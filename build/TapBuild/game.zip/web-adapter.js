function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
!function r(b, d, f) {
  function g(k, l) {
    if (!d[k]) {
      if (!b[k]) {
        var m = 'function' == typeof require && require;
        if (!l && m) return m(k, !0x0);
        if (h) return h(k, !0x0);
        throw (l = new Error('Cannot\x20find\x20module\x20\x27' + k + '\x27'))['code'] = 'MODULE_NOT_FOUND', l;
      }
      m = d[k] = {
        'exports': {}
      }, b[k][0x0]['call'](m['exports'], function (p) {
        return g(b[k][0x1][p] || p);
      }, m, m['exports'], r, b, d, f);
    }
    return d[k]['exports'];
  }
  for (var h = 'function' == typeof require && require, j = 0x0; j < f['length']; j++) g(f[j]);
  return g;
}({
  0x1: [function (a, b, c) {
    function g(y) {
      this['options'] = y || {
        'locator': {}
      };
    }
    function h() {
      this['cdata'] = !0x1;
    }
    function j(y, z) {
      z['lineNumber'] = y['lineNumber'], z['columnNumber'] = y['columnNumber'];
    }
    function k(y) {
      if (y) return '\x0a@' + (y['systemId'] || '') + '#[line:' + y['lineNumber'] + ',col:' + y['columnNumber'] + ']';
    }
    function q(y, z, A) {
      return 'string' == typeof y ? y['substr'](z, A) : y['length'] >= z + A || z ? new java['lang']['String'](y, z, A) + '' : y;
    }
    function u(y, z) {
      (y['currentElement'] || y['doc'])['appendChild'](z);
    }
    g['prototype']['parseFromString'] = function (y, z) {
      var A = this['options'],
        B = new w(),
        C = A['domBuilder'] || new h(),
        D = A['errorHandler'],
        E = A['locator'],
        F = A['xmlns'] || {},
        z = /\/x?html?$/['test'](z),
        G = z ? v['entityMap'] : {
          'lt': '<',
          'gt': '>',
          'amp': '&',
          'quot': '\x22',
          'apos': '\x27'
        };
      return E && C['setDocumentLocator'](E), B['errorHandler'] = function (H, I, J) {
        if (!H) {
          if (I instanceof h) return I;
          H = I;
        }
        var K = {},
          L = H instanceof Function;
        function M(N) {
          var O = H[N];
          !O && L && (O = 0x2 == H['length'] ? function (P) {
            H(N, P);
          } : H), K[N] = O ? function (P) {
            O('[xmldom\x20' + N + ']\x09' + P + k(J));
          } : function () {};
        }
        return J = J || {}, M('warning'), M('error'), M('fatalError'), K;
      }(D, C, E), B['domBuilder'] = A['domBuilder'] || C, z && (F[''] = 'http://www.w3.org/1999/xhtml'), F['xml'] = F['xml'] || 'http://www.w3.org/XML/1998/namespace', y ? B['parse'](y, F, G) : B['errorHandler']['error']('invalid\x20doc\x20source'), C['doc'];
    }, h['prototype'] = {
      'startDocument': function startDocument() {
        this['doc'] = new x()['createDocument'](null, null, null), this['locator'] && (this['doc']['documentURI'] = this['locator']['systemId']);
      },
      'startElement': function startElement(y, z, A, B) {
        var C = this['doc'],
          D = C['createElementNS'](y, A || z),
          E = B['length'];
        u(this, D), this['currentElement'] = D, this['locator'] && j(this['locator'], D);
        for (var F = 0x0; F < E; F++) {
          var y = B['getURI'](F),
            G = B['getValue'](F),
            A = B['getQName'](F),
            H = C['createAttributeNS'](y, A);
          this['locator'] && j(B['getLocator'](F), H), H['value'] = H['nodeValue'] = G, D['setAttributeNode'](H);
        }
      },
      'endElement': function endElement(y, z, A) {
        var B = this['currentElement'];
        B['tagName'], this['currentElement'] = B['parentNode'];
      },
      'startPrefixMapping': function startPrefixMapping(y, z) {},
      'endPrefixMapping': function endPrefixMapping(y) {},
      'processingInstruction': function processingInstruction(y, z) {
        y = this['doc']['createProcessingInstruction'](y, z), (this['locator'] && j(this['locator'], y), u(this, y));
      },
      'ignorableWhitespace': function ignorableWhitespace(y, z, A) {},
      'characters': function characters(y, z, A) {
        var B;
        (y = q['apply'](this, arguments)) && (B = this['cdata'] ? this['doc']['createCDATASection'](y) : this['doc']['createTextNode'](y), this['currentElement'] ? this['currentElement']['appendChild'](B) : /^\s*$/['test'](y) && this['doc']['appendChild'](B), this['locator']) && j(this['locator'], B);
      },
      'skippedEntity': function skippedEntity(y) {},
      'endDocument': function endDocument() {
        this['doc']['normalize']();
      },
      'setDocumentLocator': function setDocumentLocator(y) {
        (this['locator'] = y) && (y['lineNumber'] = 0x0);
      },
      'comment': function comment(y, z, A) {
        y = q['apply'](this, arguments), y = this['doc']['createComment'](y), (this['locator'] && j(this['locator'], y), u(this, y));
      },
      'startCDATA': function startCDATA() {
        this['cdata'] = !0x0;
      },
      'endCDATA': function endCDATA() {
        this['cdata'] = !0x1;
      },
      'startDTD': function startDTD(y, z, A) {
        var B = this['doc']['implementation'];
        B && B['createDocumentType'] && (B = B['createDocumentType'](y, z, A), this['locator'] && j(this['locator'], B), u(this, B));
      },
      'warning': function warning(y) {
        console['warn']('[xmldom\x20warning]\x09' + y, k(this['locator']));
      },
      'error': function error(y) {
        console['error']('[xmldom\x20error]\x09' + y, k(this['locator']));
      },
      'fatalError': function fatalError(y) {
        throw console['error']('[xmldom\x20fatalError]\x09' + y, k(this['locator'])), y;
      }
    }, 'endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl'['replace'](/\w+/g, function (y) {
      h['prototype'][y] = function () {
        return null;
      };
    });
    var v = a('./entities'),
      w = a('./sax')['XMLReader'],
      x = c['DOMImplementation'] = a('./dom')['DOMImplementation'];
    c['XMLSerializer'] = a('./dom')['XMLSerializer'], c['DOMParser'] = g, window['DOMParser'] = g;
  }, {
    './dom': 0x2,
    './entities': 0x3,
    './sax': 0x4
  }],
  0x2: [function (q, z, J) {
    function K(az) {
      return (K = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (aA) {
        return _typeof(aA);
      } : function (aA) {
        return aA && 'function' == typeof Symbol && aA['constructor'] === Symbol && aA !== Symbol['prototype'] ? 'symbol' : _typeof(aA);
      })(az);
    }
    function Q(az, aA) {
      for (var aB in az) aA[aB] = az[aB];
    }
    function V(az, aA) {
      var aB = az['prototype'];
      if (!(aB instanceof aA)) {
        var aC,
          aD = function aD() {};
        for (aC in aD['prototype'] = aA['prototype'], aD = new aD(), aB) aD[aC] = aB[aC];
        az['prototype'] = aB = aD;
      }
      aB['constructor'] != az && ('function' != typeof az && console['error']('unknow\x20Class:' + az), aB['constructor'] = az);
    }
    var _W,
      Y = {},
      Z = (Y['ELEMENT_NODE'] = 0x1, Y['ATTRIBUTE_NODE'] = 0x2, Y['TEXT_NODE'] = 0x3, Y['CDATA_SECTION_NODE'] = 0x4, Y['ENTITY_REFERENCE_NODE'] = 0x5, Y['ENTITY_NODE'] = 0x6, Y['PROCESSING_INSTRUCTION_NODE'] = 0x7, Y['COMMENT_NODE'] = 0x8, Y['DOCUMENT_NODE'] = 0x9, Y['DOCUMENT_TYPE_NODE'] = 0xa, Y['DOCUMENT_FRAGMENT_NODE'] = 0xb, Y['NOTATION_NODE'] = 0xc, {}),
      a0 = {};
    Z['INDEX_SIZE_ERR'] = (a0[0x1] = 'Index\x20size\x20error', 0x1), Z['DOMSTRING_SIZE_ERR'] = (a0[0x2] = 'DOMString\x20size\x20error', 0x2), Z['HIERARCHY_REQUEST_ERR'] = (a0[0x3] = 'Hierarchy\x20request\x20error', 0x3), Z['WRONG_DOCUMENT_ERR'] = (a0[0x4] = 'Wrong\x20document', 0x4), Z['INVALID_CHARACTER_ERR'] = (a0[0x5] = 'Invalid\x20character', 0x5), Z['NO_DATA_ALLOWED_ERR'] = (a0[0x6] = 'No\x20data\x20allowed', 0x6), Z['NO_MODIFICATION_ALLOWED_ERR'] = (a0[0x7] = 'No\x20modification\x20allowed', 0x7), Z['NOT_FOUND_ERR'] = (a0[0x8] = 'Not\x20found', 0x8), Z['NOT_SUPPORTED_ERR'] = (a0[0x9] = 'Not\x20supported', 0x9), Z['INUSE_ATTRIBUTE_ERR'] = (a0[0xa] = 'Attribute\x20in\x20use', 0xa), Z['INVALID_STATE_ERR'] = (a0[0xb] = 'Invalid\x20state', 0xb), Z['SYNTAX_ERR'] = (a0[0xc] = 'Syntax\x20error', 0xc), Z['INVALID_MODIFICATION_ERR'] = (a0[0xd] = 'Invalid\x20modification', 0xd), Z['NAMESPACE_ERR'] = (a0[0xe] = 'Invalid\x20namespace', 0xe), Z['INVALID_ACCESS_ERR'] = (a0[0xf] = 'Invalid\x20access', 0xf);
    function a1(az, aA) {
      var aB;
      return aA instanceof Error ? aB = aA : (aB = this, Error['call'](this, a0[az]), this['message'] = a0[az], Error['captureStackTrace'] && Error['captureStackTrace'](this, a1)), aB['code'] = az, aA && (this['message'] = this['message'] + ':\x20' + aA), aB;
    }
    function a2() {}
    function a3(az, aA) {
      this['_node'] = az, this['_refresh'] = aA, a4(this);
    }
    function a4(az) {
      var aA = az['_node']['_inc'] || az['_node']['ownerDocument']['_inc'];
      if (az['_inc'] != aA) {
        var aB,
          aC = az['_refresh'](az['_node']);
        for (aB in ay(az, 'length', aC['length']), aC) az[aB] = aC[aB];
        az['_inc'] = aA;
      }
    }
    function a5() {}
    function a6(az, aA) {
      for (var aB = az['length']; aB--;) if (az[aB] === aA) return aB;
    }
    function a7(az, aA, aB, aC) {
      aC ? aA[a6(aA, aC)] = aB : aA[aA['length']++] = aB, az && (aA = (aB['ownerElement'] = az)['ownerDocument']) && (aC && ae(aA, az, aC), aC = az, az = aB, (aB = aA) && aB['_inc']++, 'http://www.w3.org/2000/xmlns/' == az['namespaceURI']) && (aC['_nsMap'][az['prefix'] ? az['localName'] : ''] = az['value']);
    }
    function a8(az, aA, aB) {
      var aC = a6(aA, aB);
      if (!(0x0 <= aC)) throw a1(0x8, new Error(az['tagName'] + '@' + aB));
      for (var aD, aE = aA['length'] - 0x1; aC < aE;) aA[aC] = aA[++aC];
      aA['length'] = aE, az && (aD = az['ownerDocument']) && (ae(aD, az, aB), aB['ownerElement'] = null);
    }
    function a9(az) {
      if (this['_features'] = {}, az) {
        for (var aA in az) this['_features'] = az[aA];
      }
    }
    function aa() {}
    function ab(az) {
      return ('<' == az ? '&lt;' : '>' == az && '&gt;') || ('&' == az ? '&amp;' : '\x22' == az && '&quot;') || '&#' + az['charCodeAt']() + ';';
    }
    function ac(az, aA) {
      if (aA(az)) return 0x1;
      if (az = az['firstChild']) do {
        if (ac(az, aA)) return 0x1;
      } while (az = az['nextSibling']);
    }
    function ad() {}
    function ae(az, aA, aB) {
      az && az['_inc']++, 'http://www.w3.org/2000/xmlns/' == aB['namespaceURI'] && delete aA['_nsMap'][aB['prefix'] ? aB['localName'] : ''];
    }
    function af(az, aA, aB) {
      if (az && az['_inc']) {
        az['_inc']++;
        var aC = aA['childNodes'];
        if (aB) aC[aC['length']++] = aB;else {
          for (var aD = aA['firstChild'], aE = 0x0; aD;) aD = (aC[aE++] = aD)['nextSibling'];
          aC['length'] = aE;
        }
      }
    }
    function ag(az, aA) {
      var aB = aA['previousSibling'],
        aC = aA['nextSibling'];
      return aB ? aB['nextSibling'] = aC : az['firstChild'] = aC, aC ? aC['previousSibling'] = aB : az['lastChild'] = aB, af(az['ownerDocument'], az), aA;
    }
    function ah(az, aA, aB) {
      var aC = aA['parentNode'];
      if (aC && aC['removeChild'](aA), 0xb === aA['nodeType']) {
        var aD = aA['firstChild'];
        if (null == aD) return aA;
        var aE = aA['lastChild'];
      } else aD = aE = aA;
      aC = aB ? aB['previousSibling'] : az['lastChild'];
      for (aD['previousSibling'] = aC, aE['nextSibling'] = aB, aC ? aC['nextSibling'] = aD : az['firstChild'] = aD, null == aB ? az['lastChild'] = aE : aB['previousSibling'] = aE; aD['parentNode'] = az, aD !== aE && (aD = aD['nextSibling']););
      return af(az['ownerDocument'] || az, az), 0xb == aA['nodeType'] && (aA['firstChild'] = aA['lastChild'] = null), aA;
    }
    function ai() {
      this['_nsMap'] = {};
    }
    function aj() {}
    function ak() {}
    function al() {}
    function am() {}
    function an() {}
    function ao() {}
    function ap() {}
    function aq() {}
    function ar() {}
    function as() {}
    function at() {}
    function au() {}
    function av(az, aA) {
      var aB,
        aC = [],
        aD = 0x9 == this['nodeType'] && this['documentElement'] || this,
        aE = aD['prefix'],
        aF = aD['namespaceURI'];
      return ax(this, aC, az, aA, aB = aF && null == aE && null == aD['lookupPrefix'](aF) ? [{
        'namespace': aF,
        'prefix': null
      }] : aB), aC['join']('');
    }
    function aw(az, aA, aB) {
      var aC = az['prefix'] || '',
        aD = az['namespaceURI'];
      if ((aC || aD) && ('xml' !== aC || 'http://www.w3.org/XML/1998/namespace' !== aD) && 'http://www.w3.org/2000/xmlns/' != aD) {
        for (var aE = aB['length']; aE--;) {
          var aF = aB[aE];
          if (aF['prefix'] == aC) return aF['namespace'] != aD;
        }
        return 0x1;
      }
    }
    function ax(az, aA, aB, aC, aD) {
      if (aC) {
        if (!(az = aC(az))) return;
        if ('string' == typeof az) return void aA['push'](az);
      }
      switch (az['nodeType']) {
        case 0x1:
          aD = aD || [];
          var aE = az['attributes'],
            aF = aE['length'],
            aG = az['firstChild'],
            aH = az['tagName'];
          aB = 'http://www.w3.org/1999/xhtml' === az['namespaceURI'] || aB, aA['push']('<', aH);
          for (var aI = 0x0; aI < aF; aI++) 'xmlns' == (aJ = aE['item'](aI))['prefix'] ? aD['push']({
            'prefix': aJ['localName'],
            'namespace': aJ['value']
          }) : 'xmlns' == aJ['nodeName'] && aD['push']({
            'prefix': '',
            'namespace': aJ['value']
          });
          for (var aJ, aK, aL, aI = 0x0; aI < aF; aI++) aw(aJ = aE['item'](aI), 0x0, aD) && (aK = aJ['prefix'] || '', aL = aJ['namespaceURI'], aA['push'](aK ? '\x20xmlns:' + aK : '\x20xmlns', '=\x22', aL, '\x22'), aD['push']({
            'prefix': aK,
            'namespace': aL
          })), ax(aJ, aA, aB, aC, aD);
          if (aw(az, 0x0, aD) && (aK = az['prefix'] || '', aL = az['namespaceURI'], aA['push'](aK ? '\x20xmlns:' + aK : '\x20xmlns', '=\x22', aL, '\x22'), aD['push']({
            'prefix': aK,
            'namespace': aL
          })), aG || aB && !/^(?:meta|link|img|br|hr|input)$/i['test'](aH)) {
            if (aA['push']('>'), aB && /^script$/i['test'](aH)) {
              for (; aG;) aG['data'] ? aA['push'](aG['data']) : ax(aG, aA, aB, aC, aD), aG = aG['nextSibling'];
            } else {
              for (; aG;) ax(aG, aA, aB, aC, aD), aG = aG['nextSibling'];
            }
            aA['push']('</', aH, '>');
          } else aA['push']('/>');
          return;
        case 0x9:
        case 0xb:
          for (aG = az['firstChild']; aG;) ax(aG, aA, aB, aC, aD), aG = aG['nextSibling'];
          return;
        case 0x2:
          return aA['push']('\x20', az['name'], '=\x22', az['value']['replace'](/[<&"]/g, ab), '\x22');
        case 0x3:
          return aA['push'](az['data']['replace'](/[<&]/g, ab));
        case 0x4:
          return aA['push']('<![CDATA[', az['data'], ']]>');
        case 0x8:
          return aA['push']('<!--', az['data'], '-->');
        case 0xa:
          var aH = az['publicId'],
            aM = az['systemId'];
          return aA['push']('<!DOCTYPE\x20', az['name']), void (aH ? (aA['push']('\x20PUBLIC\x20\x22', aH), aM && '.' != aM && aA['push']('\x22\x20\x22', aM), aA['push']('\x22>')) : aM && '.' != aM ? aA['push']('\x20SYSTEM\x20\x22', aM, '\x22>') : ((aH = az['internalSubset']) && aA['push']('\x20[', aH, ']'), aA['push']('>')));
        case 0x7:
          return aA['push']('<?', az['target'], '\x20', az['data'], '?>');
        case 0x5:
          return aA['push']('&', az['nodeName'], ';');
        default:
          aA['push']('??', az['nodeName']);
      }
    }
    function ay(az, aA, aB) {
      az[aA] = aB;
    }
    a1['prototype'] = Error['prototype'], Q(Z, a1), a2['prototype'] = {
      'length': 0x0,
      'item': function item(az) {
        return this[az] || null;
      },
      'toString': function toString(az, aA) {
        for (var aB = [], aC = 0x0; aC < this['length']; aC++) ax(this[aC], aB, az, aA);
        return aB['join']('');
      }
    }, a3['prototype']['item'] = function (az) {
      return a4(this), this[az];
    }, V(a3, a2), a5['prototype'] = {
      'length': 0x0,
      'item': a2['prototype']['item'],
      'getNamedItem': function getNamedItem(az) {
        for (var aA = this['length']; aA--;) {
          var aB = this[aA];
          if (aB['nodeName'] == az) return aB;
        }
      },
      'setNamedItem': function setNamedItem(az) {
        var aA = az['ownerElement'];
        if (aA && aA != this['_ownerElement']) throw new a1(0xa);
        return aA = this['getNamedItem'](az['nodeName']), (a7(this['_ownerElement'], this, az, aA), aA);
      },
      'setNamedItemNS': function setNamedItemNS(az) {
        var aA = az['ownerElement'];
        if (aA && aA != this['_ownerElement']) throw new a1(0xa);
        return aA = this['getNamedItemNS'](az['namespaceURI'], az['localName']), a7(this['_ownerElement'], this, az, aA), aA;
      },
      'removeNamedItem': function removeNamedItem(az) {
        return az = this['getNamedItem'](az), (a8(this['_ownerElement'], this, az), az);
      },
      'removeNamedItemNS': function removeNamedItemNS(az, aA) {
        return az = this['getNamedItemNS'](az, aA), (a8(this['_ownerElement'], this, az), az);
      },
      'getNamedItemNS': function getNamedItemNS(az, aA) {
        for (var aB = this['length']; aB--;) {
          var aC = this[aB];
          if (aC['localName'] == aA && aC['namespaceURI'] == az) return aC;
        }
        return null;
      }
    }, a9['prototype'] = {
      'hasFeature': function hasFeature(az, aA) {
        return az = this['_features'][az['toLowerCase']()], !(!az || aA && !(aA in az));
      },
      'createDocument': function createDocument(az, aA, aB) {
        var aC = new ad();
        return aC['implementation'] = this, aC['childNodes'] = new a2(), (aC['doctype'] = aB) && aC['appendChild'](aB), aA && (aB = aC['createElementNS'](az, aA), aC['appendChild'](aB)), aC;
      },
      'createDocumentType': function createDocumentType(az, aA, aB) {
        var aC = new ao();
        return aC['name'] = az, aC['nodeName'] = az, aC['publicId'] = aA, aC['systemId'] = aB, aC;
      }
    }, aa['prototype'] = {
      'firstChild': null,
      'lastChild': null,
      'previousSibling': null,
      'nextSibling': null,
      'attributes': null,
      'parentNode': null,
      'childNodes': null,
      'ownerDocument': null,
      'nodeValue': null,
      'namespaceURI': null,
      'prefix': null,
      'localName': null,
      'insertBefore': function insertBefore(az, aA) {
        return ah(this, az, aA);
      },
      'replaceChild': function replaceChild(az, aA) {
        this['insertBefore'](az, aA), aA && this['removeChild'](aA);
      },
      'removeChild': function removeChild(az) {
        return ag(this, az);
      },
      'appendChild': function appendChild(az) {
        return this['insertBefore'](az, null);
      },
      'hasChildNodes': function hasChildNodes() {
        return null != this['firstChild'];
      },
      'cloneNode': function cloneNode(az) {
        return function aA(aB, aC, aD) {
          var aE = new aC['constructor']();
          for (var aF in aC) {
            var aG = aC[aF];
            'object' != K(aG) && aG != aE[aF] && (aE[aF] = aG);
          }
          aC['childNodes'] && (aE['childNodes'] = new a2()), aE['ownerDocument'] = aB;
          switch (aE['nodeType']) {
            case 0x1:
              var aH = aC['attributes'],
                aI = aE['attributes'] = new a5(),
                aJ = aH['length'];
              aI['_ownerElement'] = aE;
              for (var aK = 0x0; aK < aJ; aK++) aE['setAttributeNode'](aA(aB, aH['item'](aK), !0x0));
              break;
            case 0x2:
              aD = !0x0;
          }
          if (aD) {
            for (var aL = aC['firstChild']; aL;) aE['appendChild'](aA(aB, aL, aD)), aL = aL['nextSibling'];
          }
          return aE;
        }(this['ownerDocument'] || this, this, az);
      },
      'normalize': function normalize() {
        for (var az = this['firstChild']; az;) {
          var aA = az['nextSibling'];
          aA && 0x3 == aA['nodeType'] && 0x3 == az['nodeType'] ? (this['removeChild'](aA), az['appendData'](aA['data'])) : (az['normalize'](), az = aA);
        }
      },
      'isSupported': function isSupported(az, aA) {
        return this['ownerDocument']['implementation']['hasFeature'](az, aA);
      },
      'hasAttributes': function hasAttributes() {
        return 0x0 < this['attributes']['length'];
      },
      'lookupPrefix': function lookupPrefix(az) {
        for (var aA = this; aA;) {
          var aB = aA['_nsMap'];
          if (aB) {
            for (var aC in aB) if (aB[aC] == az) return aC;
          }
          aA = 0x2 == aA['nodeType'] ? aA['ownerDocument'] : aA['parentNode'];
        }
        return null;
      },
      'lookupNamespaceURI': function lookupNamespaceURI(az) {
        for (var aA = this; aA;) {
          var aB = aA['_nsMap'];
          if (aB && az in aB) return aB[az];
          aA = 0x2 == aA['nodeType'] ? aA['ownerDocument'] : aA['parentNode'];
        }
        return null;
      },
      'isDefaultNamespace': function isDefaultNamespace(az) {
        return null == this['lookupPrefix'](az);
      }
    }, Q(Y, aa), Q(Y, aa['prototype']), ad['prototype'] = {
      'nodeName': '#document',
      'nodeType': 0x9,
      'doctype': null,
      'documentElement': null,
      '_inc': 0x1,
      'insertBefore': function insertBefore(az, aA) {
        if (0xb == az['nodeType']) for (var aB = az['firstChild']; aB;) {
          var aC = aB['nextSibling'];
          this['insertBefore'](aB, aA), aB = aC;
        } else null == this['documentElement'] && 0x1 == az['nodeType'] && (this['documentElement'] = az), ah(this, az, aA), az['ownerDocument'] = this;
        return az;
      },
      'removeChild': function removeChild(az) {
        return this['documentElement'] == az && (this['documentElement'] = null), ag(this, az);
      },
      'importNode': function importNode(az, aA) {
        return function aB(aC, aD, aE) {
          var aF;
          switch (aD['nodeType']) {
            case 0x1:
              (aF = aD['cloneNode'](!0x1))['ownerDocument'] = aC;
            case 0xb:
              break;
            case 0x2:
              aE = !0x0;
          }
          aF = aF || aD['cloneNode'](!0x1), aF['ownerDocument'] = aC, aF['parentNode'] = null;
          if (aE) {
            for (var aG = aD['firstChild']; aG;) aF['appendChild'](aB(aC, aG, aE)), aG = aG['nextSibling'];
          }
          return aF;
        }(this, az, aA);
      },
      'getElementById': function getElementById(az) {
        var aA = null;
        return ac(this['documentElement'], function (aB) {
          if (0x1 == aB['nodeType'] && aB['getAttribute']('id') == az) return aA = aB, !0x0;
        }), aA;
      },
      'createElement': function createElement(az) {
        var aA = new ai();
        return aA['ownerDocument'] = this, aA['nodeName'] = az, aA['tagName'] = az, aA['childNodes'] = new a2(), (aA['attributes'] = new a5())['_ownerElement'] = aA;
      },
      'createDocumentFragment': function createDocumentFragment() {
        var az = new as();
        return az['ownerDocument'] = this, az['childNodes'] = new a2(), az;
      },
      'createTextNode': function createTextNode(az) {
        var aA = new al();
        return aA['ownerDocument'] = this, aA['appendData'](az), aA;
      },
      'createComment': function createComment(az) {
        var aA = new am();
        return aA['ownerDocument'] = this, aA['appendData'](az), aA;
      },
      'createCDATASection': function createCDATASection(az) {
        var aA = new an();
        return aA['ownerDocument'] = this, aA['appendData'](az), aA;
      },
      'createProcessingInstruction': function createProcessingInstruction(az, aA) {
        var aB = new at();
        return aB['ownerDocument'] = this, aB['tagName'] = aB['target'] = az, aB['nodeValue'] = aB['data'] = aA, aB;
      },
      'createAttribute': function createAttribute(az) {
        var aA = new aj();
        return aA['ownerDocument'] = this, aA['name'] = az, aA['nodeName'] = az, aA['localName'] = az, aA['specified'] = !0x0, aA;
      },
      'createEntityReference': function createEntityReference(az) {
        var aA = new ar();
        return aA['ownerDocument'] = this, aA['nodeName'] = az, aA;
      },
      'createElementNS': function createElementNS(az, aA) {
        var aB = new ai(),
          aC = aA['split'](':'),
          aD = aB['attributes'] = new a5();
        return aB['childNodes'] = new a2(), aB['ownerDocument'] = this, aB['nodeName'] = aA, aB['tagName'] = aA, aB['namespaceURI'] = az, 0x2 == aC['length'] ? (aB['prefix'] = aC[0x0], aB['localName'] = aC[0x1]) : aB['localName'] = aA, aD['_ownerElement'] = aB;
      },
      'createAttributeNS': function createAttributeNS(az, aA) {
        var aB = new aj(),
          aC = aA['split'](':');
        return aB['ownerDocument'] = this, aB['nodeName'] = aA, aB['name'] = aA, aB['namespaceURI'] = az, aB['specified'] = !0x0, 0x2 == aC['length'] ? (aB['prefix'] = aC[0x0], aB['localName'] = aC[0x1]) : aB['localName'] = aA, aB;
      }
    }, V(ad, aa), ad['prototype']['getElementsByTagName'] = (ai['prototype'] = {
      'nodeType': 0x1,
      'hasAttribute': function hasAttribute(az) {
        return null != this['getAttributeNode'](az);
      },
      'getAttribute': function getAttribute(az) {
        return az = this['getAttributeNode'](az), az && az['value'] || '';
      },
      'getAttributeNode': function getAttributeNode(az) {
        return this['attributes']['getNamedItem'](az);
      },
      'setAttribute': function setAttribute(az, aA) {
        az = this['ownerDocument']['createAttribute'](az), (az['value'] = az['nodeValue'] = '' + aA, this['setAttributeNode'](az));
      },
      'removeAttribute': function removeAttribute(az) {
        az = this['getAttributeNode'](az), az && this['removeAttributeNode'](az);
      },
      'appendChild': function appendChild(az) {
        return 0xb === az['nodeType'] ? this['insertBefore'](az, null) : (aA = this, (aB = (az = az)['parentNode']) && (aC = aA['lastChild'], aB['removeChild'](az), aC = aA['lastChild']), aC = aA['lastChild'], az['parentNode'] = aA, az['previousSibling'] = aC, az['nextSibling'] = null, aC ? aC['nextSibling'] = az : aA['firstChild'] = az, aA['lastChild'] = az, af(aA['ownerDocument'], aA, az), az);
        var aA, aB, aC;
      },
      'setAttributeNode': function setAttributeNode(az) {
        return this['attributes']['setNamedItem'](az);
      },
      'setAttributeNodeNS': function setAttributeNodeNS(az) {
        return this['attributes']['setNamedItemNS'](az);
      },
      'removeAttributeNode': function removeAttributeNode(az) {
        return this['attributes']['removeNamedItem'](az['nodeName']);
      },
      'removeAttributeNS': function removeAttributeNS(az, aA) {
        az = this['getAttributeNodeNS'](az, aA), az && this['removeAttributeNode'](az);
      },
      'hasAttributeNS': function hasAttributeNS(az, aA) {
        return null != this['getAttributeNodeNS'](az, aA);
      },
      'getAttributeNS': function getAttributeNS(az, aA) {
        return az = this['getAttributeNodeNS'](az, aA), az && az['value'] || '';
      },
      'setAttributeNS': function setAttributeNS(az, aA, aB) {
        az = this['ownerDocument']['createAttributeNS'](az, aA), (az['value'] = az['nodeValue'] = '' + aB, this['setAttributeNode'](az));
      },
      'getAttributeNodeNS': function getAttributeNodeNS(az, aA) {
        return this['attributes']['getNamedItemNS'](az, aA);
      },
      'getElementsByTagName': function getElementsByTagName(az) {
        return new a3(this, function (aA) {
          var aB = [];
          return ac(aA, function (aC) {
            aC === aA || 0x1 != aC['nodeType'] || '*' !== az && aC['tagName'] != az || aB['push'](aC);
          }), aB;
        });
      },
      'getElementsByTagNameNS': function getElementsByTagNameNS(az, aA) {
        return new a3(this, function (aB) {
          var aC = [];
          return ac(aB, function (aD) {
            aD === aB || 0x1 !== aD['nodeType'] || '*' !== az && aD['namespaceURI'] !== az || '*' !== aA && aD['localName'] != aA || aC['push'](aD);
          }), aC;
        });
      }
    })['getElementsByTagName'], ad['prototype']['getElementsByTagNameNS'] = ai['prototype']['getElementsByTagNameNS'], V(ai, aa), aj['prototype']['nodeType'] = 0x2, V(aj, aa), ak['prototype'] = {
      'data': '',
      'substringData': function substringData(az, aA) {
        return this['data']['substring'](az, az + aA);
      },
      'appendData': function appendData(az) {
        az = this['data'] + az, this['nodeValue'] = this['data'] = az, this['length'] = az['length'];
      },
      'insertData': function insertData(az, aA) {
        this['replaceData'](az, 0x0, aA);
      },
      'appendChild': function appendChild(az) {
        throw new Error(a0[0x3]);
      },
      'deleteData': function deleteData(az, aA) {
        this['replaceData'](az, aA, '');
      },
      'replaceData': function replaceData(az, aA, aB) {
        var aC = this['data']['substring'](0x0, az),
          az = this['data']['substring'](az + aA);
        this['nodeValue'] = this['data'] = aB = aC + aB + az, this['length'] = aB['length'];
      }
    }, V(ak, aa), al['prototype'] = {
      'nodeName': '#text',
      'nodeType': 0x3,
      'splitText': function splitText(az) {
        var aA = (aB = this['data'])['substring'](az),
          aB = aB['substring'](0x0, az),
          az = (this['data'] = this['nodeValue'] = aB, this['length'] = aB['length'], this['ownerDocument']['createTextNode'](aA));
        return this['parentNode'] && this['parentNode']['insertBefore'](az, this['nextSibling']), az;
      }
    }, V(al, ak), am['prototype'] = {
      'nodeName': '#comment',
      'nodeType': 0x8
    }, V(am, ak), an['prototype'] = {
      'nodeName': '#cdata-section',
      'nodeType': 0x4
    }, V(an, ak), ao['prototype']['nodeType'] = 0xa, V(ao, aa), ap['prototype']['nodeType'] = 0xc, V(ap, aa), aq['prototype']['nodeType'] = 0x6, V(aq, aa), ar['prototype']['nodeType'] = 0x5, V(ar, aa), as['prototype']['nodeName'] = '#document-fragment', as['prototype']['nodeType'] = 0xb, V(as, aa), at['prototype']['nodeType'] = 0x7, V(at, aa), au['prototype']['serializeToString'] = function (az, aA, aB) {
      return av['call'](az, aA, aB);
    }, aa['prototype']['toString'] = av;
    try {
      Object['defineProperty'] && (_W = function W(az) {
        switch (az['nodeType']) {
          case 0x1:
          case 0xb:
            var aA = [];
            for (az = az['firstChild']; az;) 0x7 !== az['nodeType'] && 0x8 !== az['nodeType'] && aA['push'](_W(az)), az = az['nextSibling'];
            return aA['join']('');
          default:
            return az['nodeValue'];
        }
      }, Object['defineProperty'](a3['prototype'], 'length', {
        'get': function get() {
          return a4(this), this['$$length'];
        }
      }), Object['defineProperty'](aa['prototype'], 'textContent', {
        'get': function get() {
          return _W(this);
        },
        'set': function set(az) {
          switch (this['nodeType']) {
            case 0x1:
            case 0xb:
              for (; this['firstChild'];) this['removeChild'](this['firstChild']);
              (az || String(az)) && this['appendChild'](this['ownerDocument']['createTextNode'](az));
              break;
            default:
              this['data'] = az, this['value'] = az, this['nodeValue'] = az;
          }
        }
      }), ay = function ay(az, aA, aB) {
        az['$$' + aA] = aB;
      });
    } catch (az) {}
    J['DOMImplementation'] = a9, J['XMLSerializer'] = au;
  }, {}],
  0x3: [function (a, b, c) {
    c['entityMap'] = {
      'lt': '<',
      'gt': '>',
      'amp': '&',
      'quot': '\x22',
      'apos': '\x27',
      'Agrave': 'À',
      'Aacute': 'Á',
      'Acirc': 'Â',
      'Atilde': 'Ã',
      'Auml': 'Ä',
      'Aring': 'Å',
      'AElig': 'Æ',
      'Ccedil': 'Ç',
      'Egrave': 'È',
      'Eacute': 'É',
      'Ecirc': 'Ê',
      'Euml': 'Ë',
      'Igrave': 'Ì',
      'Iacute': 'Í',
      'Icirc': 'Î',
      'Iuml': 'Ï',
      'ETH': 'Ð',
      'Ntilde': 'Ñ',
      'Ograve': 'Ò',
      'Oacute': 'Ó',
      'Ocirc': 'Ô',
      'Otilde': 'Õ',
      'Ouml': 'Ö',
      'Oslash': 'Ø',
      'Ugrave': 'Ù',
      'Uacute': 'Ú',
      'Ucirc': 'Û',
      'Uuml': 'Ü',
      'Yacute': 'Ý',
      'THORN': 'Þ',
      'szlig': 'ß',
      'agrave': 'à',
      'aacute': 'á',
      'acirc': 'â',
      'atilde': 'ã',
      'auml': 'ä',
      'aring': 'å',
      'aelig': 'æ',
      'ccedil': 'ç',
      'egrave': 'è',
      'eacute': 'é',
      'ecirc': 'ê',
      'euml': 'ë',
      'igrave': 'ì',
      'iacute': 'í',
      'icirc': 'î',
      'iuml': 'ï',
      'eth': 'ð',
      'ntilde': 'ñ',
      'ograve': 'ò',
      'oacute': 'ó',
      'ocirc': 'ô',
      'otilde': 'õ',
      'ouml': 'ö',
      'oslash': 'ø',
      'ugrave': 'ù',
      'uacute': 'ú',
      'ucirc': 'û',
      'uuml': 'ü',
      'yacute': 'ý',
      'thorn': 'þ',
      'yuml': 'ÿ',
      'nbsp': '\x20',
      'iexcl': '¡',
      'cent': '¢',
      'pound': '£',
      'curren': '¤',
      'yen': '¥',
      'brvbar': '¦',
      'sect': '§',
      'uml': '¨',
      'copy': '©',
      'ordf': 'ª',
      'laquo': '«',
      'not': '¬',
      'shy': '­­',
      'reg': '®',
      'macr': '¯',
      'deg': '°',
      'plusmn': '±',
      'sup2': '²',
      'sup3': '³',
      'acute': '´',
      'micro': 'µ',
      'para': '¶',
      'middot': '·',
      'cedil': '¸',
      'sup1': '¹',
      'ordm': 'º',
      'raquo': '»',
      'frac14': '¼',
      'frac12': '½',
      'frac34': '¾',
      'iquest': '¿',
      'times': '×',
      'divide': '÷',
      'forall': '∀',
      'part': '∂',
      'exist': '∃',
      'empty': '∅',
      'nabla': '∇',
      'isin': '∈',
      'notin': '∉',
      'ni': '∋',
      'prod': '∏',
      'sum': '∑',
      'minus': '−',
      'lowast': '∗',
      'radic': '√',
      'prop': '∝',
      'infin': '∞',
      'ang': '∠',
      'and': '∧',
      'or': '∨',
      'cap': '∩',
      'cup': '∪',
      'int': '∫',
      'there4': '∴',
      'sim': '∼',
      'cong': '≅',
      'asymp': '≈',
      'ne': '≠',
      'equiv': '≡',
      'le': '≤',
      'ge': '≥',
      'sub': '⊂',
      'sup': '⊃',
      'nsub': '⊄',
      'sube': '⊆',
      'supe': '⊇',
      'oplus': '⊕',
      'otimes': '⊗',
      'perp': '⊥',
      'sdot': '⋅',
      'Alpha': 'Α',
      'Beta': 'Β',
      'Gamma': 'Γ',
      'Delta': 'Δ',
      'Epsilon': 'Ε',
      'Zeta': 'Ζ',
      'Eta': 'Η',
      'Theta': 'Θ',
      'Iota': 'Ι',
      'Kappa': 'Κ',
      'Lambda': 'Λ',
      'Mu': 'Μ',
      'Nu': 'Ν',
      'Xi': 'Ξ',
      'Omicron': 'Ο',
      'Pi': 'Π',
      'Rho': 'Ρ',
      'Sigma': 'Σ',
      'Tau': 'Τ',
      'Upsilon': 'Υ',
      'Phi': 'Φ',
      'Chi': 'Χ',
      'Psi': 'Ψ',
      'Omega': 'Ω',
      'alpha': 'α',
      'beta': 'β',
      'gamma': 'γ',
      'delta': 'δ',
      'epsilon': 'ε',
      'zeta': 'ζ',
      'eta': 'η',
      'theta': 'θ',
      'iota': 'ι',
      'kappa': 'κ',
      'lambda': 'λ',
      'mu': 'μ',
      'nu': 'ν',
      'xi': 'ξ',
      'omicron': 'ο',
      'pi': 'π',
      'rho': 'ρ',
      'sigmaf': 'ς',
      'sigma': 'σ',
      'tau': 'τ',
      'upsilon': 'υ',
      'phi': 'φ',
      'chi': 'χ',
      'psi': 'ψ',
      'omega': 'ω',
      'thetasym': 'ϑ',
      'upsih': 'ϒ',
      'piv': 'ϖ',
      'OElig': 'Œ',
      'oelig': 'œ',
      'Scaron': 'Š',
      'scaron': 'š',
      'Yuml': 'Ÿ',
      'fnof': 'ƒ',
      'circ': 'ˆ',
      'tilde': '˜',
      'ensp': "\u2002",
      'emsp': "\u2003",
      'thinsp': "\u2009",
      'zwnj': '‌',
      'zwj': '‍',
      'lrm': '‎',
      'rlm': '‏',
      'ndash': '–',
      'mdash': '—',
      'lsquo': '‘',
      'rsquo': '’',
      'sbquo': '‚',
      'ldquo': '“',
      'rdquo': '”',
      'bdquo': '„',
      'dagger': '†',
      'Dagger': '‡',
      'bull': '•',
      'hellip': '…',
      'permil': '‰',
      'prime': '′',
      'Prime': '″',
      'lsaquo': '‹',
      'rsaquo': '›',
      'oline': '‾',
      'euro': '€',
      'trade': '™',
      'larr': '←',
      'uarr': '↑',
      'rarr': '→',
      'darr': '↓',
      'harr': '↔',
      'crarr': '↵',
      'lceil': '⌈',
      'rceil': '⌉',
      'lfloor': '⌊',
      'rfloor': '⌋',
      'loz': '◊',
      'spades': '♠',
      'clubs': '♣',
      'hearts': '♥',
      'diams': '♦'
    };
  }, {}],
  0x4: [function (b, c, d) {
    var f = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
      g = new RegExp('[\x5c-\x5c.0-9' + f['source']['slice'](0x1, -0x1) + '\x5cu00B7\x5cu0300-\x5cu036F\x5cu203F-\x5cu2040]'),
      h = new RegExp('^' + f['source'] + g['source'] + '*(?::' + f['source'] + g['source'] + '*)?$'),
      k = 0x0,
      l = 0x1,
      m = 0x2,
      q = 0x3,
      s = 0x4,
      u = 0x5,
      v = 0x6,
      w = 0x7;
    function y() {}
    function z(J, K) {
      return K['lineNumber'] = J['lineNumber'], K['columnNumber'] = J['columnNumber'], K;
    }
    function A(J, K, N) {
      for (var O = J['tagName'], P = null, Q = J['length']; Q--;) {
        var R = J[Q],
          S = R['qName'],
          T = R['value'],
          S = 0x0 < (W = S['indexOf'](':')) ? (V = R['prefix'] = S['slice'](0x0, W), X = S['slice'](W + 0x1), 'xmlns' === V && X) : (V = null, 'xmlns' === (X = S) && '');
        R['localName'] = X, !0x1 !== S && (null == P && (P = {}, E(N, N = {})), N[S] = P[S] = T, R['uri'] = 'http://www.w3.org/2000/xmlns/', K['startPrefixMapping'](S, T));
      }
      for (var V, Q = J['length']; Q--;) (V = (R = J[Q])['prefix']) && ('xml' === V && (R['uri'] = 'http://www.w3.org/XML/1998/namespace'), 'xmlns' !== V) && (R['uri'] = N[V || '']);
      var W,
        X = 0x0 < (W = O['indexOf'](':')) ? (V = J['prefix'] = O['slice'](0x0, W), J['localName'] = O['slice'](W + 0x1)) : (V = null, J['localName'] = O),
        Y = J['uri'] = N[V || ''];
      if (K['startElement'](Y, X, O, J), !J['closed']) return J['currentNSMap'] = N, J['localNSMap'] = P, 0x1;
      if (K['endElement'](Y, X, O), P) {
        for (V in P) K['endPrefixMapping'](V);
      }
    }
    function E(J, K) {
      for (var N in J) K[N] = J[N];
    }
    function G(J) {}
    y['prototype'] = {
      'parse': function parse(J, K, N) {
        var O = this['domBuilder'];
        O['startDocument'](), E(K, K = {}), function (Q, V, W, X, Y) {
          function Z(ao) {
            var ap = ao['slice'](0x1, -0x1);
            return ap in W ? W[ap] : '#' === ap['charAt'](0x0) ? 0xffff < (ap = parseInt(ap['substr'](0x1)['replace']('x', '0x'))) ? (ap -= 0x10000, String['fromCharCode'](0xd800 + (ap >> 0xa), 0xdc00 + (0x3ff & ap))) : String['fromCharCode'](ap) : (Y['error']('entity\x20not\x20found:' + ao), ao);
          }
          function a0(ao) {
            var ap;
            a8 < ao && (ap = Q['substring'](a8, ao)['replace'](/&#?\w+;/g, Z), a5 && a1(a8), X['characters'](ap, 0x0, ao - a8), a8 = ao);
          }
          function a1(ao, ap) {
            for (; a3 <= ao && (ap = a4['exec'](Q));) a2 = ap['index'], a3 = a2 + ap[0x0]['length'], a5['lineNumber']++;
            a5['columnNumber'] = ao - a2 + 0x1;
          }
          for (var a2 = 0x0, a3 = 0x0, a4 = /.*(?:\r\n?|\n)|.*$/g, a5 = X['locator'], a6 = [{
              'currentNSMap': V
            }], a7 = {}, a8 = 0x0;;) {
            try {
              var a9,
                aa,
                ab = Q['indexOf']('<', a8);
              if (ab < 0x0) return Q['substr'](a8)['match'](/^\s*$/) || (a9 = X['doc'], aa = a9['createTextNode'](Q['substr'](a8)), a9['appendChild'](aa), X['currentElement'] = aa);
              switch (a8 < ab && a0(ab), Q['charAt'](ab + 0x1)) {
                case '/':
                  var ac = Q['indexOf']('>', ab + 0x3),
                    ad = Q['substring'](ab + 0x2, ac),
                    ae = a6['pop'](),
                    af = (ac < 0x0 ? (ad = Q['substring'](ab + 0x2)['replace'](/[\s<].*/, ''), Y['error']('end\x20tag\x20name:\x20' + ad + '\x20is\x20not\x20complete:' + ae['tagName']), ac = ab + 0x1 + ad['length']) : ad['match'](/\s</) && (ad = ad['replace'](/[\s<].*/, ''), Y['error']('end\x20tag\x20name:\x20' + ad + '\x20maybe\x20not\x20complete'), ac = ab + 0x1 + ad['length']), ae['localNSMap']),
                    ag = ae['tagName'] == ad;
                  if (ag || ae['tagName'] && ae['tagName']['toLowerCase']() == ad['toLowerCase']()) {
                    if (X['endElement'](ae['uri'], ae['localName'], ad), af) {
                      for (var ah in af) X['endPrefixMapping'](ah);
                    }
                    ag || Y['fatalError']('end\x20tag\x20name:\x20' + ad + '\x20is\x20not\x20match\x20the\x20current\x20start\x20tagName:' + ae['tagName']);
                  } else a6['push'](ae);
                  ac++;
                  break;
                case '?':
                  a5 && a1(ab), ac = function (ao, ap, aq) {
                    var ar = ao['indexOf']('?>', ap);
                    if (ar) {
                      ao = ao['substring'](ap, ar)['match'](/^<\?(\S*)\s*([\s\S]*?)\s*$/);
                      if (ao) return ao[0x0]['length'], aq['processingInstruction'](ao[0x1], ao[0x2]), ar + 0x2;
                    }
                    return -0x1;
                  }(Q, ab, X);
                  break;
                case '!':
                  a5 && a1(ab), ac = function (ao, ap, aq, ar) {
                    var as, at;
                    return '-' === ao['charAt'](ap + 0x2) ? '-' === ao['charAt'](ap + 0x3) ? (at = ao['indexOf']('-->', ap + 0x4), ap < at ? (aq['comment'](ao, ap + 0x4, at - ap - 0x4), at + 0x3) : (ar['error']('Unclosed\x20comment'), -0x1)) : -0x1 : 'CDATA[' == ao['substr'](ap + 0x3, 0x6) ? (at = ao['indexOf'](']]>', ap + 0x9), aq['startCDATA'](), aq['characters'](ao, ap + 0x9, at - ap - 0x9), aq['endCDATA'](), at + 0x3) : 0x1 < (at = (ar = function (au, av) {
                      var aw,
                        ax = [],
                        ay = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;
                      for (ay['lastIndex'] = av, ay['exec'](au); aw = ay['exec'](au);) if (ax['push'](aw), aw[0x1]) return ax;
                    }(ao, ap))['length']) && /!doctype/i['test'](ar[0x0][0x0]) ? (ao = ar[0x1][0x0], ap = 0x3 < at && /^public$/i['test'](ar[0x2][0x0]) && ar[0x3][0x0], as = 0x4 < at && ar[0x4][0x0], ar = ar[at - 0x1], aq['startDTD'](ao, ap && ap['replace'](/^(['"])(.*?)\1$/, '$2'), as && as['replace'](/^(['"])(.*?)\1$/, '$2')), aq['endDTD'](), ar['index'] + ar[0x0]['length']) : -0x1;
                  }(Q, ab, X, Y);
                  break;
                default:
                  a5 && a1(ab);
                  var ai = new G(),
                    aj = a6[a6['length'] - 0x1]['currentNSMap'],
                    ac = function (ao, ap, aq, ar, as, at) {
                      for (var au, av = ++ap, aw = k;;) {
                        var ax = ao['charAt'](av);
                        switch (ax) {
                          case '=':
                            if (aw === l) au = ao['slice'](ap, av);else {
                              if (aw !== m) throw new Error('attribute\x20equal\x20must\x20after\x20attrName');
                            }
                            aw = q;
                            break;
                          case '\x27':
                          case '\x22':
                            if (aw === q || aw === l) {
                              if (aw === l && (at['warning']('attribute\x20value\x20must\x20after\x20\x22=\x22'), au = ao['slice'](ap, av)), ap = av + 0x1, !(0x0 < (av = ao['indexOf'](ax, ap)))) throw new Error('attribute\x20value\x20no\x20end\x20\x27' + ax + '\x27\x20match');
                              ay = ao['slice'](ap, av)['replace'](/&#?\w+;/g, as), aq['add'](au, ay, ap - 0x1);
                            } else {
                              if (aw != s) throw new Error('attribute\x20value\x20must\x20after\x20\x22=\x22');
                              ay = ao['slice'](ap, av)['replace'](/&#?\w+;/g, as), aq['add'](au, ay, ap), at['warning']('attribute\x20\x22' + au + '\x22\x20missed\x20start\x20quot(' + ax + ')!!'), ap = av + 0x1;
                            }
                            aw = u;
                            break;
                          case '/':
                            switch (aw) {
                              case k:
                                aq['setTagName'](ao['slice'](ap, av));
                              case u:
                              case v:
                              case w:
                                aw = w, aq['closed'] = !0x0;
                              case s:
                              case l:
                              case m:
                                break;
                              default:
                                throw new Error('attribute\x20invalid\x20close\x20char(\x27/\x27)');
                            }
                            break;
                          case '':
                            return at['error']('unexpected\x20end\x20of\x20input'), aw == k && aq['setTagName'](ao['slice'](ap, av)), av;
                          case '>':
                            switch (aw) {
                              case k:
                                aq['setTagName'](ao['slice'](ap, av));
                              case u:
                              case v:
                              case w:
                                break;
                              case s:
                              case l:
                                '/' === (ay = ao['slice'](ap, av))['slice'](-0x1) && (aq['closed'] = !0x0, ay = ay['slice'](0x0, -0x1));
                              case m:
                                aw === m && (ay = au), aw == s ? (at['warning']('attribute\x20\x22' + ay + '\x22\x20missed\x20quot(\x22)!!'), aq['add'](au, ay['replace'](/&#?\w+;/g, as), ap)) : ('http://www.w3.org/1999/xhtml' === ar[''] && ay['match'](/^(?:disabled|checked|selected)$/i) || at['warning']('attribute\x20\x22' + ay + '\x22\x20missed\x20value!!\x20\x22' + ay + '\x22\x20instead!!'), aq['add'](ay, ay, ap));
                                break;
                              case q:
                                throw new Error('attribute\x20value\x20missed!!');
                            }
                            return av;
                          case "\x80":
                            ax = '\x20';
                          default:
                            if (ax <= '\x20') switch (aw) {
                              case k:
                                aq['setTagName'](ao['slice'](ap, av)), aw = v;
                                break;
                              case l:
                                au = ao['slice'](ap, av), aw = m;
                                break;
                              case s:
                                var ay = ao['slice'](ap, av)['replace'](/&#?\w+;/g, as);
                                at['warning']('attribute\x20\x22' + ay + '\x22\x20missed\x20quot(\x22)!!'), aq['add'](au, ay, ap);
                              case u:
                                aw = v;
                            } else switch (aw) {
                              case m:
                                aq['tagName'], ('http://www.w3.org/1999/xhtml' === ar[''] && au['match'](/^(?:disabled|checked|selected)$/i) || at['warning']('attribute\x20\x22' + au + '\x22\x20missed\x20value!!\x20\x22' + au + '\x22\x20instead2!!'), aq['add'](au, au, ap), ap = av, aw = l);
                                break;
                              case u:
                                at['warning']('attribute\x20space\x20is\x20required\x22' + au + '\x22!!');
                              case v:
                                aw = l, ap = av;
                                break;
                              case q:
                                aw = s, ap = av;
                                break;
                              case w:
                                throw new Error('elements\x20closed\x20character\x20\x27/\x27\x20and\x20\x27>\x27\x20must\x20be\x20connected\x20to');
                            }
                        }
                        av++;
                      }
                    }(Q, ab, ai, aj, Z, Y),
                    ak = ai['length'];
                  if (!ai['closed'] && function (ao, ap, aq, ar) {
                    var as = ar[aq];
                    return null == as && ((as = ao['lastIndexOf']('</' + aq + '>')) < ap && (as = ao['lastIndexOf']('</' + aq)), ar[aq] = as), as < ap;
                  }(Q, ac, ai['tagName'], a7) && (ai['closed'] = !0x0, W['nbsp'] || Y['warning']('unclosed\x20xml\x20attribute')), a5 && ak) {
                    for (var al = z(a5, {}), am = 0x0; am < ak; am++) {
                      var an = ai[am];
                      a1(an['offset']), an['locator'] = z(a5, {});
                    }
                    X['locator'] = al, A(ai, X, aj) && a6['push'](ai), X['locator'] = a5;
                  } else A(ai, X, aj) && a6['push'](ai);
                  'http://www.w3.org/1999/xhtml' !== ai['uri'] || ai['closed'] ? ac++ : ac = function (ao, ap, aq, ar, as) {
                    if (/^(?:script|textarea)$/i['test'](aq)) {
                      var at = ao['indexOf']('</' + aq + '>', ap),
                        ao = ao['substring'](ap + 0x1, at);
                      if (/[&<]/['test'](ao)) return /^script$/i['test'](aq) ? as['characters'](ao, 0x0, ao['length']) : (ao = ao['replace'](/&#?\w+;/g, ar), as['characters'](ao, 0x0, ao['length'])), at;
                    }
                    return ap + 0x1;
                  }(Q, ac, ai['tagName'], Z, X);
              }
            } catch (ao) {
              Y['error']('element\x20parse\x20error:\x20' + ao), ac = -0x1;
            }
            a8 < ac ? a8 = ac : a0(Math['max'](ab, a8) + 0x1);
          }
        }(J, K, N, O, this['errorHandler']), O['endDocument']();
      }
    }, G['prototype'] = {
      'setTagName': function setTagName(J) {
        if (!h['test'](J)) throw new Error('invalid\x20tagName:' + J);
        this['tagName'] = J;
      },
      'add': function add(J, K, N) {
        if (!h['test'](J)) throw new Error('invalid\x20attribute:' + J);
        this[this['length']++] = {
          'qName': J,
          'value': K,
          'offset': N
        };
      },
      'length': 0x0,
      'getLocalName': function getLocalName(J) {
        return this[J]['localName'];
      },
      'getLocator': function getLocator(J) {
        return this[J]['locator'];
      },
      'getQName': function getQName(J) {
        return this[J]['qName'];
      },
      'getURI': function getURI(J) {
        return this[J]['uri'];
      },
      'getValue': function getValue(J) {
        return this[J]['value'];
      }
    }, d['XMLReader'] = y;
  }, {}],
  0x5: [function (b, c, g) {
    function h(y) {
      return (h = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (z) {
        return _typeof(z);
      } : function (z) {
        return z && 'function' == typeof Symbol && z['constructor'] === Symbol && z !== Symbol['prototype'] ? 'symbol' : _typeof(z);
      })(y);
    }
    Object['defineProperty'](g, '__esModule', {
      'value': !0x0
    }), g['default'] = void 0x0, b = (b = b('./HTMLAudioElement')) && b['__esModule'] ? b : {
      'default': b
    };
    function j(y, z) {
      for (var A = 0x0; A < z['length']; A++) {
        var B = z[A];
        B['enumerable'] = B['enumerable'] || !0x1, B['configurable'] = !0x0, 'value' in B && (B['writable'] = !0x0), Object['defineProperty'](y, function (C) {
          return C = function (D, E) {
            if ('object' != h(D) || !D) return D;
            var F = D[Symbol['toPrimitive']];
            if (void 0x0 === F) return ('string' === E ? String : Number)(D);
            if ('object' != h(F = F['call'](D, E || 'default'))) return F;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(C, 'string'), 'symbol' == h(C) ? C : C + '';
        }(B['key']), B);
      }
    }
    function k(y, z, A) {
      z = q(z);
      var B = y,
        z = m() ? Reflect['construct'](z, A || [], q(y)['constructor']) : z['apply'](y, A);
      if (!z || 'object' != h(z) && 'function' != typeof z) {
        if (void 0x0 !== z) throw new TypeError('Derived\x20constructors\x20may\x20only\x20return\x20object\x20or\x20undefined');
        if (void 0x0 === (z = B)) throw new ReferenceError('this\x20hasn\x27t\x20been\x20initialised\x20-\x20super()\x20hasn\x27t\x20been\x20called');
      }
      return z;
    }
    function m() {
      try {
        var y = !Boolean['prototype']['valueOf']['call'](Reflect['construct'](Boolean, [], function () {}));
      } catch (z) {}
      return (m = function m() {
        return !!y;
      })();
    }
    function p() {
      return (p = 'undefined' != typeof Reflect && Reflect['get'] ? Reflect['get']['bind']() : function (y, z, A) {
        var B = function (C, D) {
          for (; !{}['hasOwnProperty']['call'](C, D) && null !== (C = q(C)););
          return C;
        }(y, z);
        if (B) return (B = Object['getOwnPropertyDescriptor'](B, z))['get'] ? B['get']['call'](arguments['length'] < 0x3 ? y : A) : B['value'];
      })['apply'](null, arguments);
    }
    function q(y) {
      return (q = Object['setPrototypeOf'] ? Object['getPrototypeOf']['bind']() : function (z) {
        return z['__proto__'] || Object['getPrototypeOf'](z);
      })(y);
    }
    function v(y, z) {
      return (v = Object['setPrototypeOf'] ? Object['setPrototypeOf']['bind']() : function (A, B) {
        return A['__proto__'] = B, A;
      })(y, z);
    }
    var w = 0x1,
      x = {};
    g['default'] = function (y) {
      function z(C) {
        var D;
        if (!(this instanceof z)) throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
        (D = k(this, z))['_$sn'] = w++, D['HAVE_NOTHING'] = 0x0, D['HAVE_METADATA'] = 0x1, D['HAVE_CURRENT_DATA'] = 0x2, D['HAVE_FUTURE_DATA'] = 0x3, D['HAVE_ENOUGH_DATA'] = 0x4, D['readyState'] = 0x0;
        var E = wx['createInnerAudioContext']();
        return x[D['_$sn']] = E, D['_canplayEvents'] = ['load', 'loadend', 'canplay', 'canplaythrough', 'loadedmetadata'], E['onCanplay'](function () {
          D['_loaded'] = !0x0, D['readyState'] = D['HAVE_CURRENT_DATA'], D['_canplayEvents']['forEach'](function (F) {
            D['dispatchEvent']({
              'type': F
            });
          });
        }), E['onPlay'](function () {
          D['_paused'] = x[D['_$sn']]['paused'], D['dispatchEvent']({
            'type': 'play'
          });
        }), E['onPause'](function () {
          D['_paused'] = x[D['_$sn']]['paused'], D['dispatchEvent']({
            'type': 'pause'
          });
        }), E['onEnded'](function () {
          D['_paused'] = x[D['_$sn']]['paused'], !0x1 === x[D['_$sn']]['loop'] && D['dispatchEvent']({
            'type': 'ended'
          }), D['readyState'] = 0x4;
        }), E['onError'](function () {
          D['_paused'] = x[D['_$sn']]['paused'], D['dispatchEvent']({
            'type': 'error'
          });
        }), C ? D['src'] = C : D['_src'] = '', D['_loop'] = E['loop'], D['_autoplay'] = E['autoplay'], D['_paused'] = E['paused'], D['_volume'] = E['volume'], D['_muted'] = !0x1, D;
      }
      var A,
        B = z;
      if ('function' != typeof y && null !== y) throw new TypeError('Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function');
      return B['prototype'] = Object['create'](y && y['prototype'], {
        'constructor': {
          'value': B,
          'writable': !0x0,
          'configurable': !0x0
        }
      }), Object['defineProperty'](B, 'prototype', {
        'writable': !0x1
      }), y && v(B, y), B = z, (y = [{
        'key': 'addEventListener',
        'value': function value(C, D) {
          var E,
            F,
            G,
            H,
            I,
            J = 0x2 < arguments['length'] && void 0x0 !== arguments[0x2] ? arguments[0x2] : {};
          E = z, F = 'addEventListener', G = this, I = p(q(0x1 & (H = 0x3) ? E['prototype'] : E), F, G), (0x2 & H && 'function' == typeof I ? function (K) {
            return I['apply'](G, K);
          } : I)([C, D, J]), C = String(C)['toLowerCase'](), this['_loaded'] && -0x1 !== this['_canplayEvents']['indexOf'](C) && this['dispatchEvent']({
            'type': C
          });
        }
      }, {
        'key': 'load',
        'value': function value() {}
      }, {
        'key': 'play',
        'value': function value() {
          x[this['_$sn']]['play']();
        }
      }, {
        'key': 'resume',
        'value': function value() {
          x[this['_$sn']]['resume']();
        }
      }, {
        'key': 'pause',
        'value': function value() {
          x[this['_$sn']]['pause']();
        }
      }, {
        'key': 'stop',
        'value': function value() {
          x[this['_$sn']]['stop']();
        }
      }, {
        'key': 'destroy',
        'value': function value() {
          x[this['_$sn']]['destroy']();
        }
      }, {
        'key': 'canPlayType',
        'value': function value() {
          var C = 0x0 < arguments['length'] && void 0x0 !== arguments[0x0] ? arguments[0x0] : '';
          return 'string' == typeof C && (-0x1 < C['indexOf']('audio/mpeg') || C['indexOf']('audio/mp4')) ? 'probably' : '';
        }
      }, {
        'key': 'currentTime',
        'get': function get() {
          return x[this['_$sn']]['currentTime'];
        },
        'set': function set(C) {
          x[this['_$sn']]['seek'](C);
        }
      }, {
        'key': 'duration',
        'get': function get() {
          return x[this['_$sn']]['duration'];
        }
      }, {
        'key': 'src',
        'get': function get() {
          return this['_src'];
        },
        'set': function set(C) {
          this['_src'] = C, this['_loaded'] = !0x1, this['readyState'] = this['HAVE_NOTHING'], x[this['_$sn']]['src'] = C;
        }
      }, {
        'key': 'loop',
        'get': function get() {
          return this['_loop'];
        },
        'set': function set(C) {
          this['_loop'] = C, x[this['_$sn']]['loop'] = C;
        }
      }, {
        'key': 'autoplay',
        'get': function get() {
          return this['autoplay'];
        },
        'set': function set(C) {
          this['_autoplay'] = C, x[this['_$sn']]['autoplay'] = C;
        }
      }, {
        'key': 'paused',
        'get': function get() {
          return this['_paused'];
        }
      }, {
        'key': 'volume',
        'get': function get() {
          return this['_volume'];
        },
        'set': function set(C) {
          this['_volume'] = C, this['_muted'] || (x[this['_$sn']]['volume'] = C);
        }
      }, {
        'key': 'muted',
        'get': function get() {
          return this['_muted'];
        },
        'set': function set(C) {
          this['_muted'] = C, x[this['_$sn']]['volume'] = C ? 0x0 : this['_volume'];
        }
      }, {
        'key': 'cloneNode',
        'value': function value() {
          var C = new z();
          return C['loop'] = this['loop'], C['autoplay'] = this['autoplay'], C['src'] = this['src'], C;
        }
      }]) && j(B['prototype'], y), A && j(B, A), Object['defineProperty'](B, 'prototype', {
        'writable': !0x1
      }), B;
    }(b['default']);
  }, {
    './HTMLAudioElement': 0xd
  }],
  0x6: [function (a, b, c) {
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = function () {
      var f = wx['createCanvas']();
      return f['type'] = 'canvas', (f['getBoundingClientRect'] = function () {
        return {
          'top': 0x0,
          'left': 0x0,
          'width': window['innerWidth'],
          'height': window['innerHeight']
        };
      }, f['style'] = {
        'top': '0px',
        'left': '0px',
        'width': ''['concat'](d['innerWidth'], 'px'),
        'height': ''['concat'](d['innerHeight'], 'px')
      }, f['addEventListener'] = function (g, h) {
        var i = 0x2 < arguments['length'] && void 0x0 !== arguments[0x2] ? arguments[0x2] : {};
        ('function' == typeof getApp ? GameGlobal['document'] : document)['addEventListener'](g, h, i);
      }, f['removeEventListener'] = function (g, h) {
        ('function' == typeof getApp ? GameGlobal['document'] : document)['removeEventListener'](g, h);
      }, f['dispatchEvent'] = function () {
        var g = 0x0 < arguments['length'] && void 0x0 !== arguments[0x0] ? arguments[0x0] : {};
        console['log']('canvas.dispatchEvent', g['type'], g);
      }, Object['defineProperty'](f, 'clientWidth', {
        'enumerable': !0x0,
        'get': function get() {
          return d['innerWidth'];
        }
      }), Object['defineProperty'](f, 'clientHeight', {
        'enumerable': !0x0,
        'get': function get() {
          return d['innerHeight'];
        }
      }), f);
    };
    var d = a('./WindowProperties');
  }, {
    './WindowProperties': 0x18
  }],
  0x7: [function (b, d, g) {
    Object['defineProperty'](g, '__esModule', {
      'value': !0x0
    }), g['default'] = void 0x0, b = (b = b('./Node')) && b['__esModule'] ? b : {
      'default': b
    };
    function h(x) {
      return (h = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (y) {
        return _typeof(y);
      } : function (y) {
        return y && 'function' == typeof Symbol && y['constructor'] === Symbol && y !== Symbol['prototype'] ? 'symbol' : _typeof(y);
      })(x);
    }
    function j(x, y) {
      for (var z = 0x0; z < y['length']; z++) {
        var A = y[z];
        A['enumerable'] = A['enumerable'] || !0x1, A['configurable'] = !0x0, 'value' in A && (A['writable'] = !0x0), Object['defineProperty'](x, w(A['key']), A);
      }
    }
    function k(x, y, z) {
      y = p(y);
      var A = x,
        y = m() ? Reflect['construct'](y, z || [], p(x)['constructor']) : y['apply'](x, z);
      if (!y || 'object' != h(y) && 'function' != typeof y) {
        if (void 0x0 !== y) throw new TypeError('Derived\x20constructors\x20may\x20only\x20return\x20object\x20or\x20undefined');
        if (void 0x0 === (y = A)) throw new ReferenceError('this\x20hasn\x27t\x20been\x20initialised\x20-\x20super()\x20hasn\x27t\x20been\x20called');
      }
      return y;
    }
    function m() {
      try {
        var x = !Boolean['prototype']['valueOf']['call'](Reflect['construct'](Boolean, [], function () {}));
      } catch (y) {}
      return (m = function m() {
        return !!x;
      })();
    }
    function p(x) {
      return (p = Object['setPrototypeOf'] ? Object['getPrototypeOf']['bind']() : function (y) {
        return y['__proto__'] || Object['getPrototypeOf'](y);
      })(x);
    }
    function q(x, y) {
      return (q = Object['setPrototypeOf'] ? Object['setPrototypeOf']['bind']() : function (z, A) {
        return z['__proto__'] = A, z;
      })(x, y);
    }
    function v(x, y, z) {
      (y = w(y)) in x ? Object['defineProperty'](x, y, {
        'value': z,
        'enumerable': !0x0,
        'configurable': !0x0,
        'writable': !0x0
      }) : x[y] = z;
    }
    function w(x) {
      return x = function (y, z) {
        if ('object' != h(y) || !y) return y;
        var A = y[Symbol['toPrimitive']];
        if (void 0x0 === A) return ('string' === z ? String : Number)(y);
        if ('object' != h(A = A['call'](y, z || 'default'))) return A;
        throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
      }(x, 'string'), 'symbol' == h(x) ? x : x + '';
    }
    g['default'] = function (x) {
      function y() {
        var C;
        if (this instanceof y) return v(C = k(this, y), 'className', ''), v(C, 'children', []), C;
        throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      }
      var z,
        A,
        B = y;
      if ('function' != typeof x && null !== x) throw new TypeError('Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function');
      return B['prototype'] = Object['create'](x && x['prototype'], {
        'constructor': {
          'value': B,
          'writable': !0x0,
          'configurable': !0x0
        }
      }), Object['defineProperty'](B, 'prototype', {
        'writable': !0x1
      }), x && q(B, x), B = y, z && j(B['prototype'], z), A && j(B, A), Object['defineProperty'](B, 'prototype', {
        'writable': !0x1
      }), B;
    }(b['default']);
  }, {
    './Node': 0x15
  }],
  0x8: [function (a, b, c) {
    function d(h) {
      return (d = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (j) {
        return _typeof(j);
      } : function (j) {
        return j && 'function' == typeof Symbol && j['constructor'] === Symbol && j !== Symbol['prototype'] ? 'symbol' : _typeof(j);
      })(h);
    }
    function f(h, j) {
      for (var k = 0x0; k < j['length']; k++) {
        var l = j[k];
        l['enumerable'] = l['enumerable'] || !0x1, l['configurable'] = !0x0, 'value' in l && (l['writable'] = !0x0), Object['defineProperty'](h, function (m) {
          return m = function (p, q) {
            if ('object' != d(p) || !p) return p;
            var s = p[Symbol['toPrimitive']];
            if (void 0x0 === s) return ('string' === q ? String : Number)(p);
            if ('object' != d(s = s['call'](p, q || 'default'))) return s;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(m, 'string'), 'symbol' == d(m) ? m : m + '';
        }(l['key']), l);
      }
    }
    function g(h, j, k) {
      return j && f(h['prototype'], j), k && f(h, k), Object['defineProperty'](h, 'prototype', {
        'writable': !0x1
      }), h;
    }
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = void 0x0, c['default'] = g(function h() {
      if (!(this instanceof h)) throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
    });
  }, {}],
  0x9: [function (b, d, f) {
    Object['defineProperty'](f, '__esModule', {
      'value': !0x0
    }), f['default'] = void 0x0;
    var g = b('../util/index.js');
    function h(w) {
      return (h = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (x) {
        return _typeof(x);
      } : function (x) {
        return x && 'function' == typeof Symbol && x['constructor'] === Symbol && x !== Symbol['prototype'] ? 'symbol' : _typeof(x);
      })(w);
    }
    function j(w, x) {
      for (var y = 0x0; y < x['length']; y++) {
        var z = x[y];
        z['enumerable'] = z['enumerable'] || !0x1, z['configurable'] = !0x0, 'value' in z && (z['writable'] = !0x0), Object['defineProperty'](w, p(z['key']), z);
      }
    }
    function k(w, x, y) {
      return x && j(w['prototype'], x), y && j(w, y), Object['defineProperty'](w, 'prototype', {
        'writable': !0x1
      }), w;
    }
    function m(w, x, y) {
      (x = p(x)) in w ? Object['defineProperty'](w, x, {
        'value': y,
        'enumerable': !0x0,
        'configurable': !0x0,
        'writable': !0x0
      }) : w[x] = y;
    }
    function p(w) {
      return w = function (x, y) {
        if ('object' != h(x) || !x) return x;
        var z = x[Symbol['toPrimitive']];
        if (void 0x0 === z) return ('string' === y ? String : Number)(x);
        if ('object' != h(z = z['call'](x, y || 'default'))) return z;
        throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
      }(w, 'string'), 'symbol' == h(w) ? w : w + '';
    }
    var q = f['default'] = k(function w(x) {
      if (!(this instanceof w)) throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      m(this, 'touches', []), m(this, 'targetTouches', []), m(this, 'changedTouches', []), m(this, 'preventDefault', g['noop']), m(this, 'stopPropagation', g['noop']), this['type'] = x, this['target'] = window['canvas'], this['currentTarget'] = window['canvas'];
    });
    function v(x) {
      return function (y) {
        var z = new q(x);
        z['touches'] = y['touches'], z['targetTouches'] = Array['prototype']['slice']['call'](y['touches']), z['changedTouches'] = y['changedTouches'], z['timeStamp'] = y['timeStamp'], ('function' == typeof getApp ? GameGlobal['document'] : document)['dispatchEvent'](z);
      };
    }
    wx['onTouchStart'](v('touchstart')), wx['onTouchMove'](v('touchmove')), wx['onTouchEnd'](v('touchend')), wx['onTouchCancel'](v('touchcancel'));
  }, {
    '../util/index.js': 0x1f
  }],
  0xa: [function (a, b, c) {
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), Object['defineProperty'](c, 'MouseEvent', {
      'enumerable': !0x0,
      'get': function get() {
        return f['default'];
      }
    }), Object['defineProperty'](c, 'TouchEvent', {
      'enumerable': !0x0,
      'get': function get() {
        return d['default'];
      }
    });
    var d = g(a('./TouchEvent')),
      f = g(a('./MouseEvent'));
    function g(h) {
      return h && h['__esModule'] ? h : {
        'default': h
      };
    }
  }, {
    './MouseEvent': 0x8,
    './TouchEvent': 0x9
  }],
  0xb: [function (b, c, d) {
    function f(j) {
      return (f = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (k) {
        return _typeof(k);
      } : function (k) {
        return k && 'function' == typeof Symbol && k['constructor'] === Symbol && k !== Symbol['prototype'] ? 'symbol' : _typeof(k);
      })(j);
    }
    function g(j, k) {
      for (var l = 0x0; l < k['length']; l++) {
        var m = k[l];
        m['enumerable'] = m['enumerable'] || !0x1, m['configurable'] = !0x0, 'value' in m && (m['writable'] = !0x0), Object['defineProperty'](j, function (p) {
          return p = function (q, s) {
            if ('object' != f(q) || !q) return q;
            var u = q[Symbol['toPrimitive']];
            if (void 0x0 === u) return ('string' === s ? String : Number)(q);
            if ('object' != f(u = u['call'](q, s || 'default'))) return u;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(p, 'string'), 'symbol' == f(p) ? p : p + '';
        }(m['key']), m);
      }
    }
    Object['defineProperty'](d, '__esModule', {
      'value': !0x0
    }), d['default'] = void 0x0;
    var h = new WeakMap();
    d['default'] = function () {
      function j() {
        if (!(this instanceof j)) throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
        h['set'](this, {});
      }
      return k = j, (l = [{
        'key': 'addEventListener',
        'value': function value(p, q) {
          var s = 0x2 < arguments['length'] && void 0x0 !== arguments[0x2] ? arguments[0x2] : {},
            u = h['get'](this);
          u || h['set'](this, u = {}), u[p] || (u[p] = []), u[p]['push'](q), s['capture'], s['once'], s['passive'];
        }
      }, {
        'key': 'removeEventListener',
        'value': function value(p, q) {
          var s = h['get'](this);
          if (s) {
            var u = s[p];
            if (u && 0x0 < u['length']) {
              for (var v = u['length']; v--;) if (u[v] === q) {
                u['splice'](v, 0x1);
                break;
              }
            }
          }
        }
      }, {
        'key': 'dispatchEvent',
        'value': function value() {
          var p = 0x0 < arguments['length'] && void 0x0 !== arguments[0x0] ? arguments[0x0] : {},
            q = h['get'](this)[p['type']];
          if (q) {
            for (var s = 0x0; s < q['length']; s++) q[s](p);
          }
        }
      }]) && g(k['prototype'], l), m && g(k, m), Object['defineProperty'](k, 'prototype', {
        'writable': !0x1
      }), k;
      var k, l, m;
    }();
  }, {}],
  0xc: [function (a, b, c) {
    function d(g) {
      return (d = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (h) {
        return _typeof(h);
      } : function (h) {
        return h && 'function' == typeof Symbol && h['constructor'] === Symbol && h !== Symbol['prototype'] ? 'symbol' : _typeof(h);
      })(g);
    }
    function f(g, h) {
      for (var j = 0x0; j < h['length']; j++) {
        var k = h[j];
        k['enumerable'] = k['enumerable'] || !0x1, k['configurable'] = !0x0, 'value' in k && (k['writable'] = !0x0), Object['defineProperty'](g, function (l) {
          return l = function (m, p) {
            if ('object' != d(m) || !m) return m;
            var q = m[Symbol['toPrimitive']];
            if (void 0x0 === q) return ('string' === p ? String : Number)(m);
            if ('object' != d(q = q['call'](m, p || 'default'))) return q;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(l, 'string'), 'symbol' == d(l) ? l : l + '';
        }(k['key']), k);
      }
    }
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = void 0x0, c['default'] = function () {
      function g() {
        if (!(this instanceof g)) throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      }
      return h = g, (j = [{
        'key': 'construct',
        'value': function value() {}
      }]) && f(h['prototype'], j), k && f(h, k), Object['defineProperty'](h, 'prototype', {
        'writable': !0x1
      }), h;
      var h, j, k;
    }();
  }, {}],
  0xd: [function (b, d, f) {
    function g(q) {
      return (g = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (s) {
        return _typeof(s);
      } : function (s) {
        return s && 'function' == typeof Symbol && s['constructor'] === Symbol && s !== Symbol['prototype'] ? 'symbol' : _typeof(s);
      })(q);
    }
    Object['defineProperty'](f, '__esModule', {
      'value': !0x0
    }), f['default'] = void 0x0, b = (b = b('./HTMLMediaElement')) && b['__esModule'] ? b : {
      'default': b
    };
    function h(q, s) {
      for (var v = 0x0; v < s['length']; v++) {
        var w = s[v];
        w['enumerable'] = w['enumerable'] || !0x1, w['configurable'] = !0x0, 'value' in w && (w['writable'] = !0x0), Object['defineProperty'](q, function (x) {
          return x = function (y, z) {
            if ('object' != g(y) || !y) return y;
            var A = y[Symbol['toPrimitive']];
            if (void 0x0 === A) return ('string' === z ? String : Number)(y);
            if ('object' != g(A = A['call'](y, z || 'default'))) return A;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(x, 'string'), 'symbol' == g(x) ? x : x + '';
        }(w['key']), w);
      }
    }
    function j(q, s, v) {
      s = m(s);
      var w = q,
        s = k() ? Reflect['construct'](s, v || [], m(q)['constructor']) : s['apply'](q, v);
      if (!s || 'object' != g(s) && 'function' != typeof s) {
        if (void 0x0 !== s) throw new TypeError('Derived\x20constructors\x20may\x20only\x20return\x20object\x20or\x20undefined');
        if (void 0x0 === (s = w)) throw new ReferenceError('this\x20hasn\x27t\x20been\x20initialised\x20-\x20super()\x20hasn\x27t\x20been\x20called');
      }
      return s;
    }
    function k() {
      try {
        var q = !Boolean['prototype']['valueOf']['call'](Reflect['construct'](Boolean, [], function () {}));
      } catch (s) {}
      return (k = function k() {
        return !!q;
      })();
    }
    function m(q) {
      return (m = Object['setPrototypeOf'] ? Object['getPrototypeOf']['bind']() : function (s) {
        return s['__proto__'] || Object['getPrototypeOf'](s);
      })(q);
    }
    function p(q, s) {
      return (p = Object['setPrototypeOf'] ? Object['setPrototypeOf']['bind']() : function (v, w) {
        return v['__proto__'] = w, v;
      })(q, s);
    }
    f['default'] = function (q) {
      function s() {
        if (this instanceof s) return j(this, s, ['audio']);
        throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      }
      var v,
        w,
        x = s;
      if ('function' != typeof q && null !== q) throw new TypeError('Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function');
      return x['prototype'] = Object['create'](q && q['prototype'], {
        'constructor': {
          'value': x,
          'writable': !0x0,
          'configurable': !0x0
        }
      }), Object['defineProperty'](x, 'prototype', {
        'writable': !0x1
      }), q && p(x, q), x = s, v && h(x['prototype'], v), w && h(x, w), Object['defineProperty'](x, 'prototype', {
        'writable': !0x1
      }), x;
    }(b['default']);
  }, {
    './HTMLMediaElement': 0x11
  }],
  0xe: [function (a, b, c) {
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = void 0x0, a = (a = a('./Canvas')) && a['__esModule'] ? a : {
      'default': a
    }, GameGlobal['screencanvas'] = GameGlobal['screencanvas'] || new a['default'](), a = GameGlobal['screencanvas']['constructor'], c['default'] = a;
  }, {
    './Canvas': 0x6
  }],
  0xf: [function (b, g, h) {
    Object['defineProperty'](h, '__esModule', {
      'value': !0x0
    }), h['default'] = void 0x0;
    var j = (j = b('./Element')) && j['__esModule'] ? j : {
        'default': j
      },
      k = b('./util/index.js'),
      m = b('./WindowProperties');
    function q(C) {
      return (q = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (D) {
        return _typeof(D);
      } : function (D) {
        return D && 'function' == typeof Symbol && D['constructor'] === Symbol && D !== Symbol['prototype'] ? 'symbol' : _typeof(D);
      })(C);
    }
    function v(C, D) {
      for (var E = 0x0; E < D['length']; E++) {
        var F = D[E];
        F['enumerable'] = F['enumerable'] || !0x1, F['configurable'] = !0x0, 'value' in F && (F['writable'] = !0x0), Object['defineProperty'](C, B(F['key']), F);
      }
    }
    function w(C, D, E) {
      D = y(D);
      var F = C,
        D = x() ? Reflect['construct'](D, E || [], y(C)['constructor']) : D['apply'](C, E);
      if (!D || 'object' != q(D) && 'function' != typeof D) {
        if (void 0x0 !== D) throw new TypeError('Derived\x20constructors\x20may\x20only\x20return\x20object\x20or\x20undefined');
        if (void 0x0 === (D = F)) throw new ReferenceError('this\x20hasn\x27t\x20been\x20initialised\x20-\x20super()\x20hasn\x27t\x20been\x20called');
      }
      return D;
    }
    function x() {
      try {
        var C = !Boolean['prototype']['valueOf']['call'](Reflect['construct'](Boolean, [], function () {}));
      } catch (D) {}
      return (x = function x() {
        return !!C;
      })();
    }
    function y(C) {
      return (y = Object['setPrototypeOf'] ? Object['getPrototypeOf']['bind']() : function (D) {
        return D['__proto__'] || Object['getPrototypeOf'](D);
      })(C);
    }
    function z(C, D) {
      return (z = Object['setPrototypeOf'] ? Object['setPrototypeOf']['bind']() : function (E, F) {
        return E['__proto__'] = F, E;
      })(C, D);
    }
    function A(C, D, E) {
      (D = B(D)) in C ? Object['defineProperty'](C, D, {
        'value': E,
        'enumerable': !0x0,
        'configurable': !0x0,
        'writable': !0x0
      }) : C[D] = E;
    }
    function B(C) {
      return C = function (D, E) {
        if ('object' != q(D) || !D) return D;
        var F = D[Symbol['toPrimitive']];
        if (void 0x0 === F) return ('string' === E ? String : Number)(D);
        if ('object' != q(F = F['call'](D, E || 'default'))) return F;
        throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
      }(C, 'string'), 'symbol' == q(C) ? C : C + '';
    }
    h['default'] = function (C) {
      function D() {
        var G = 0x0 < arguments['length'] && void 0x0 !== arguments[0x0] ? arguments[0x0] : '',
          H = this,
          I = D;
        if (H instanceof I) return A(H = w(this, D), 'className', ''), A(H, 'childern', []), A(H, 'style', {
          'width': ''['concat'](m['innerWidth'], 'px'),
          'height': ''['concat'](m['innerHeight'], 'px')
        }), A(H, 'insertBefore', k['noop']), A(H, 'innerHTML', ''), H['tagName'] = G['toUpperCase'](), H;
        throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      }
      var E,
        F = D;
      if ('function' != typeof C && null !== C) throw new TypeError('Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function');
      return F['prototype'] = Object['create'](C && C['prototype'], {
        'constructor': {
          'value': F,
          'writable': !0x0,
          'configurable': !0x0
        }
      }), Object['defineProperty'](F, 'prototype', {
        'writable': !0x1
      }), C && z(F, C), F = D, (C = [{
        'key': 'setAttribute',
        'value': function value(G, H) {
          this[G] = H;
        }
      }, {
        'key': 'getAttribute',
        'value': function value(G) {
          return this[G];
        }
      }, {
        'key': 'clientWidth',
        'get': function get() {
          var G = parseInt(this['style']['fontSize'], 0xa) * this['innerHTML']['length'];
          return Number['isNaN'](G) ? 0x0 : G;
        }
      }, {
        'key': 'clientHeight',
        'get': function get() {
          var G = parseInt(this['style']['fontSize'], 0xa);
          return Number['isNaN'](G) ? 0x0 : G;
        }
      }, {
        'key': 'getBoundingClientRect',
        'value': function value() {
          return {
            'top': 0x0,
            'left': 0x0,
            'width': m['innerWidth'],
            'height': m['innerHeight']
          };
        }
      }, {
        'key': 'focus',
        'value': function value() {}
      }]) && v(F['prototype'], C), E && v(F, E), Object['defineProperty'](F, 'prototype', {
        'writable': !0x1
      }), F;
    }(j['default']);
  }, {
    './Element': 0x7,
    './WindowProperties': 0x18,
    './util/index.js': 0x1f
  }],
  0x10: [function (a, b, c) {
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = void 0x0;
    var d = wx['createImage']()['constructor'];
    c['default'] = d;
  }, {}],
  0x11: [function (b, d, f) {
    function g(q) {
      return (g = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (s) {
        return _typeof(s);
      } : function (s) {
        return s && 'function' == typeof Symbol && s['constructor'] === Symbol && s !== Symbol['prototype'] ? 'symbol' : _typeof(s);
      })(q);
    }
    Object['defineProperty'](f, '__esModule', {
      'value': !0x0
    }), f['default'] = void 0x0, b = (b = b('./HTMLElement')) && b['__esModule'] ? b : {
      'default': b
    };
    function h(q, s) {
      for (var v = 0x0; v < s['length']; v++) {
        var w = s[v];
        w['enumerable'] = w['enumerable'] || !0x1, w['configurable'] = !0x0, 'value' in w && (w['writable'] = !0x0), Object['defineProperty'](q, function (x) {
          return x = function (y, z) {
            if ('object' != g(y) || !y) return y;
            var A = y[Symbol['toPrimitive']];
            if (void 0x0 === A) return ('string' === z ? String : Number)(y);
            if ('object' != g(A = A['call'](y, z || 'default'))) return A;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(x, 'string'), 'symbol' == g(x) ? x : x + '';
        }(w['key']), w);
      }
    }
    function j(q, s, v) {
      s = m(s);
      var w = q,
        s = k() ? Reflect['construct'](s, v || [], m(q)['constructor']) : s['apply'](q, v);
      if (!s || 'object' != g(s) && 'function' != typeof s) {
        if (void 0x0 !== s) throw new TypeError('Derived\x20constructors\x20may\x20only\x20return\x20object\x20or\x20undefined');
        if (void 0x0 === (s = w)) throw new ReferenceError('this\x20hasn\x27t\x20been\x20initialised\x20-\x20super()\x20hasn\x27t\x20been\x20called');
      }
      return s;
    }
    function k() {
      try {
        var q = !Boolean['prototype']['valueOf']['call'](Reflect['construct'](Boolean, [], function () {}));
      } catch (s) {}
      return (k = function k() {
        return !!q;
      })();
    }
    function m(q) {
      return (m = Object['setPrototypeOf'] ? Object['getPrototypeOf']['bind']() : function (s) {
        return s['__proto__'] || Object['getPrototypeOf'](s);
      })(q);
    }
    function p(q, s) {
      return (p = Object['setPrototypeOf'] ? Object['setPrototypeOf']['bind']() : function (v, w) {
        return v['__proto__'] = w, v;
      })(q, s);
    }
    f['default'] = function (q) {
      function s(x) {
        if (this instanceof s) return j(this, s, [x]);
        throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      }
      var v,
        w = s;
      if ('function' != typeof q && null !== q) throw new TypeError('Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function');
      return w['prototype'] = Object['create'](q && q['prototype'], {
        'constructor': {
          'value': w,
          'writable': !0x0,
          'configurable': !0x0
        }
      }), Object['defineProperty'](w, 'prototype', {
        'writable': !0x1
      }), q && p(w, q), w = s, (q = [{
        'key': 'addTextTrack',
        'value': function value() {}
      }, {
        'key': 'captureStream',
        'value': function value() {}
      }, {
        'key': 'fastSeek',
        'value': function value() {}
      }, {
        'key': 'load',
        'value': function value() {}
      }, {
        'key': 'pause',
        'value': function value() {}
      }, {
        'key': 'play',
        'value': function value() {}
      }]) && h(w['prototype'], q), v && h(w, v), Object['defineProperty'](w, 'prototype', {
        'writable': !0x1
      }), w;
    }(b['default']);
  }, {
    './HTMLElement': 0xf
  }],
  0x12: [function (b, d, f) {
    function g(q) {
      return (g = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (s) {
        return _typeof(s);
      } : function (s) {
        return s && 'function' == typeof Symbol && s['constructor'] === Symbol && s !== Symbol['prototype'] ? 'symbol' : _typeof(s);
      })(q);
    }
    Object['defineProperty'](f, '__esModule', {
      'value': !0x0
    }), f['default'] = void 0x0, b = (b = b('./HTMLMediaElement')) && b['__esModule'] ? b : {
      'default': b
    };
    function h(q, s) {
      for (var v = 0x0; v < s['length']; v++) {
        var w = s[v];
        w['enumerable'] = w['enumerable'] || !0x1, w['configurable'] = !0x0, 'value' in w && (w['writable'] = !0x0), Object['defineProperty'](q, function (x) {
          return x = function (y, z) {
            if ('object' != g(y) || !y) return y;
            var A = y[Symbol['toPrimitive']];
            if (void 0x0 === A) return ('string' === z ? String : Number)(y);
            if ('object' != g(A = A['call'](y, z || 'default'))) return A;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(x, 'string'), 'symbol' == g(x) ? x : x + '';
        }(w['key']), w);
      }
    }
    function j(q, s, v) {
      s = m(s);
      var w = q,
        s = k() ? Reflect['construct'](s, v || [], m(q)['constructor']) : s['apply'](q, v);
      if (!s || 'object' != g(s) && 'function' != typeof s) {
        if (void 0x0 !== s) throw new TypeError('Derived\x20constructors\x20may\x20only\x20return\x20object\x20or\x20undefined');
        if (void 0x0 === (s = w)) throw new ReferenceError('this\x20hasn\x27t\x20been\x20initialised\x20-\x20super()\x20hasn\x27t\x20been\x20called');
      }
      return s;
    }
    function k() {
      try {
        var q = !Boolean['prototype']['valueOf']['call'](Reflect['construct'](Boolean, [], function () {}));
      } catch (s) {}
      return (k = function k() {
        return !!q;
      })();
    }
    function m(q) {
      return (m = Object['setPrototypeOf'] ? Object['getPrototypeOf']['bind']() : function (s) {
        return s['__proto__'] || Object['getPrototypeOf'](s);
      })(q);
    }
    function p(q, s) {
      return (p = Object['setPrototypeOf'] ? Object['setPrototypeOf']['bind']() : function (v, w) {
        return v['__proto__'] = w, v;
      })(q, s);
    }
    f['default'] = function (q) {
      function s() {
        if (this instanceof s) return j(this, s, ['video']);
        throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      }
      var v,
        w,
        x = s;
      if ('function' != typeof q && null !== q) throw new TypeError('Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function');
      return x['prototype'] = Object['create'](q && q['prototype'], {
        'constructor': {
          'value': x,
          'writable': !0x0,
          'configurable': !0x0
        }
      }), Object['defineProperty'](x, 'prototype', {
        'writable': !0x1
      }), q && p(x, q), x = s, v && h(x['prototype'], v), w && h(x, w), Object['defineProperty'](x, 'prototype', {
        'writable': !0x1
      }), x;
    }(b['default']);
  }, {
    './HTMLMediaElement': 0x11
  }],
  0x13: [function (a, b, c) {
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = function () {
      var d = wx['createImage']();
      return d['premultiplyAlpha'] = !0x1, d;
    };
  }, {}],
  0x14: [function (a, b, c) {
    function d(h) {
      return (d = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (j) {
        return _typeof(j);
      } : function (j) {
        return j && 'function' == typeof Symbol && j['constructor'] === Symbol && j !== Symbol['prototype'] ? 'symbol' : _typeof(j);
      })(h);
    }
    function f(h, j) {
      for (var k = 0x0; k < j['length']; k++) {
        var l = j[k];
        l['enumerable'] = l['enumerable'] || !0x1, l['configurable'] = !0x0, 'value' in l && (l['writable'] = !0x0), Object['defineProperty'](h, function (m) {
          return m = function (p, q) {
            if ('object' != d(p) || !p) return p;
            var s = p[Symbol['toPrimitive']];
            if (void 0x0 === s) return ('string' === q ? String : Number)(p);
            if ('object' != d(s = s['call'](p, q || 'default'))) return s;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(m, 'string'), 'symbol' == d(m) ? m : m + '';
        }(l['key']), l);
      }
    }
    function g(h, j, k) {
      return j && f(h['prototype'], j), k && f(h, k), Object['defineProperty'](h, 'prototype', {
        'writable': !0x1
      }), h;
    }
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = void 0x0, c['default'] = g(function h() {
      if (!(this instanceof h)) throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
    });
  }, {}],
  0x15: [function (b, d, f) {
    Object['defineProperty'](f, '__esModule', {
      'value': !0x0
    }), f['default'] = void 0x0, b = (b = b('./EventTarget.js')) && b['__esModule'] ? b : {
      'default': b
    };
    function g(s) {
      return (g = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (v) {
        return _typeof(v);
      } : function (v) {
        return v && 'function' == typeof Symbol && v['constructor'] === Symbol && v !== Symbol['prototype'] ? 'symbol' : _typeof(v);
      })(s);
    }
    function h(s, v) {
      for (var w = 0x0; w < v['length']; w++) {
        var x = v[w];
        x['enumerable'] = x['enumerable'] || !0x1, x['configurable'] = !0x0, 'value' in x && (x['writable'] = !0x0), Object['defineProperty'](s, q(x['key']), x);
      }
    }
    function j(s, v, w) {
      v = m(v);
      var x = s,
        v = k() ? Reflect['construct'](v, w || [], m(s)['constructor']) : v['apply'](s, w);
      if (!v || 'object' != g(v) && 'function' != typeof v) {
        if (void 0x0 !== v) throw new TypeError('Derived\x20constructors\x20may\x20only\x20return\x20object\x20or\x20undefined');
        if (void 0x0 === (v = x)) throw new ReferenceError('this\x20hasn\x27t\x20been\x20initialised\x20-\x20super()\x20hasn\x27t\x20been\x20called');
      }
      return v;
    }
    function k() {
      try {
        var s = !Boolean['prototype']['valueOf']['call'](Reflect['construct'](Boolean, [], function () {}));
      } catch (v) {}
      return (k = function k() {
        return !!s;
      })();
    }
    function m(s) {
      return (m = Object['setPrototypeOf'] ? Object['getPrototypeOf']['bind']() : function (v) {
        return v['__proto__'] || Object['getPrototypeOf'](v);
      })(s);
    }
    function p(s, v) {
      return (p = Object['setPrototypeOf'] ? Object['setPrototypeOf']['bind']() : function (w, x) {
        return w['__proto__'] = x, w;
      })(s, v);
    }
    function q(s) {
      return s = function (v, w) {
        if ('object' != g(v) || !v) return v;
        var x = v[Symbol['toPrimitive']];
        if (void 0x0 === x) return ('string' === w ? String : Number)(v);
        if ('object' != g(x = x['call'](v, w || 'default'))) return x;
        throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
      }(s, 'string'), 'symbol' == g(s) ? s : s + '';
    }
    f['default'] = function (s) {
      function v() {
        var y, z, A, B;
        if (this instanceof v) return y = j(this, v), z = y, B = [], (A = q(A = 'childNodes')) in z ? Object['defineProperty'](z, A, {
          'value': B,
          'enumerable': !0x0,
          'configurable': !0x0,
          'writable': !0x0
        }) : z[A] = B, y;
        throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      }
      var w,
        x = v;
      if ('function' != typeof s && null !== s) throw new TypeError('Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function');
      return x['prototype'] = Object['create'](s && s['prototype'], {
        'constructor': {
          'value': x,
          'writable': !0x0,
          'configurable': !0x0
        }
      }), Object['defineProperty'](x, 'prototype', {
        'writable': !0x1
      }), s && p(x, s), x = v, (s = [{
        'key': 'appendChild',
        'value': function value(y) {
          this['childNodes']['push'](y);
        }
      }, {
        'key': 'cloneNode',
        'value': function value() {
          var y = Object['create'](this);
          return Object['assign'](y, this), y;
        }
      }, {
        'key': 'removeChild',
        'value': function value(y) {
          var z = this['childNodes']['findIndex'](function (A) {
            return A === y;
          });
          return -0x1 < z ? this['childNodes']['splice'](z, 0x1) : null;
        }
      }]) && h(x['prototype'], s), w && h(x, w), Object['defineProperty'](x, 'prototype', {
        'writable': !0x1
      }), x;
    }(b['default']);
  }, {
    './EventTarget.js': 0xb
  }],
  0x16: [function (a, b, c) {
    function d(h) {
      return (d = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (j) {
        return _typeof(j);
      } : function (j) {
        return j && 'function' == typeof Symbol && j['constructor'] === Symbol && j !== Symbol['prototype'] ? 'symbol' : _typeof(j);
      })(h);
    }
    function f(h, j) {
      for (var k = 0x0; k < j['length']; k++) {
        var l = j[k];
        l['enumerable'] = l['enumerable'] || !0x1, l['configurable'] = !0x0, 'value' in l && (l['writable'] = !0x0), Object['defineProperty'](h, function (m) {
          return m = function (p, q) {
            if ('object' != d(p) || !p) return p;
            var s = p[Symbol['toPrimitive']];
            if (void 0x0 === s) return ('string' === q ? String : Number)(p);
            if ('object' != d(s = s['call'](p, q || 'default'))) return s;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(m, 'string'), 'symbol' == d(m) ? m : m + '';
        }(l['key']), l);
      }
    }
    function g(h, j, k) {
      return j && f(h['prototype'], j), k && f(h, k), Object['defineProperty'](h, 'prototype', {
        'writable': !0x1
      }), h;
    }
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = void 0x0, c = c['default'] = g(function h() {
      if (!(this instanceof h)) throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
    }), (c['ACTIVE_ATTRIBUTES'] = 0x8b89, c['ACTIVE_TEXTURE'] = 0x84e0, c['ACTIVE_UNIFORMS'] = 0x8b86, c['ALIASED_LINE_WIDTH_RANGE'] = 0x846e, c['ALIASED_POINT_SIZE_RANGE'] = 0x846d, c['ALPHA'] = 0x1906, c['ALPHA_BITS'] = 0xd55, c['ALWAYS'] = 0x207, c['ARRAY_BUFFER'] = 0x8892, c['ARRAY_BUFFER_BINDING'] = 0x8894, c['ATTACHED_SHADERS'] = 0x8b85, c['BACK'] = 0x405, c['BLEND'] = 0xbe2, c['BLEND_COLOR'] = 0x8005, c['BLEND_DST_ALPHA'] = 0x80ca, c['BLEND_DST_RGB'] = 0x80c8, c['BLEND_EQUATION'] = 0x8009, c['BLEND_EQUATION_ALPHA'] = 0x883d, c['BLEND_EQUATION_RGB'] = 0x8009, c['BLEND_SRC_ALPHA'] = 0x80cb, c['BLEND_SRC_RGB'] = 0x80c9, c['BLUE_BITS'] = 0xd54, c['BOOL'] = 0x8b56, c['BOOL_VEC2'] = 0x8b57, c['BOOL_VEC3'] = 0x8b58, c['BOOL_VEC4'] = 0x8b59, c['BROWSER_DEFAULT_WEBGL'] = 0x9244, c['BUFFER_SIZE'] = 0x8764, c['BUFFER_USAGE'] = 0x8765, c['BYTE'] = 0x1400, c['CCW'] = 0x901, c['CLAMP_TO_EDGE'] = 0x812f, c['COLOR_ATTACHMENT0'] = 0x8ce0, c['COLOR_BUFFER_BIT'] = 0x4000, c['COLOR_CLEAR_VALUE'] = 0xc22, c['COLOR_WRITEMASK'] = 0xc23, c['COMPILE_STATUS'] = 0x8b81, c['COMPRESSED_TEXTURE_FORMATS'] = 0x86a3, c['CONSTANT_ALPHA'] = 0x8003, c['CONSTANT_COLOR'] = 0x8001, c['CONTEXT_LOST_WEBGL'] = 0x9242, c['CULL_FACE'] = 0xb44, c['CULL_FACE_MODE'] = 0xb45, c['CURRENT_PROGRAM'] = 0x8b8d, c['CURRENT_VERTEX_ATTRIB'] = 0x8626, c['CW'] = 0x900, c['DECR'] = 0x1e03, c['DECR_WRAP'] = 0x8508, c['DELETE_STATUS'] = 0x8b80, c['DEPTH_ATTACHMENT'] = 0x8d00, c['DEPTH_BITS'] = 0xd56, c['DEPTH_BUFFER_BIT'] = 0x100, c['DEPTH_CLEAR_VALUE'] = 0xb73, c['DEPTH_COMPONENT'] = 0x1902, c['DEPTH_COMPONENT16'] = 0x81a5, c['DEPTH_FUNC'] = 0xb74, c['DEPTH_RANGE'] = 0xb70, c['DEPTH_STENCIL'] = 0x84f9, c['DEPTH_STENCIL_ATTACHMENT'] = 0x821a, c['DEPTH_TEST'] = 0xb71, c['DEPTH_WRITEMASK'] = 0xb72, c['DITHER'] = 0xbd0, c['DONT_CARE'] = 0x1100, c['DST_ALPHA'] = 0x304, c['DST_COLOR'] = 0x306, c['DYNAMIC_DRAW'] = 0x88e8, c['ELEMENT_ARRAY_BUFFER'] = 0x8893, c['ELEMENT_ARRAY_BUFFER_BINDING'] = 0x8895, c['EQUAL'] = 0x202, c['FASTEST'] = 0x1101, c['FLOAT'] = 0x1406, c['FLOAT_MAT2'] = 0x8b5a, c['FLOAT_MAT3'] = 0x8b5b, c['FLOAT_MAT4'] = 0x8b5c, c['FLOAT_VEC2'] = 0x8b50, c['FLOAT_VEC3'] = 0x8b51, c['FLOAT_VEC4'] = 0x8b52, c['FRAGMENT_SHADER'] = 0x8b30, c['FRAMEBUFFER'] = 0x8d40, c['FRAMEBUFFER_ATTACHMENT_OBJECT_NAME'] = 0x8cd1, c['FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE'] = 0x8cd0, c['FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE'] = 0x8cd3, c['FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL'] = 0x8cd2, c['FRAMEBUFFER_BINDING'] = 0x8ca6, c['FRAMEBUFFER_COMPLETE'] = 0x8cd5, c['FRAMEBUFFER_INCOMPLETE_ATTACHMENT'] = 0x8cd6, c['FRAMEBUFFER_INCOMPLETE_DIMENSIONS'] = 0x8cd9, c['FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT'] = 0x8cd7, c['FRAMEBUFFER_UNSUPPORTED'] = 0x8cdd, c['FRONT'] = 0x404, c['FRONT_AND_BACK'] = 0x408, c['FRONT_FACE'] = 0xb46, c['FUNC_ADD'] = 0x8006, c['FUNC_REVERSE_SUBTRACT'] = 0x800b, c['FUNC_SUBTRACT'] = 0x800a, c['GENERATE_MIPMAP_HINT'] = 0x8192, c['GEQUAL'] = 0x206, c['GREATER'] = 0x204, c['GREEN_BITS'] = 0xd53, c['HIGH_FLOAT'] = 0x8df2, c['HIGH_INT'] = 0x8df5, c['IMPLEMENTATION_COLOR_READ_FORMAT'] = 0x8b9b, c['IMPLEMENTATION_COLOR_READ_TYPE'] = 0x8b9a, c['INCR'] = 0x1e02, c['INCR_WRAP'] = 0x8507, c['INT'] = 0x1404, c['INT_VEC2'] = 0x8b53, c['INT_VEC3'] = 0x8b54, c['INT_VEC4'] = 0x8b55, c['INVALID_ENUM'] = 0x500, c['INVALID_FRAMEBUFFER_OPERATION'] = 0x506, c['INVALID_OPERATION'] = 0x502, c['INVALID_VALUE'] = 0x501, c['INVERT'] = 0x150a, c['KEEP'] = 0x1e00, c['LEQUAL'] = 0x203, c['LESS'] = 0x201, c['LINEAR'] = 0x2601, c['LINEAR_MIPMAP_LINEAR'] = 0x2703, c['LINEAR_MIPMAP_NEAREST'] = 0x2701, c['LINES'] = 0x1, c['LINE_LOOP'] = 0x2, c['LINE_STRIP'] = 0x3, c['LINE_WIDTH'] = 0xb21, c['LINK_STATUS'] = 0x8b82, c['LOW_FLOAT'] = 0x8df0, c['LOW_INT'] = 0x8df3, c['LUMINANCE'] = 0x1909, c['LUMINANCE_ALPHA'] = 0x190a, c['MAX_COMBINED_TEXTURE_IMAGE_UNITS'] = 0x8b4d, c['MAX_CUBE_MAP_TEXTURE_SIZE'] = 0x851c, c['MAX_FRAGMENT_UNIFORM_VECTORS'] = 0x8dfd, c['MAX_RENDERBUFFER_SIZE'] = 0x84e8, c['MAX_TEXTURE_IMAGE_UNITS'] = 0x8872, c['MAX_TEXTURE_SIZE'] = 0xd33, c['MAX_VARYING_VECTORS'] = 0x8dfc, c['MAX_VERTEX_ATTRIBS'] = 0x8869, c['MAX_VERTEX_TEXTURE_IMAGE_UNITS'] = 0x8b4c, c['MAX_VERTEX_UNIFORM_VECTORS'] = 0x8dfb, c['MAX_VIEWPORT_DIMS'] = 0xd3a, c['MEDIUM_FLOAT'] = 0x8df1, c['MEDIUM_INT'] = 0x8df4, c['MIRRORED_REPEAT'] = 0x8370, c['NEAREST'] = 0x2600, c['NEAREST_MIPMAP_LINEAR'] = 0x2702, c['NEAREST_MIPMAP_NEAREST'] = 0x2700, c['NEVER'] = 0x200, c['NICEST'] = 0x1102, c['NONE'] = 0x0, c['NOTEQUAL'] = 0x205, c['NO_ERROR'] = 0x0, c['ONE'] = 0x1, c['ONE_MINUS_CONSTANT_ALPHA'] = 0x8004, c['ONE_MINUS_CONSTANT_COLOR'] = 0x8002, c['ONE_MINUS_DST_ALPHA'] = 0x305, c['ONE_MINUS_DST_COLOR'] = 0x307, c['ONE_MINUS_SRC_ALPHA'] = 0x303, c['ONE_MINUS_SRC_COLOR'] = 0x301, c['OUT_OF_MEMORY'] = 0x505, c['PACK_ALIGNMENT'] = 0xd05, c['POINTS'] = 0x0, c['POLYGON_OFFSET_FACTOR'] = 0x8038, c['POLYGON_OFFSET_FILL'] = 0x8037, c['POLYGON_OFFSET_UNITS'] = 0x2a00, c['RED_BITS'] = 0xd52, c['RENDERBUFFER'] = 0x8d41, c['RENDERBUFFER_ALPHA_SIZE'] = 0x8d53, c['RENDERBUFFER_BINDING'] = 0x8ca7, c['RENDERBUFFER_BLUE_SIZE'] = 0x8d52, c['RENDERBUFFER_DEPTH_SIZE'] = 0x8d54, c['RENDERBUFFER_GREEN_SIZE'] = 0x8d51, c['RENDERBUFFER_HEIGHT'] = 0x8d43, c['RENDERBUFFER_INTERNAL_FORMAT'] = 0x8d44, c['RENDERBUFFER_RED_SIZE'] = 0x8d50, c['RENDERBUFFER_STENCIL_SIZE'] = 0x8d55, c['RENDERBUFFER_WIDTH'] = 0x8d42, c['RENDERER'] = 0x1f01, c['REPEAT'] = 0x2901, c['REPLACE'] = 0x1e01, c['RGB'] = 0x1907, c['RGB5_A1'] = 0x8057, c['RGB565'] = 0x8d62, c['RGBA'] = 0x1908, c['RGBA4'] = 0x8056, c['SAMPLER_2D'] = 0x8b5e, c['SAMPLER_CUBE'] = 0x8b60, c['SAMPLES'] = 0x80a9, c['SAMPLE_ALPHA_TO_COVERAGE'] = 0x809e, c['SAMPLE_BUFFERS'] = 0x80a8, c['SAMPLE_COVERAGE'] = 0x80a0, c['SAMPLE_COVERAGE_INVERT'] = 0x80ab, c['SAMPLE_COVERAGE_VALUE'] = 0x80aa, c['SCISSOR_BOX'] = 0xc10, c['SCISSOR_TEST'] = 0xc11, c['SHADER_TYPE'] = 0x8b4f, c['SHADING_LANGUAGE_VERSION'] = 0x8b8c, c['SHORT'] = 0x1402, c['SRC_ALPHA'] = 0x302, c['SRC_ALPHA_SATURATE'] = 0x308, c['SRC_COLOR'] = 0x300, c['STATIC_DRAW'] = 0x88e4, c['STENCIL_ATTACHMENT'] = 0x8d20, c['STENCIL_BACK_FAIL'] = 0x8801, c['STENCIL_BACK_FUNC'] = 0x8800, c['STENCIL_BACK_PASS_DEPTH_FAIL'] = 0x8802, c['STENCIL_BACK_PASS_DEPTH_PASS'] = 0x8803, c['STENCIL_BACK_REF'] = 0x8ca3, c['STENCIL_BACK_VALUE_MASK'] = 0x8ca4, c['STENCIL_BACK_WRITEMASK'] = 0x8ca5, c['STENCIL_BITS'] = 0xd57, c['STENCIL_BUFFER_BIT'] = 0x400, c['STENCIL_CLEAR_VALUE'] = 0xb91, c['STENCIL_FAIL'] = 0xb94, c['STENCIL_FUNC'] = 0xb92, c['STENCIL_INDEX8'] = 0x8d48, c['STENCIL_PASS_DEPTH_FAIL'] = 0xb95, c['STENCIL_PASS_DEPTH_PASS'] = 0xb96, c['STENCIL_REF'] = 0xb97, c['STENCIL_TEST'] = 0xb90, c['STENCIL_VALUE_MASK'] = 0xb93, c['STENCIL_WRITEMASK'] = 0xb98, c['STREAM_DRAW'] = 0x88e0, c['SUBPIXEL_BITS'] = 0xd50, c['TEXTURE'] = 0x1702, c['TEXTURE0'] = 0x84c0, c['TEXTURE1'] = 0x84c1, c['TEXTURE2'] = 0x84c2, c['TEXTURE3'] = 0x84c3, c['TEXTURE4'] = 0x84c4, c['TEXTURE5'] = 0x84c5, c['TEXTURE6'] = 0x84c6, c['TEXTURE7'] = 0x84c7, c['TEXTURE8'] = 0x84c8, c['TEXTURE9'] = 0x84c9, c['TEXTURE10'] = 0x84ca, c['TEXTURE11'] = 0x84cb, c['TEXTURE12'] = 0x84cc, c['TEXTURE13'] = 0x84cd, c['TEXTURE14'] = 0x84ce, c['TEXTURE15'] = 0x84cf, c['TEXTURE16'] = 0x84d0, c['TEXTURE17'] = 0x84d1, c['TEXTURE18'] = 0x84d2, c['TEXTURE19'] = 0x84d3, c['TEXTURE20'] = 0x84d4, c['TEXTURE21'] = 0x84d5, c['TEXTURE22'] = 0x84d6, c['TEXTURE23'] = 0x84d7, c['TEXTURE24'] = 0x84d8, c['TEXTURE25'] = 0x84d9, c['TEXTURE26'] = 0x84da, c['TEXTURE27'] = 0x84db, c['TEXTURE28'] = 0x84dc, c['TEXTURE29'] = 0x84dd, c['TEXTURE30'] = 0x84de, c['TEXTURE31'] = 0x84df, c['TEXTURE_2D'] = 0xde1, c['TEXTURE_BINDING_2D'] = 0x8069, c['TEXTURE_BINDING_CUBE_MAP'] = 0x8514, c['TEXTURE_CUBE_MAP'] = 0x8513, c['TEXTURE_CUBE_MAP_NEGATIVE_X'] = 0x8516, c['TEXTURE_CUBE_MAP_NEGATIVE_Y'] = 0x8518, c['TEXTURE_CUBE_MAP_NEGATIVE_Z'] = 0x851a, c['TEXTURE_CUBE_MAP_POSITIVE_X'] = 0x8515, c['TEXTURE_CUBE_MAP_POSITIVE_Y'] = 0x8517, c['TEXTURE_CUBE_MAP_POSITIVE_Z'] = 0x8519, c['TEXTURE_MAG_FILTER'] = 0x2800, c['TEXTURE_MIN_FILTER'] = 0x2801, c['TEXTURE_WRAP_S'] = 0x2802, c['TEXTURE_WRAP_T'] = 0x2803, c['TRIANGLES'] = 0x4, c['TRIANGLE_FAN'] = 0x6, c['TRIANGLE_STRIP'] = 0x5, c['UNPACK_ALIGNMENT'] = 0xcf5, c['UNPACK_COLORSPACE_CONVERSION_WEBGL'] = 0x9243, c['UNPACK_FLIP_Y_WEBGL'] = 0x9240, c['UNPACK_PREMULTIPLY_ALPHA_WEBGL'] = 0x9241, c['UNSIGNED_BYTE'] = 0x1401, c['UNSIGNED_INT'] = 0x1405, c['UNSIGNED_SHORT'] = 0x1403, c['UNSIGNED_SHORT_4_4_4_4'] = 0x8033, c['UNSIGNED_SHORT_5_5_5_1'] = 0x8034, c['UNSIGNED_SHORT_5_6_5'] = 0x8363, c['VALIDATE_STATUS'] = 0x8b83, c['VENDOR'] = 0x1f00, c['VERSION'] = 0x1f02, c['VERTEX_ATTRIB_ARRAY_BUFFER_BINDING'] = 0x889f, c['VERTEX_ATTRIB_ARRAY_ENABLED'] = 0x8622, c['VERTEX_ATTRIB_ARRAY_NORMALIZED'] = 0x886a, c['VERTEX_ATTRIB_ARRAY_POINTER'] = 0x8645, c['VERTEX_ATTRIB_ARRAY_SIZE'] = 0x8623, c['VERTEX_ATTRIB_ARRAY_STRIDE'] = 0x8624, c['VERTEX_ATTRIB_ARRAY_TYPE'] = 0x8625, c['VERTEX_SHADER'] = 0x8b31, c['VIEWPORT'] = 0xba2, c['ZERO'] = 0x0);
  }, {}],
  0x17: [function (b, c, d) {
    function f(l) {
      return (f = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (m) {
        return _typeof(m);
      } : function (m) {
        return m && 'function' == typeof Symbol && m['constructor'] === Symbol && m !== Symbol['prototype'] ? 'symbol' : _typeof(m);
      })(l);
    }
    function g(l, m) {
      for (var p = 0x0; p < m['length']; p++) {
        var q = m[p];
        q['enumerable'] = q['enumerable'] || !0x1, q['configurable'] = !0x0, 'value' in q && (q['writable'] = !0x0), Object['defineProperty'](l, j(q['key']), q);
      }
    }
    function h(l, m, p) {
      (m = j(m)) in l ? Object['defineProperty'](l, m, {
        'value': p,
        'enumerable': !0x0,
        'configurable': !0x0,
        'writable': !0x0
      }) : l[m] = p;
    }
    function j(l) {
      return l = function (m, p) {
        if ('object' != f(m) || !m) return m;
        var q = m[Symbol['toPrimitive']];
        if (void 0x0 === q) return ('string' === p ? String : Number)(m);
        if ('object' != f(q = q['call'](m, p || 'default'))) return q;
        throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
      }(l, 'string'), 'symbol' == f(l) ? l : l + '';
    }
    Object['defineProperty'](d, '__esModule', {
      'value': !0x0
    }), d['default'] = void 0x0;
    var k = new WeakMap(),
      d = d['default'] = function () {
        function l(s) {
          var v = this,
            w = 0x1 < arguments['length'] && void 0x0 !== arguments[0x1] ? arguments[0x1] : [],
            x = this,
            y = l;
          if (!(x instanceof y)) throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
          if (h(this, 'binaryType', ''), h(this, 'bufferedAmount', 0x0), h(this, 'extensions', ''), h(this, 'onclose', null), h(this, 'onerror', null), h(this, 'onmessage', null), h(this, 'onopen', null), h(this, 'protocol', ''), h(this, 'readyState', 0x3), 'string' != typeof s || !/(^ws:\/\/)|(^wss:\/\/)/['test'](s)) throw new TypeError('Failed\x20to\x20construct\x20\x27WebSocket\x27:\x20The\x20URL\x20\x27'['concat'](s, '\x27\x20is\x20invalid'));
          return this['url'] = s, this['readyState'] = l['CONNECTING'], x = wx['connectSocket']({
            'url': s,
            'protocols': Array['isArray'](w) ? w : [w],
            'tcpNoDelay': !0x0
          }), (k['set'](this, x), x['onClose'](function (z) {
            v['readyState'] = l['CLOSED'], 'function' == typeof v['onclose'] && v['onclose'](z);
          }), x['onMessage'](function (z) {
            'function' == typeof v['onmessage'] && v['onmessage'](z);
          }), x['onOpen'](function () {
            v['readyState'] = l['OPEN'], 'function' == typeof v['onopen'] && v['onopen']();
          }), x['onError'](function (z) {
            'function' == typeof v['onerror'] && v['onerror'](new Error(z['errMsg']));
          }), this);
        }
        return m = l, (p = [{
          'key': 'close',
          'value': function value(s, v) {
            this['readyState'] = l['CLOSING'], k['get'](this)['close']({
              'code': s,
              'reason': v
            });
          }
        }, {
          'key': 'send',
          'value': function value(s) {
            if (!('string' == typeof s || s instanceof ArrayBuffer || ArrayBuffer['isView'](s))) throw new TypeError('Failed\x20to\x20send\x20message:\x20The\x20data\x20'['concat'](s, '\x20is\x20invalid'));
            k['get'](this)['send']({
              'data': s
            });
          }
        }]) && g(m['prototype'], p), q && g(m, q), Object['defineProperty'](m, 'prototype', {
          'writable': !0x1
        }), m;
        var m, p, q;
      }();
    h(d, 'CONNECTING', 0x0), h(d, 'OPEN', 0x1), h(d, 'CLOSING', 0x2), h(d, 'CLOSED', 0x3);
  }, {}],
  0x18: [function (b, c, d) {
    Object['defineProperty'](d, '__esModule', {
      'value': !0x0
    }), d['screen'] = d['performance'] = d['ontouchstart'] = d['ontouchmove'] = d['ontouchend'] = d['innerWidth'] = d['innerHeight'] = d['devicePixelRatio'] = void 0x0;
    var f = wx['getSystemInfoSync'](),
      g = f['screenWidth'],
      h = f['screenHeight'],
      f = (d['devicePixelRatio'] = f['devicePixelRatio'], d['innerWidth'] = g),
      j = d['innerHeight'] = h;
    d['screen'] = {
      'width': g,
      'height': h,
      'availWidth': f,
      'availHeight': j,
      'availLeft': 0x0,
      'availTop': 0x0
    }, d['performance'] = {
      'now': Date['now']
    }, d['ontouchstart'] = null, d['ontouchmove'] = null, d['ontouchend'] = null;
  }, {}],
  0x19: [function (b, g, j) {
    Object['defineProperty'](j, '__esModule', {
      'value': !0x0
    }), j['default'] = void 0x0, b = (b = b('./EventTarget.js')) && b['__esModule'] ? b : {
      'default': b
    };
    function k(K) {
      return (k = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (L) {
        return _typeof(L);
      } : function (L) {
        return L && 'function' == typeof Symbol && L['constructor'] === Symbol && L !== Symbol['prototype'] ? 'symbol' : _typeof(L);
      })(K);
    }
    function q(K, L) {
      for (var M = 0x0; M < L['length']; M++) {
        var N = L[M];
        N['enumerable'] = N['enumerable'] || !0x1, N['configurable'] = !0x0, 'value' in N && (N['writable'] = !0x0), Object['defineProperty'](K, B(N['key']), N);
      }
    }
    function v(K, L, M) {
      L = x(L);
      var N = K,
        L = w() ? Reflect['construct'](L, M || [], x(K)['constructor']) : L['apply'](K, M);
      if (!L || 'object' != k(L) && 'function' != typeof L) {
        if (void 0x0 !== L) throw new TypeError('Derived\x20constructors\x20may\x20only\x20return\x20object\x20or\x20undefined');
        if (void 0x0 === (L = N)) throw new ReferenceError('this\x20hasn\x27t\x20been\x20initialised\x20-\x20super()\x20hasn\x27t\x20been\x20called');
      }
      return L;
    }
    function w() {
      try {
        var K = !Boolean['prototype']['valueOf']['call'](Reflect['construct'](Boolean, [], function () {}));
      } catch (L) {}
      return (w = function w() {
        return !!K;
      })();
    }
    function x(K) {
      return (x = Object['setPrototypeOf'] ? Object['getPrototypeOf']['bind']() : function (L) {
        return L['__proto__'] || Object['getPrototypeOf'](L);
      })(K);
    }
    function z(K, L) {
      return (z = Object['setPrototypeOf'] ? Object['setPrototypeOf']['bind']() : function (M, N) {
        return M['__proto__'] = N, M;
      })(K, L);
    }
    function A(K, L, M) {
      (L = B(L)) in K ? Object['defineProperty'](K, L, {
        'value': M,
        'enumerable': !0x0,
        'configurable': !0x0,
        'writable': !0x0
      }) : K[L] = M;
    }
    function B(K) {
      return K = function (L, M) {
        if ('object' != k(L) || !L) return L;
        var N = L[Symbol['toPrimitive']];
        if (void 0x0 === N) return ('string' === M ? String : Number)(L);
        if ('object' != k(N = N['call'](L, M || 'default'))) return N;
        throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
      }(K, 'string'), 'symbol' == k(K) ? K : K + '';
    }
    var C = new WeakMap(),
      D = new WeakMap(),
      F = new WeakMap(),
      G = new WeakMap(),
      H = new WeakMap();
    function I(K) {
      if ('function' == typeof this['on'['concat'](K)]) {
        for (var L = arguments['length'], M = new Array(0x1 < L ? L - 0x1 : 0x0), N = 0x1; N < L; N++) M[N - 0x1] = arguments[N];
        this['on'['concat'](K)]['apply'](this, M);
      }
    }
    function J(K) {
      this['readyState'] = K, I['call'](this, 'readystatechange');
    }
    j = j['default'] = function (K) {
      function L() {
        var O;
        if (this instanceof L) return A(O = v(this, L), 'timeout', 0x0), A(O, 'onabort', null), A(O, 'onerror', null), A(O, 'onload', null), A(O, 'onloadstart', null), A(O, 'onprogress', null), A(O, 'ontimeout', null), A(O, 'onloadend', null), A(O, 'onreadystatechange', null), A(O, 'readyState', 0x0), A(O, 'response', null), A(O, 'responseText', null), A(O, 'responseType', ''), A(O, 'responseXML', null), A(O, 'status', 0x0), A(O, 'statusText', ''), A(O, 'upload', {}), A(O, 'withCredentials', !0x1), F['set'](O, {
          'content-type': 'application/x-www-form-urlencoded'
        }), G['set'](O, {}), O;
        throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      }
      var M,
        N = L;
      if ('function' != typeof K && null !== K) throw new TypeError('Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function');
      return N['prototype'] = Object['create'](K && K['prototype'], {
        'constructor': {
          'value': N,
          'writable': !0x0,
          'configurable': !0x0
        }
      }), Object['defineProperty'](N, 'prototype', {
        'writable': !0x1
      }), K && z(N, K), N = L, (K = [{
        'key': 'abort',
        'value': function value() {
          var O = H['get'](this);
          O && O['abort']();
        }
      }, {
        'key': 'getAllResponseHeaders',
        'value': function value() {
          var O = G['get'](this);
          return Object['keys'](O)['map'](function (P) {
            return ''['concat'](P, ':\x20')['concat'](O[P]);
          })['join']('\x0a');
        }
      }, {
        'key': 'getResponseHeader',
        'value': function value(O) {
          return G['get'](this)[O];
        }
      }, {
        'key': 'open',
        'value': function value(O, P) {
          D['set'](this, O), C['set'](this, P), J['call'](this, L['OPENED']);
        }
      }, {
        'key': 'overrideMimeType',
        'value': function value() {}
      }, {
        'key': 'send',
        'value': function value() {
          var O = this,
            P = 0x0 < arguments['length'] && void 0x0 !== arguments[0x0] ? arguments[0x0] : '';
          if (this['readyState'] !== L['OPENED']) throw new Error('Failed\x20to\x20execute\x20\x27send\x27\x20on\x20\x27XMLHttpRequest\x27:\x20The\x20object\x27s\x20state\x20must\x20be\x20OPENED.');
          P = wx['request']({
            'data': P,
            'url': C['get'](this),
            'method': D['get'](this),
            'header': F['get'](this),
            'dataType': 'other',
            'responseType': 'arraybuffer' === this['responseType'] ? 'arraybuffer' : 'text',
            'timeout': this['timeout'] || void 0x0,
            'success': function success(Q) {
              var R = Q['data'],
                S = Q['header'];
              switch (O['status'] = Q['statusCode'], G['set'](O, S), I['call'](O, 'loadstart'), J['call'](O, L['HEADERS_RECEIVED']), J['call'](O, L['LOADING']), O['responseType']) {
                case 'json':
                  O['responseText'] = R;
                  try {
                    O['response'] = JSON['parse'](R);
                  } catch (W) {
                    O['response'] = null;
                  }
                  break;
                case '':
                case 'text':
                  O['responseText'] = O['response'] = R;
                  break;
                case 'arraybuffer':
                  O['response'] = R, O['responseText'] = '';
                  for (var T = new Uint8Array(R), U = T['byteLength'], V = 0x0; V < U; V++) O['responseText'] += String['fromCharCode'](T[V]);
                  break;
                default:
                  O['response'] = null;
              }
              J['call'](O, L['DONE']), I['call'](O, 'load'), I['call'](O, 'loadend');
            },
            'fail': function fail(Q) {
              Q = Q['errMsg'], (-0x1 !== Q['indexOf']('abort') ? I['call'](O, 'abort') : -0x1 !== Q['indexOf']('timeout') ? I['call'](O, 'timeout') : I['call'](O, 'error', Q), I['call'](O, 'loadend'));
            }
          }), H['set'](this, P);
        }
      }, {
        'key': 'setRequestHeader',
        'value': function value(O, P) {
          var Q = F['get'](this);
          Q[O] = P, F['set'](this, Q);
        }
      }, {
        'key': 'addEventListener',
        'value': function value(O, P) {
          var Q;
          'function' == typeof P && (Q = this, this['on' + O] = function (R) {
            P['call'](Q, R);
          });
        }
      }]) && q(N['prototype'], K), M && q(N, M), Object['defineProperty'](N, 'prototype', {
        'writable': !0x1
      }), N;
    }(b['default']), (A(j, 'UNSEND', 0x0), A(j, 'OPENED', 0x1), A(j, 'HEADERS_RECEIVED', 0x2), A(j, 'LOADING', 0x3), A(j, 'DONE', 0x4));
  }, {
    './EventTarget.js': 0xb
  }],
  0x1a: [function (b, g, h) {
    function j(C) {
      return (j = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (D) {
        return _typeof(D);
      } : function (D) {
        return D && 'function' == typeof Symbol && D['constructor'] === Symbol && D !== Symbol['prototype'] ? 'symbol' : _typeof(D);
      })(C);
    }
    Object['defineProperty'](h, '__esModule', {
      'value': !0x0
    }), h['default'] = void 0x0;
    var k = z(b('./window')),
      m = y(b('./HTMLElement')),
      q = y(b('./HTMLVideoElement')),
      v = y(b('./Image')),
      w = y(b('./Audio')),
      x = y(b('./Canvas'));
    function y(C) {
      return C && C['__esModule'] ? C : {
        'default': C
      };
    }
    function z(C, D) {
      var E, F;
      return 'function' == typeof WeakMap && (E = new WeakMap(), F = new WeakMap()), function (G, H) {
        if (!H && G && G['__esModule']) return G;
        var I,
          J,
          K = {
            '__proto__': null,
            'default': G
          };
        if (null !== G && ('object' == j(G) || 'function' == typeof G)) {
          if (I = H ? F : E) {
            if (I['has'](G)) return I['get'](G);
            I['set'](G, K);
          }
          for (var L in G) 'default' !== L && {}['hasOwnProperty']['call'](G, L) && ((J = (I = Object['defineProperty']) && Object['getOwnPropertyDescriptor'](G, L)) && (J['get'] || J['set']) ? I(K, L, J) : K[L] = G[L]);
        }
        return K;
      }(C, D);
    }
    b('./EventIniter/index.js');
    var A = {},
      B = {
        'readyState': 'complete',
        'visibilityState': 'visible',
        'documentElement': k,
        'hidden': !0x1,
        'style': {},
        'location': k['location'],
        'ontouchstart': null,
        'ontouchmove': null,
        'ontouchend': null,
        'head': new m['default']('head'),
        'body': new m['default']('body'),
        'createElement': function createElement(C) {
          return 'canvas' === C ? new x['default']() : 'audio' === C ? new w['default']() : 'img' === C ? new v['default']() : 'video' === C ? new q['default']() : new m['default'](C);
        },
        'createElementNS': function createElementNS(C, D) {
          return this['createElement'](D);
        },
        'getElementById': function getElementById(C) {
          return C === k['canvas']['id'] ? k['canvas'] : null;
        },
        'getElementsByTagName': function getElementsByTagName(C) {
          return 'head' === C ? [B['head']] : 'body' === C ? [B['body']] : 'canvas' === C ? [k['canvas']] : [];
        },
        'getElementsByName': function getElementsByName(C) {
          return 'head' === C ? [B['head']] : 'body' === C ? [B['body']] : 'canvas' === C ? [k['canvas']] : [];
        },
        'querySelector': function querySelector(C) {
          return 'head' === C ? B['head'] : 'body' === C ? B['body'] : 'canvas' === C || C === '#'['concat'](k['canvas']['id']) ? k['canvas'] : null;
        },
        'querySelectorAll': function querySelectorAll(C) {
          return 'head' === C ? [B['head']] : 'body' === C ? [B['body']] : 'canvas' === C ? [k['canvas']] : [];
        },
        'addEventListener': function addEventListener(C, D) {
          A[C] || (A[C] = []), A[C]['push'](D);
        },
        'removeEventListener': function removeEventListener(C, D) {
          var E = A[C];
          if (E && 0x0 < E['length']) {
            for (var F = E['length']; F--;) if (E[F] === D) {
              E['splice'](F, 0x1);
              break;
            }
          }
        },
        'dispatchEvent': function dispatchEvent(C) {
          var D = A[C['type']];
          if (D) {
            for (var E = 0x0; E < D['length']; E++) D[E](C);
          }
        }
      };
    h['default'] = B;
  }, {
    './Audio': 0x5,
    './Canvas': 0x6,
    './EventIniter/index.js': 0xa,
    './HTMLElement': 0xf,
    './HTMLVideoElement': 0x12,
    './Image': 0x13,
    './window': 0x20
  }],
  0x1b: [function (b, g, h) {
    function j(A) {
      return (j = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (B) {
        return _typeof(B);
      } : function (B) {
        return B && 'function' == typeof Symbol && B['constructor'] === Symbol && B !== Symbol['prototype'] ? 'symbol' : _typeof(B);
      })(A);
    }
    var k = p(b('./window')),
      m = (m = b('./document')) && m['__esModule'] ? m : {
        'default': m
      };
    function p(A, B) {
      var C, D;
      return 'function' == typeof WeakMap && (C = new WeakMap(), D = new WeakMap()), function (E, F) {
        if (!F && E && E['__esModule']) return E;
        var G,
          H,
          I = {
            '__proto__': null,
            'default': E
          };
        if (null !== E && ('object' == j(E) || 'function' == typeof E)) {
          if (G = F ? D : C) {
            if (G['has'](E)) return G['get'](E);
            G['set'](E, I);
          }
          for (var J in E) 'default' !== J && {}['hasOwnProperty']['call'](E, J) && ((H = (G = Object['defineProperty']) && Object['getOwnPropertyDescriptor'](E, J)) && (H['get'] || H['set']) ? G(I, J, H) : I[J] = E[J]);
        }
        return I;
      }(A, B);
    }
    var q = GameGlobal;
    if (!GameGlobal['__isAdapterInjected']) {
      GameGlobal['__isAdapterInjected'] = !0x0, k['document'] = m['default'], k['addEventListener'] = function (A, B) {
        k['document']['addEventListener'](A, B);
      }, k['removeEventListener'] = function (A, B) {
        k['document']['removeEventListener'](A, B);
      }, k['dispatchEvent'] = function () {
        var A = 0x0 < arguments['length'] && void 0x0 !== arguments[0x0] ? arguments[0x0] : {};
        console['log']('window.dispatchEvent', A['type'], A);
      }, m = wx['getSystemInfoSync']()['platform'];
      if ('undefined' == typeof __devtoolssubcontext && 'devtools' === m) {
        for (var v in k) {
          var w = Object['getOwnPropertyDescriptor'](q, v);
          w && !0x0 !== w['configurable'] || Object['defineProperty'](window, v, {
            'value': k[v]
          });
        }
        for (var x in k['document']) {
          var y = Object['getOwnPropertyDescriptor'](q['document'], x);
          y && !0x0 !== y['configurable'] || Object['defineProperty'](q['document'], x, {
            'value': k['document'][x]
          });
        }
        window['parent'] = window;
      } else {
        for (var z in k) q[z] = k[z];
        q['window'] = k, (window = q)['top'] = window['parent'] = window;
      }
    }
    q['CCWebAssembly'] = q['WebAssembly'] = q['WXWebAssembly'], b('../../../../common/xmldom/dom-parser'), b('../unify'), b('../fs-utils');
  }, {
    '../../../../common/xmldom/dom-parser': 0x1,
    '../fs-utils': 0x21,
    '../unify': 0x22,
    './document': 0x1a,
    './window': 0x20
  }],
  0x1c: [function (a, b, c) {
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = void 0x0, c['default'] = {
      get 'length'() {
        return wx['getStorageInfoSync']()['keys']['length'];
      },
      'key': function key(d) {
        return wx['getStorageInfoSync']()['keys'][d];
      },
      'getItem': function getItem(d) {
        return wx['getStorageSync'](d);
      },
      'setItem': function setItem(d, f) {
        return wx['setStorageSync'](d, f);
      },
      'removeItem': function removeItem(d) {
        wx['removeStorageSync'](d);
      },
      'clear': function clear() {
        wx['clearStorageSync']();
      }
    };
  }, {}],
  0x1d: [function (a, b, c) {
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['default'] = void 0x0, c['default'] = {
      'href': 'game.js',
      'protocol': '',
      'reload': function reload() {}
    };
  }, {}],
  0x1e: [function (b, c, d) {
    Object['defineProperty'](d, '__esModule', {
      'value': !0x0
    }), d['default'] = void 0x0;
    var b = b('./util/index.js'),
      f = wx['getSystemInfoSync'](),
      g = (console['log'](f), f['system']),
      h = f['platform'],
      j = f['language'],
      f = f['version'],
      g = -0x1 !== g['toLowerCase']()['indexOf']('android') ? 'Android;\x20CPU\x20'['concat'](g) : 'iPhone;\x20CPU\x20iPhone\x20OS\x20'['concat'](g, '\x20like\x20Mac\x20OS\x20X'),
      f = 'Mozilla/5.0\x20('['concat'](g, ')\x20AppleWebKit/603.1.30\x20(KHTML,\x20like\x20Gecko)\x20Mobile/14E8301\x20MicroMessenger/')['concat'](f, '\x20MiniGame\x20NetType/WIFI\x20Language/')['concat'](j),
      k = {
        'platform': h,
        'language': j,
        'appVersion': '5.0\x20('['concat'](g, ')\x20AppleWebKit/601.1.46\x20(KHTML,\x20like\x20Gecko)\x20Version/9.0\x20Mobile/13B143\x20Safari/601.1'),
        'userAgent': f,
        'onLine': !0x0,
        'geolocation': {
          'getCurrentPosition': b['noop'],
          'watchPosition': b['noop'],
          'clearWatch': b['noop']
        }
      };
    wx['onNetworkStatusChange'] && wx['onNetworkStatusChange'](function (l) {
      k['onLine'] = l['isConnected'];
    }), d['default'] = k;
  }, {
    './util/index.js': 0x1f
  }],
  0x1f: [function (a, b, c) {
    Object['defineProperty'](c, '__esModule', {
      'value': !0x0
    }), c['noop'] = function () {};
  }, {}],
  0x20: [function (j, k, q) {
    Object['defineProperty'](q, '__esModule', {
      'value': !0x0
    });
    var x = {
        'canvas': !0x0,
        'setTimeout': !0x0,
        'setInterval': !0x0,
        'clearTimeout': !0x0,
        'clearInterval': !0x0,
        'requestAnimationFrame': !0x0,
        'cancelAnimationFrame': !0x0,
        'navigator': !0x0,
        'XMLHttpRequest': !0x0,
        'WebSocket': !0x0,
        'Image': !0x0,
        'ImageBitmap': !0x0,
        'Audio': !0x0,
        'FileReader': !0x0,
        'HTMLElement': !0x0,
        'HTMLImageElement': !0x0,
        'HTMLCanvasElement': !0x0,
        'HTMLMediaElement': !0x0,
        'HTMLAudioElement': !0x0,
        'HTMLVideoElement': !0x0,
        'WebGLRenderingContext': !0x0,
        'TouchEvent': !0x0,
        'MouseEvent': !0x0,
        'DeviceMotionEvent': !0x0,
        'localStorage': !0x0,
        'location': !0x0
      },
      z = (Object['defineProperty'](q, 'Audio', {
        'enumerable': !0x0,
        'get': function get() {
          return G['default'];
        }
      }), Object['defineProperty'](q, 'DeviceMotionEvent', {
        'enumerable': !0x0,
        'get': function get() {
          return P['DeviceMotionEvent'];
        }
      }), Object['defineProperty'](q, 'FileReader', {
        'enumerable': !0x0,
        'get': function get() {
          return H['default'];
        }
      }), Object['defineProperty'](q, 'HTMLAudioElement', {
        'enumerable': !0x0,
        'get': function get() {
          return M['default'];
        }
      }), Object['defineProperty'](q, 'HTMLCanvasElement', {
        'enumerable': !0x0,
        'get': function get() {
          return K['default'];
        }
      }), Object['defineProperty'](q, 'HTMLElement', {
        'enumerable': !0x0,
        'get': function get() {
          return I['default'];
        }
      }), Object['defineProperty'](q, 'HTMLImageElement', {
        'enumerable': !0x0,
        'get': function get() {
          return J['default'];
        }
      }), Object['defineProperty'](q, 'HTMLMediaElement', {
        'enumerable': !0x0,
        'get': function get() {
          return L['default'];
        }
      }), Object['defineProperty'](q, 'HTMLVideoElement', {
        'enumerable': !0x0,
        'get': function get() {
          return N['default'];
        }
      }), Object['defineProperty'](q, 'Image', {
        'enumerable': !0x0,
        'get': function get() {
          return D['default'];
        }
      }), Object['defineProperty'](q, 'ImageBitmap', {
        'enumerable': !0x0,
        'get': function get() {
          return F['default'];
        }
      }), Object['defineProperty'](q, 'MouseEvent', {
        'enumerable': !0x0,
        'get': function get() {
          return P['MouseEvent'];
        }
      }), Object['defineProperty'](q, 'TouchEvent', {
        'enumerable': !0x0,
        'get': function get() {
          return P['TouchEvent'];
        }
      }), Object['defineProperty'](q, 'WebGLRenderingContext', {
        'enumerable': !0x0,
        'get': function get() {
          return O['default'];
        }
      }), Object['defineProperty'](q, 'WebSocket', {
        'enumerable': !0x0,
        'get': function get() {
          return C['default'];
        }
      }), Object['defineProperty'](q, 'XMLHttpRequest', {
        'enumerable': !0x0,
        'get': function get() {
          return B['default'];
        }
      }), q['clearTimeout'] = q['clearInterval'] = q['canvas'] = q['cancelAnimationFrame'] = void 0x0, Object['defineProperty'](q, 'localStorage', {
        'enumerable': !0x0,
        'get': function get() {
          return Q['default'];
        }
      }), Object['defineProperty'](q, 'location', {
        'enumerable': !0x0,
        'get': function get() {
          return R['default'];
        }
      }), Object['defineProperty'](q, 'navigator', {
        'enumerable': !0x0,
        'get': function get() {
          return A['default'];
        }
      }), q['setTimeout'] = q['setInterval'] = q['requestAnimationFrame'] = void 0x0, U(j('./Canvas'))),
      A = U(j('./navigator')),
      B = U(j('./XMLHttpRequest')),
      C = U(j('./WebSocket')),
      D = U(j('./Image')),
      F = U(j('./ImageBitmap')),
      G = U(j('./Audio')),
      H = U(j('./FileReader')),
      I = U(j('./HTMLElement')),
      J = U(j('./HTMLImageElement')),
      K = U(j('./HTMLCanvasElement')),
      L = U(j('./HTMLMediaElement')),
      M = U(j('./HTMLAudioElement')),
      N = U(j('./HTMLVideoElement')),
      O = U(j('./WebGLRenderingContext')),
      P = j('./EventIniter/index.js'),
      Q = U(j('./localStorage')),
      R = U(j('./location')),
      S = j('./WindowProperties');
    function U(V) {
      return V && V['__esModule'] ? V : {
        'default': V
      };
    }
    Object['keys'](S)['forEach'](function (V) {
      'default' === V || '__esModule' === V || Object['prototype']['hasOwnProperty']['call'](x, V) || V in q && q[V] === S[V] || Object['defineProperty'](q, V, {
        'enumerable': !0x0,
        'get': function get() {
          return S[V];
        }
      });
    }), GameGlobal['screencanvas'] = GameGlobal['screencanvas'] || new z['default'](), q['canvas'] = GameGlobal['screencanvas'], j = GameGlobal, (q['setTimeout'] = j['setTimeout'], q['setInterval'] = j['setInterval'], q['clearTimeout'] = j['clearTimeout'], q['clearInterval'] = j['clearInterval'], q['requestAnimationFrame'] = j['requestAnimationFrame'], q['cancelAnimationFrame'] = j['cancelAnimationFrame']);
  }, {
    './Audio': 0x5,
    './Canvas': 0x6,
    './EventIniter/index.js': 0xa,
    './FileReader': 0xc,
    './HTMLAudioElement': 0xd,
    './HTMLCanvasElement': 0xe,
    './HTMLElement': 0xf,
    './HTMLImageElement': 0x10,
    './HTMLMediaElement': 0x11,
    './HTMLVideoElement': 0x12,
    './Image': 0x13,
    './ImageBitmap': 0x14,
    './WebGLRenderingContext': 0x16,
    './WebSocket': 0x17,
    './WindowProperties': 0x18,
    './XMLHttpRequest': 0x19,
    './localStorage': 0x1c,
    './location': 0x1d,
    './navigator': 0x1e
  }],
  0x21: [function (b, c, d) {
    var f = wx['getFileSystemManager'] ? wx['getFileSystemManager']() : null,
      g = /the maximum size of the file storage/,
      h = {
        'fs': f,
        'isOutOfStorage': function isOutOfStorage(i) {
          return g['test'](i);
        },
        'getUserDataPath': function getUserDataPath() {
          return wx['env']['USER_DATA_PATH'];
        },
        'checkFsValid': function checkFsValid() {
          return !!f || (console['warn']('can\x20not\x20get\x20the\x20file\x20system!'), !0x1);
        },
        'deleteFile': function deleteFile(i, j) {
          f['unlink']({
            'filePath': i,
            'success': function success() {
              j && j(null);
            },
            'fail': function fail(k) {
              console['warn']('Delete\x20file\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](k['errMsg'])), j && j(new Error(k['errMsg']));
            }
          });
        },
        'downloadFile': function downloadFile(j, k, l, m, p) {
          var q = {
              'url': j,
              'success': function success(s) {
                0xc8 === s['statusCode'] ? p && p(null, s['tempFilePath'] || s['filePath']) : (s['filePath'] && h['deleteFile'](s['filePath']), console['warn']('Download\x20file\x20failed:\x20path:\x20'['concat'](j, '\x20message:\x20')['concat'](s['statusCode'])), p && p(new Error(s['statusCode']), null));
              },
              'fail': function fail(s) {
                console['warn']('Download\x20file\x20failed:\x20path:\x20'['concat'](j, '\x20message:\x20')['concat'](s['errMsg'])), p && p(new Error(s['errMsg']), null);
              }
            },
            k = (k && (q['filePath'] = k), l && (q['header'] = l), wx['downloadFile'](q));
          m && k['onProgressUpdate'](m);
        },
        'saveFile': function saveFile(i, j, k) {
          wx['saveFile']({
            'tempFilePath': i,
            'filePath': j,
            'success': function success() {
              k && k(null);
            },
            'fail': function fail(l) {
              console['warn']('Save\x20file\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](l['errMsg'])), k && k(new Error(l['errMsg']));
            }
          });
        },
        'copyFile': function copyFile(i, j, k) {
          f['copyFile']({
            'srcPath': i,
            'destPath': j,
            'success': function success() {
              k && k(null);
            },
            'fail': function fail(l) {
              console['warn']('Copy\x20file\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](l['errMsg'])), k && k(new Error(l['errMsg']));
            }
          });
        },
        'writeFile': function writeFile(i, j, k, l) {
          f['writeFile']({
            'filePath': i,
            'encoding': k,
            'data': j,
            'success': function success() {
              l && l(null);
            },
            'fail': function fail(m) {
              console['warn']('Write\x20file\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](m['errMsg'])), l && l(new Error(m['errMsg']));
            }
          });
        },
        'writeFileSync': function writeFileSync(i, j, k) {
          try {
            return f['writeFileSync'](i, j, k), null;
          } catch (l) {
            return console['warn']('Write\x20file\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](l['message'])), new Error(l['message']);
          }
        },
        'readFile': function readFile(i, j, k) {
          f['readFile']({
            'filePath': i,
            'encoding': j,
            'success': function success(l) {
              k && k(null, l['data']);
            },
            'fail': function fail(l) {
              console['warn']('Read\x20file\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](l['errMsg'])), k && k(new Error(l['errMsg']), null);
            }
          });
        },
        'readDir': function readDir(i, j) {
          f['readdir']({
            'dirPath': i,
            'success': function success(k) {
              j && j(null, k['files']);
            },
            'fail': function fail(k) {
              console['warn']('Read\x20directory\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](k['errMsg'])), j && j(new Error(k['errMsg']), null);
            }
          });
        },
        'readText': function readText(i, j) {
          h['readFile'](i, 'utf8', j);
        },
        'readArrayBuffer': function readArrayBuffer(i, j) {
          h['readFile'](i, void 0x0, j);
        },
        'readJson': function readJson(i, j) {
          h['readFile'](i, 'utf8', function (k, l) {
            var m = null;
            if (!k) try {
              m = JSON['parse'](l);
            } catch (p) {
              console['warn']('Read\x20json\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](p['message'])), k = new Error(p['message']);
            }
            j && j(k, m);
          });
        },
        'readJsonSync': function readJsonSync(i) {
          try {
            var j = f['readFileSync'](i, 'utf8');
            return JSON['parse'](j);
          } catch (k) {
            return console['warn']('Read\x20json\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](k['message'])), new Error(k['message']);
          }
        },
        'makeDirSync': function makeDirSync(i, j) {
          try {
            return f['mkdirSync'](i, j), null;
          } catch (k) {
            return console['warn']('Make\x20directory\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](k['message'])), new Error(k['message']);
          }
        },
        'rmdirSync': function rmdirSync(i, j) {
          try {
            return f['rmdirSync'](i, j), null;
          } catch (k) {
            return console['warn']('rm\x20directory\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](k['message'])), new Error(k['message']);
          }
        },
        'exists': function exists(i, j) {
          f['access']({
            'path': i,
            'success': function success() {
              j && j(!0x0);
            },
            'fail': function fail() {
              j && j(!0x1);
            }
          });
        },
        'loadSubpackage': function loadSubpackage(i, j, k) {
          var l = wx['loadSubpackage']({
            'name': i,
            'success': function success() {
              k && k();
            },
            'fail': function fail(m) {
              console['warn']('Load\x20Subpackage\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](m['errMsg'])), k && k(new Error('Failed\x20to\x20load\x20subpackage\x20'['concat'](i, ':\x20')['concat'](m['errMsg'])));
            }
          });
          return j && l['onProgressUpdate'](j), l;
        },
        'unzip': function unzip(i, j, k) {
          f['unzip']({
            'zipFilePath': i,
            'targetPath': j,
            'success': function success() {
              k && k(null);
            },
            'fail': function fail(l) {
              console['warn']('unzip\x20failed:\x20path:\x20'['concat'](i, '\x20message:\x20')['concat'](l['errMsg'])), k && k(new Error('unzip\x20failed:\x20'['concat'](l['errMsg'])));
            }
          });
        }
      };
    window['fsUtils'] = c['exports'] = h;
  }, {}],
  0x22: [function (b, d, f) {
    var g,
      h,
      j,
      k,
      l,
      m,
      b = b('./utils');
    window['__globalAdapter'] = window['__globalAdapter'] || {}, window['__globalAdapter'] && (g = window['__globalAdapter'], j = (h = wx['getSystemInfoSync']())['windowWidth'], k = h['windowHeight'] < j, g['isSubContext'] = void 0x0 === wx['getOpenDataContext'], g['isDevTool'] = 'devtools' === h['platform'], b['cloneMethod'](g, wx, 'getSystemInfoSync'), b['cloneMethod'](g, wx, 'onTouchStart'), b['cloneMethod'](g, wx, 'onTouchMove'), b['cloneMethod'](g, wx, 'onTouchEnd'), b['cloneMethod'](g, wx, 'onTouchCancel'), b['cloneMethod'](g, wx, 'createInnerAudioContext'), b['cloneMethod'](g, wx, 'onAudioInterruptionEnd'), b['cloneMethod'](g, wx, 'onAudioInterruptionBegin'), b['cloneMethod'](g, wx, 'createVideo'), b['cloneMethod'](g, wx, 'setPreferredFramesPerSecond'), b['cloneMethod'](g, wx, 'showKeyboard'), b['cloneMethod'](g, wx, 'hideKeyboard'), b['cloneMethod'](g, wx, 'updateKeyboard'), b['cloneMethod'](g, wx, 'onKeyboardInput'), b['cloneMethod'](g, wx, 'onKeyboardConfirm'), b['cloneMethod'](g, wx, 'onKeyboardComplete'), b['cloneMethod'](g, wx, 'offKeyboardInput'), b['cloneMethod'](g, wx, 'offKeyboardConfirm'), b['cloneMethod'](g, wx, 'offKeyboardComplete'), b['cloneMethod'](g, wx, 'getOpenDataContext'), b['cloneMethod'](g, wx, 'onMessage'), b['cloneMethod'](g, wx, 'loadSubpackage'), b['cloneMethod'](g, wx, 'getSharedCanvas'), b['cloneMethod'](g, wx, 'loadFont'), b['cloneMethod'](g, wx, 'onShow'), b['cloneMethod'](g, wx, 'onHide'), 'function' == typeof getApp && (wx['onShow'] = wx['onAppShow'], wx['onHide'] = wx['onAppHide']), b['cloneMethod'](g, wx, 'onError'), b['cloneMethod'](g, wx, 'offError'), l = !0x1, m = 0x1, wx['onDeviceOrientationChange'] && wx['onDeviceOrientationChange'](function (p) {
      'landscape' === p['value'] ? m = 0x1 : 'landscapeReverse' === p['value'] && (m = -0x1);
    }), Object['assign'](g, {
      'startAccelerometer': function startAccelerometer(p) {
        l ? wx['startAccelerometer'] && wx['startAccelerometer']({
          'fail': function fail(q) {
            console['error']('start\x20accelerometer\x20failed', q);
          }
        }) : (l = !0x0, wx['onAccelerometerChange'] && wx['onAccelerometerChange'](function (q) {
          var s,
            v = {},
            w = q['x'],
            x = q['y'];
          k && (s = w, w = -x, x = s), v['x'] = w * m, v['y'] = x * m, v['z'] = q['z'], p && p(v);
        }));
      },
      'stopAccelerometer': function stopAccelerometer() {
        wx['stopAccelerometer'] && wx['stopAccelerometer']({
          'fail': function fail(p) {
            console['error']('stop\x20accelerometer\x20failed', p);
          }
        });
      }
    }));
  }, {
    './utils': 0x23
  }],
  0x23: [function (a, b, c) {
    b['exports'] = {
      'cloneMethod': function cloneMethod(d, f, g, h) {
        f[g] && (d[h = h || g] = f[g]['bind'](f));
      }
    };
  }, {}]
}, {}, [0x1b]);