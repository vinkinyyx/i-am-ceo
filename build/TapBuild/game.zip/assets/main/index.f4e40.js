function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
function _regeneratorRuntime() {
  "use strict";

  /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */
  _regeneratorRuntime = function _regeneratorRuntime() {
    return r;
  };
  var t,
    r = {},
    e = Object.prototype,
    n = e.hasOwnProperty,
    o = "function" == typeof Symbol ? Symbol : {},
    i = o.iterator || "@@iterator",
    a = o.asyncIterator || "@@asyncIterator",
    u = o.toStringTag || "@@toStringTag";
  function c(t, r, e, n) {
    return Object.defineProperty(t, r, {
      value: e,
      enumerable: !n,
      configurable: !n,
      writable: !n
    });
  }
  try {
    c({}, "");
  } catch (t) {
    c = function c(t, r, e) {
      return t[r] = e;
    };
  }
  function h(r, e, n, o) {
    var i = e && e.prototype instanceof Generator ? e : Generator,
      a = Object.create(i.prototype);
    return c(a, "_invoke", function (r, e, n) {
      var o = 1;
      return function (i, a) {
        if (3 === o) throw Error("Generator is already running");
        if (4 === o) {
          if ("throw" === i) throw a;
          return {
            value: t,
            done: !0
          };
        }
        for (n.method = i, n.arg = a;;) {
          var u = n.delegate;
          if (u) {
            var c = d(u, n);
            if (c) {
              if (c === f) continue;
              return c;
            }
          }
          if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) {
            if (1 === o) throw o = 4, n.arg;
            n.dispatchException(n.arg);
          } else "return" === n.method && n.abrupt("return", n.arg);
          o = 3;
          var h = s(r, e, n);
          if ("normal" === h.type) {
            if (o = n.done ? 4 : 2, h.arg === f) continue;
            return {
              value: h.arg,
              done: n.done
            };
          }
          "throw" === h.type && (o = 4, n.method = "throw", n.arg = h.arg);
        }
      };
    }(r, n, new Context(o || [])), !0), a;
  }
  function s(t, r, e) {
    try {
      return {
        type: "normal",
        arg: t.call(r, e)
      };
    } catch (t) {
      return {
        type: "throw",
        arg: t
      };
    }
  }
  r.wrap = h;
  var f = {};
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}
  var l = {};
  c(l, i, function () {
    return this;
  });
  var p = Object.getPrototypeOf,
    y = p && p(p(x([])));
  y && y !== e && n.call(y, i) && (l = y);
  var v = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(l);
  function g(t) {
    ["next", "throw", "return"].forEach(function (r) {
      c(t, r, function (t) {
        return this._invoke(r, t);
      });
    });
  }
  function AsyncIterator(t, r) {
    function e(o, i, a, u) {
      var c = s(t[o], t, i);
      if ("throw" !== c.type) {
        var h = c.arg,
          f = h.value;
        return f && "object" == _typeof(f) && n.call(f, "__await") ? r.resolve(f.__await).then(function (t) {
          e("next", t, a, u);
        }, function (t) {
          e("throw", t, a, u);
        }) : r.resolve(f).then(function (t) {
          h.value = t, a(h);
        }, function (t) {
          return e("throw", t, a, u);
        });
      }
      u(c.arg);
    }
    var o;
    c(this, "_invoke", function (t, n) {
      function i() {
        return new r(function (r, o) {
          e(t, n, r, o);
        });
      }
      return o = o ? o.then(i, i) : i();
    }, !0);
  }
  function d(r, e) {
    var n = e.method,
      o = r.i[n];
    if (o === t) return e.delegate = null, "throw" === n && r.i["return"] && (e.method = "return", e.arg = t, d(r, e), "throw" === e.method) || "return" !== n && (e.method = "throw", e.arg = new TypeError("The iterator does not provide a '" + n + "' method")), f;
    var i = s(o, r.i, e.arg);
    if ("throw" === i.type) return e.method = "throw", e.arg = i.arg, e.delegate = null, f;
    var a = i.arg;
    return a ? a.done ? (e[r.r] = a.value, e.next = r.n, "return" !== e.method && (e.method = "next", e.arg = t), e.delegate = null, f) : a : (e.method = "throw", e.arg = new TypeError("iterator result is not an object"), e.delegate = null, f);
  }
  function w(t) {
    this.tryEntries.push(t);
  }
  function m(r) {
    var e = r[4] || {};
    e.type = "normal", e.arg = t, r[4] = e;
  }
  function Context(t) {
    this.tryEntries = [[-1]], t.forEach(w, this), this.reset(!0);
  }
  function x(r) {
    if (null != r) {
      var e = r[i];
      if (e) return e.call(r);
      if ("function" == typeof r.next) return r;
      if (!isNaN(r.length)) {
        var o = -1,
          a = function e() {
            for (; ++o < r.length;) if (n.call(r, o)) return e.value = r[o], e.done = !1, e;
            return e.value = t, e.done = !0, e;
          };
        return a.next = a;
      }
    }
    throw new TypeError(_typeof(r) + " is not iterable");
  }
  return GeneratorFunction.prototype = GeneratorFunctionPrototype, c(v, "constructor", GeneratorFunctionPrototype), c(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = c(GeneratorFunctionPrototype, u, "GeneratorFunction"), r.isGeneratorFunction = function (t) {
    var r = "function" == typeof t && t.constructor;
    return !!r && (r === GeneratorFunction || "GeneratorFunction" === (r.displayName || r.name));
  }, r.mark = function (t) {
    return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, c(t, u, "GeneratorFunction")), t.prototype = Object.create(v), t;
  }, r.awrap = function (t) {
    return {
      __await: t
    };
  }, g(AsyncIterator.prototype), c(AsyncIterator.prototype, a, function () {
    return this;
  }), r.AsyncIterator = AsyncIterator, r.async = function (t, e, n, o, i) {
    void 0 === i && (i = Promise);
    var a = new AsyncIterator(h(t, e, n, o), i);
    return r.isGeneratorFunction(e) ? a : a.next().then(function (t) {
      return t.done ? t.value : a.next();
    });
  }, g(v), c(v, u, "Generator"), c(v, i, function () {
    return this;
  }), c(v, "toString", function () {
    return "[object Generator]";
  }), r.keys = function (t) {
    var r = Object(t),
      e = [];
    for (var n in r) e.unshift(n);
    return function t() {
      for (; e.length;) if ((n = e.pop()) in r) return t.value = n, t.done = !1, t;
      return t.done = !0, t;
    };
  }, r.values = x, Context.prototype = {
    constructor: Context,
    reset: function reset(r) {
      if (this.prev = this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(m), !r) for (var e in this) "t" === e.charAt(0) && n.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = t);
    },
    stop: function stop() {
      this.done = !0;
      var t = this.tryEntries[0][4];
      if ("throw" === t.type) throw t.arg;
      return this.rval;
    },
    dispatchException: function dispatchException(r) {
      if (this.done) throw r;
      var e = this;
      function n(t) {
        a.type = "throw", a.arg = r, e.next = t;
      }
      for (var o = e.tryEntries.length - 1; o >= 0; --o) {
        var i = this.tryEntries[o],
          a = i[4],
          u = this.prev,
          c = i[1],
          h = i[2];
        if (-1 === i[0]) return n("end"), !1;
        if (!c && !h) throw Error("try statement without catch or finally");
        if (null != i[0] && i[0] <= u) {
          if (u < c) return this.method = "next", this.arg = t, n(c), !0;
          if (u < h) return n(h), !1;
        }
      }
    },
    abrupt: function abrupt(t, r) {
      for (var e = this.tryEntries.length - 1; e >= 0; --e) {
        var n = this.tryEntries[e];
        if (n[0] > -1 && n[0] <= this.prev && this.prev < n[2]) {
          var o = n;
          break;
        }
      }
      o && ("break" === t || "continue" === t) && o[0] <= r && r <= o[2] && (o = null);
      var i = o ? o[4] : {};
      return i.type = t, i.arg = r, o ? (this.method = "next", this.next = o[2], f) : this.complete(i);
    },
    complete: function complete(t, r) {
      if ("throw" === t.type) throw t.arg;
      return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && r && (this.next = r), f;
    },
    finish: function finish(t) {
      for (var r = this.tryEntries.length - 1; r >= 0; --r) {
        var e = this.tryEntries[r];
        if (e[2] === t) return this.complete(e[4], e[3]), m(e), f;
      }
    },
    "catch": function _catch(t) {
      for (var r = this.tryEntries.length - 1; r >= 0; --r) {
        var e = this.tryEntries[r];
        if (e[0] === t) {
          var n = e[4];
          if ("throw" === n.type) {
            var o = n.arg;
            m(e);
          }
          return o;
        }
      }
      throw Error("illegal catch attempt");
    },
    delegateYield: function delegateYield(r, e, n) {
      return this.delegate = {
        i: x(r),
        r: e,
        n: n
      }, "next" === this.method && (this.arg = t), f;
    }
  }, r;
}
System.register("chunks:///_virtual/advanceMonth.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./errors.ts", "./monthly.ts", "./annual.ts", "./departments.ts", "./annualEvent.ts", "./market.ts", "./statePrune.ts"], function (e) {
  var n, t, a, r, o, s, u, i, l, c, d;
  return {
    setters: [function (e) {
      n = e.createForOfIteratorHelperLoose;
    }, function (e) {
      t = e.cclegacy;
    }, function (e) {
      a = e.GameErrorCode;
    }, function (e) {
      r = e.settleMonth;
    }, function (e) {
      o = e.annualSettlement;
    }, function (e) {
      s = e.applyDueTransfers;
    }, function (e) {
      u = e.ensureAnnualEvent, i = e.monthlyDemandEventBps, l = e.applyEventForMonth;
    }, function (e) {
      c = e.annualDemand;
    }, function (e) {
      d = e.pruneStateHistory;
    }],
    execute: function execute() {
      function h(e) {
        return 12 * (e.gameYear - 1) + (e.gameMonth - 1);
      }
      function p(e, n, t) {
        return e + ":" + n + ":" + t;
      }
      e({
        advanceMonth: function advanceMonth(e, t) {
          if (!e.company) throw new Error(a.NOT_READY);
          if ("RUNNING" !== e.phase && "DISTRESS" !== e.phase) throw new Error(a.NOT_READY);
          var m = e.gameYear,
            y = e.gameMonth,
            f = h(e),
            g = p(e.runId, m, y);
          if (e.lastSettledMonthKey === g) throw new Error(a.MONTH_ALREADY_SETTLED);
          if (e.monthlyLedgersRolling.some(function (n) {
            return n.runId === e.runId && n.year === m && n.month === y;
          })) throw new Error(a.MONTH_ALREADY_SETTLED);
          var v = e.company.cashYuan;
          1 === y && void 0 === e.yearOpenCashYuan[m] && (e.yearOpenCashYuan[m] = v);
          var Y = u(e, t, m),
            E = i(Y, y),
            M = c(t, e.company.industry, m).annualDemandYuan,
            S = l(e, t, Y, y, M),
            D = r({
              state: e,
              cfg: t,
              industry: e.company.industry,
              year: m,
              month: y,
              monthIndex: f,
              acqMultiplierBps: 1e4,
              eventDemandBps: E,
              businessCapacityInvestmentYuan: e.company.businessCapacityInvestmentYuan,
              eventLossYuan: S
            }),
            I = {
              runId: e.runId,
              year: m,
              month: y,
              revenueYuan: D.revenue,
              directCostYuan: -D.directCost,
              otherOperatingCostYuan: -D.otherOperating,
              afterSalesCostYuan: -D.afterSales,
              fixedCostYuan: -D.fixed,
              payrollYuan: -D.payroll,
              recruitmentCostYuan: -D.recruitment,
              severanceCostYuan: -D.severance,
              deptSetupCostYuan: -D.deptSetup,
              eventCostYuan: -D.event,
              depreciationYuan: -D.depreciation,
              profitYuan: D.profit,
              cashDeltaYuan: D.cashDelta
            };
          e.company.cashYuan = v + D.unpaidCashDelta, e.lastSettledMonthKey = g, e.monthlyLedgersRolling.push(I), e.monthlyLedgersRolling.length > t.save.rollingMonthlyLedgers && (e.monthlyLedgersRolling = e.monthlyLedgersRolling.slice(-t.save.rollingMonthlyLedgers));
          e.pendingEntries = e.pendingEntries.filter(function (e) {
            return e.monthKey !== g;
          });
          for (var C, L = f + 1, O = n(e.employees); !(C = O()).done;) {
            var R = C.value;
            "PENDING_DISMISSAL" === R.status && null !== R.dismissedAtMonthIndex && R.dismissedAtMonthIndex <= L && (R.status = "DISMISSED");
          }
          s(e, f);
          var A = !1;
          if (12 === y) {
            var T;
            o(e, t, null != (T = e.yearOpenCashYuan[m]) ? T : v), d(e, t), A = !0, e.gameYear += 1, e.gameMonth = 1;
          } else e.gameMonth += 1;
          return {
            ledger: I,
            yearClosed: A,
            cashBefore: v
          };
        },
        monthIndexOfYear: h,
        monthKeyOf: p
      }), t._RF.push({}, "66588aGjgxO7Leoing93UmC", "advanceMonth", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/annual.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./leaderboard.ts"], function (n) {
  var e, a, t;
  return {
    setters: [function (n) {
      e = n.createForOfIteratorHelperLoose;
    }, function (n) {
      a = n.cclegacy;
    }, function (n) {
      t = n.advanceBotsOneYear;
    }],
    execute: function execute() {
      n("annualSettlement", function (n, a, s) {
        if (!n.company || !n.ceo) throw new Error("NOT_READY");
        var o = n.gameYear,
          i = n.monthlyLedgersRolling.filter(function (e) {
            return e.runId === n.runId && e.year === o;
          }),
          c = u(i.map(function (n) {
            return n.revenueYuan;
          })),
          l = u(i.map(function (n) {
            return n.directCostYuan;
          })),
          p = u(i.map(function (n) {
            return n.otherOperatingCostYuan;
          })),
          m = u(i.map(function (n) {
            return n.afterSalesCostYuan;
          })),
          f = u(i.map(function (n) {
            return n.fixedCostYuan;
          })),
          Y = u(i.map(function (n) {
            return n.payrollYuan;
          })),
          v = u(i.map(function (n) {
            return n.recruitmentCostYuan;
          })),
          d = u(i.map(function (n) {
            return n.severanceCostYuan;
          })),
          h = u(i.map(function (n) {
            return n.deptSetupCostYuan;
          })),
          C = u(i.map(function (n) {
            return n.eventCostYuan;
          })),
          b = u(i.map(function (n) {
            return n.depreciationYuan;
          })),
          g = u(i.map(function (n) {
            return n.profitYuan;
          })),
          y = n.company.cashYuan;
        g > 0 ? n.consecutiveProfitableYears += 1 : n.consecutiveProfitableYears = 0;
        n.consecutiveProfitableYears >= a.player.continuousProfitYearsForGoal && (n.target3YearsAchieved = !0);
        var k = r[n.ceo.trait],
          S = n.ceo;
        S.businessSkill = Math.min(100, S.businessSkill + k.business), S.managementSkill = Math.min(100, S.managementSkill + k.management), S.financeSkill = Math.min(100, S.financeSkill + k.finance);
        for (var R, A = a.recruitment.annualSkillGrowthDenominator, M = e(n.employees); !(R = M()).done;) {
          var O = R.value;
          if ("ACTIVE" === O.status) {
            var P = Math.max(1, Math.round(O.potential / A));
            O.skill = Math.min(100, O.skill + P);
          }
        }
        var B = n.employees.filter(function (n) {
            return "ACTIVE" === n.status;
          }).length,
          E = {
            year: o,
            revenueYuan: c,
            directCostYuan: l,
            otherOperatingCostYuan: p,
            afterSalesCostYuan: m,
            fixedCostYuan: f,
            payrollYuan: Y,
            recruitmentCostYuan: v,
            severanceCostYuan: d,
            deptSetupCostYuan: h,
            eventCostYuan: C,
            depreciationYuan: b,
            profitYuan: g,
            cashOpenYuan: s,
            cashCloseYuan: y,
            assetCloseYuan: y + n.company.businessAssetBookYuan,
            headcountClose: B,
            settled: !0
          };
        n.annualReports.push(E), n.annualReports.length > a.save.keepAnnualReports && (n.annualReports = n.annualReports.slice(-a.save.keepAnnualReports));
        return function (n, e) {
          var a = n.company;
          if (!a) return;
          var t = e.productivity.annualDepreciationBpsFromNextYear / 1e4,
            r = Math.round(a.businessAssetBookYuan * t);
          if (r <= 0) return;
          a.businessAssetBookYuan -= r, a.businessCapacityInvestmentYuan = Math.max(0, a.businessCapacityInvestmentYuan - r);
        }(n, a), t(n, a, o), E;
      }), a._RF.push({}, "db0acRenvhHP76J0COamrL+", "annual", void 0);
      var r = {
        BOLD: {
          business: 2,
          management: 1,
          finance: 1
        },
        STEADY: {
          business: 1,
          management: 1,
          finance: 2
        },
        PEOPLE: {
          business: 1,
          management: 2,
          finance: 1
        }
      };
      function u(n) {
        return n.reduce(function (n, e) {
          return n + e;
        }, 0);
      }
      a._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/annualEvent.ts", ["cc", "./rng.ts", "./monthEntry.ts"], function (e) {
  var n, t, a, u;
  return {
    setters: [function (e) {
      n = e.cclegacy;
    }, function (e) {
      t = e.Rng, a = e.deriveSeed;
    }, function (e) {
      u = e.monthIndexOf;
    }],
    execute: function execute() {
      e({
        annualEventKey: p,
        applyEventForMonth: function applyEventForMonth(e, n, t, a, r) {
          if (!t.happened || t.applied || t.month !== a) return 0;
          var p = 0;
          if ("COST_RISE" === t.type || "ASSET_LOSS" === t.type) p = Math.round(r / 12 * (t.effectBps / 1e4)), t.amountYuan = p;else if ("EMPLOYEE_LEAVE" === t.type && t.employeeId) {
            var l = e.employees.find(function (e) {
              return e.employeeId === t.employeeId;
            });
            l && "ACTIVE" === l.status && (l.leftVoluntarily = !0, l.status = "PENDING_DISMISSAL", l.dismissedAtMonthIndex = u(e) + 1);
          }
          return t.applied = !0, p;
        },
        ensureAnnualEvent: function ensureAnnualEvent(e, n, t) {
          var a = e.annualEvents.find(function (n) {
            return n.key === p(e, t);
          });
          if (a) return a;
          var u = l(e, n, t);
          e.annualEvents.push(u), e.annualEvents.length > n.save.keepRecentEventDetails + 40 && (e.annualEvents = e.annualEvents.slice(-(n.save.keepRecentEventDetails + 40)));
          return u;
        },
        makeEventForTest: function makeEventForTest(e, n, t, a, u, r) {
          var l = {
            key: p(e, n),
            year: n,
            happened: !0,
            type: t,
            month: a,
            effectBps: u,
            amountYuan: 0,
            employeeId: null == r ? void 0 : r.employeeId,
            applied: !1
          };
          return e.annualEvents = e.annualEvents.filter(function (e) {
            return e.key !== l.key;
          }), e.annualEvents.push(l), l;
        },
        monthlyDemandEventBps: function monthlyDemandEventBps(e, n) {
          return e && e.happened && !e.applied ? "ORDER_SURGE" !== e.type && "ORDER_DROP" !== e.type || e.month !== n ? 0 : "ORDER_SURGE" === e.type ? e.effectBps : -e.effectBps : 0;
        },
        planAnnualEvent: l
      }), n._RF.push({}, "d9565mdbt1HJpbDT0k6vj3T", "annualEvent", void 0);
      var r = ["ORDER_SURGE", "ORDER_DROP", "COST_RISE", "EMPLOYEE_LEAVE", "ASSET_LOSS"];
      function p(e, n) {
        return e.runId + ":" + n;
      }
      function l(e, n, u) {
        var l = e.annualEvents.find(function (n) {
          return n.key === p(e, u);
        });
        if (l) return l;
        var i = function (e, n) {
            return new t(a(e.seed, e.runId, n, "event"));
          }(e, u),
          s = i.nextInt(1, 1e4),
          E = p(e, u);
        if (u <= 1 || s > n.risk.eventAnnualChanceBps) return {
          key: E,
          year: u,
          happened: !1,
          type: null,
          month: 0,
          effectBps: 0,
          amountYuan: 0,
          applied: !0
        };
        var f,
          o = i.pick(r),
          v = i.nextInt(1, 12),
          d = i.nextInt(n.risk.eventEffectMinBps, n.risk.eventEffectMaxBps);
        if ("EMPLOYEE_LEAVE" === o) {
          var c,
            y = e.employees.filter(function (e) {
              return "ACTIVE" === e.status;
            });
          if (0 === y.length) return {
            key: E,
            year: u,
            happened: !1,
            type: null,
            month: 0,
            effectBps: 0,
            amountYuan: 0,
            applied: !0
          };
          f = null == (c = y[i.nextInt(0, y.length - 1)]) ? void 0 : c.employeeId;
        }
        return {
          key: E,
          year: u,
          happened: !0,
          type: o,
          month: v,
          effectBps: d,
          amountYuan: 0,
          employeeId: f,
          applied: !1
        };
      }
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/AppView.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./GameFacade.ts", "./types.ts", "./PlatformFactory.ts", "./SafeArea2.ts", "./loadConfig.ts", "./loadRuntimeConfig.ts", "./runtimeConfig.ts", "./AuthService.ts", "./privacyConsent.ts", "./errors.ts", "./BootTrap.ts", "./UiFactory.ts", "./theme.ts", "./AudioManager.ts"], function (t) {
  var e, n, o, i, r, a, s, d, l, h, c, f, u, p, y, m, g, x, P, v, S, C, I, w, T, E, k, z, b, H, W, O, R, A, N, M, Y;
  return {
    setters: [function (t) {
      e = t.inheritsLoose, n = t.createForOfIteratorHelperLoose, o = t.asyncToGenerator;
    }, function (t) {
      i = t.cclegacy, r = t.Color, a = t.Node, s = t.UITransform, d = t.Size, l = t.Vec3, h = t.view, c = t.Widget, f = t.Graphics, u = t.Component, p = t.profiler;
    }, function (t) {
      y = t.GameFacade;
    }, function (t) {
      m = t.SUPPORT_DEPARTMENTS;
    }, function (t) {
      g = t.createPlatform;
    }, function (t) {
      x = t.resolveSafeAreaTransform;
    }, function (t) {
      P = t.loadEconomyConfig;
    }, function (t) {
      v = t.loadRuntimeConfig;
    }, function (t) {
      S = t.getRuntimeConfig;
    }, function (t) {
      C = t.AuthService;
    }, function (t) {
      I = t.hasAcceptedPrivacy, w = t.acceptPrivacy;
    }, function (t) {
      T = t.GameError;
    }, function (t) {
      E = t.bootTrapWatchdog, k = t.bootTrapReady, z = t.bootTrapError;
    }, function (t) {
      b = t.createRect, H = t.createLabel, W = t.createButton, O = t.moneyText, R = t.stretchToParent;
    }, function (t) {
      A = t.THEME, N = t.DESIGN_WIDTH, M = t.DESIGN_HEIGHT;
    }, function (t) {
      Y = t.audioManager;
    }],
    execute: function execute() {
      i._RF.push({}, "d5d4f16CWdJPq2W/JRqAaJ+", "AppView", void 0);
      var D = {
          TRADE: "电商贸易",
          SOFTWARE: "软件科技",
          SERVICE: "企业服务"
        },
        L = {
          BOLD: {
            name: "进取",
            desc: "每年 商业+2 管理+1 财务+1，擅长开发市场"
          },
          STEADY: {
            name: "稳健",
            desc: "每年 商业+1 管理+1 财务+2，擅长资金管理"
          },
          PEOPLE: {
            name: "亲和",
            desc: "每年 商业+1 管理+2 财务+1，擅长团队协作"
          }
        },
        B = {
          PROCUREMENT: {
            name: "采购部",
            desc: "降低可适用的直接采购成本"
          },
          CUSTOMER_SERVICE: {
            name: "客服部",
            desc: "降低售后费用"
          },
          MARKETING: {
            name: "市场部",
            desc: "提升潜在订单（受产能上限）"
          },
          FINANCE: {
            name: "财务部",
            desc: "降低固定管理费用"
          },
          HR: {
            name: "人力资源部",
            desc: "提升业务产能、降低招聘费"
          }
        },
        U = {
          STEADY: {
            name: "稳健",
            desc: "ROI≥1.0，保留6个月刚性费用"
          },
          GROWTH: {
            name: "扩张",
            desc: "ROI≥0.8，适度提前准备产能"
          },
          PROFIT: {
            name: "利润优先",
            desc: "ROI≥1.2，保留9个月刚性费用"
          }
        },
        F = 0;
      function G(t) {
        return F += 1, t + "_" + Date.now().toString(36) + "_" + F;
      }
      t("AppView", function (t) {
        function i() {
          for (var e, n = arguments.length, o = new Array(n), i = 0; i < n; i++) o[i] = arguments[i];
          return (e = t.call.apply(t, [this].concat(o)) || this).facade = void 0, e.platform = null, e.auth = null, e.authed = !1, e.root = void 0, e.toastNode = null, e.selectedIndustry = "TRADE", e.selectedTrait = "BOLD", e.customCompanyName = "", e.customCeoName = "", e.randomCompanyNames = [], e.selectedNameIndex = 0, e.activeTab = "COMPANY", e.rankMode = "assets", e.pendingOffer = null, e.lastForegroundMs = 0, e.lastBackgroundMs = 0, e.layoffToken = null, e;
        }
        e(i, t);
        var u = i.prototype;
        return u.start = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
            var t, e, n;
            return _regeneratorRuntime().wrap(function _callee$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  t = this;
                  E(this.node);
                  _context2.prev = 2;
                  p.hideStats(), Y.loadSettings();
                  e = g();
                  this.platform = e;
                  _context2.next = 8;
                  return Promise.all([P(), v()]);
                case 8:
                  n = _context2.sent[0];
                  this.auth = new C(e, {
                    endpoint: S().authEndpoint
                  });
                  _context2.next = 12;
                  return y.bootstrap(e, n);
                case 12:
                  this.facade = _context2.sent;
                  this.lastForegroundMs = Date.now();
                  this.buildRoot();
                  this.render();
                  _context2.next = 18;
                  return I(e);
                case 18:
                  if (!_context2.sent) {
                    _context2.next = 22;
                    break;
                  }
                  this.ensurePlatformLogin(!1);
                  _context2.next = 23;
                  break;
                case 22:
                  this.renderPrivacyDialog();
                case 23:
                  k();
                  this.node.once(a.EventType.TOUCH_START, function () {
                    Y.unlock(), "RUNNING" === t.state().phase ? Y.playBgm("operation") : Y.playBgm("startup");
                  });
                  this.schedule(this.clockTick, .2);
                  e.onHide(function () {
                    t.lastBackgroundMs = Date.now(), Y.onAppHide(), t.toast("已自动保存");
                  });
                  e.onShow(function () {
                    return t.onReturnForeground();
                  });
                  _context2.next = 33;
                  break;
                case 30:
                  _context2.prev = 30;
                  _context2.t0 = _context2["catch"](2);
                  throw z(_context2.t0), _context2.t0;
                case 33:
                case "end":
                  return _context2.stop();
              }
            }, _callee, this, [[2, 30]]);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), u.ensurePlatformLogin = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2(t) {
            var e, n;
            return _regeneratorRuntime().wrap(function _callee2$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                  if (!(this.auth && !this.authed)) {
                    _context3.next = 15;
                    break;
                  }
                  _context3.prev = 1;
                  _context3.next = 4;
                  return this.auth.ensureAuthenticated();
                case 4:
                  e = _context3.sent;
                  this.authed = !0, t && "taptap" !== e.kind || this.toast("平台登录成功");
                  _context3.next = 15;
                  break;
                case 8:
                  _context3.prev = 8;
                  _context3.t0 = _context3["catch"](1);
                  this.authed = !1;
                  n = _context3.t0 instanceof T ? _context3.t0.code : "";
                  if (!t) {
                    _context3.next = 14;
                    break;
                  }
                  return _context3.abrupt("return");
                case 14:
                  "PLATFORM_UNAVAILABLE" === n ? this.toast("网络或登录服务暂不可用，可先本地游玩") : this.renderLoginRetry();
                case 15:
                case "end":
                  return _context3.stop();
              }
            }, _callee2, this, [[1, 8]]);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.renderLoginRetry = function () {
          var t = this,
            e = this.modalOverlay();
          b({
            width: 300,
            height: 250,
            color: r.WHITE,
            radius: 12,
            parent: e
          }).setPosition(0, 0), H({
            text: "平台登录未完成",
            fontSize: 18,
            bold: !0,
            parent: e
          }).setPosition(0, 92), H({
            text: "TapTap 登录暂时失败。\n你的经营进度只保存在本机，不会丢失。\n可重试登录，或先进入单机游玩。",
            fontSize: 13,
            color: A.text,
            width: 250,
            lineHeight: 22,
            parent: e
          }).setPosition(0, 20), W({
            text: "重试登录",
            width: 220,
            height: 46,
            parent: e,
            onClick: function onClick() {
              e.destroy(), t.ensurePlatformLogin(!1);
            }
          }).setPosition(0, -56), W({
            text: "先进入单机游玩",
            width: 220,
            height: 40,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.primary,
            parent: e,
            onClick: function onClick() {
              return e.destroy();
            }
          }).setPosition(0, -106);
        }, u.renderPrivacyDialog = function () {
          var t = this,
            e = this.modalOverlay(),
            n = S().privacyPolicyUrl.length > 0,
            o = n ? 420 : 396;
          b({
            width: 312,
            height: o,
            color: r.WHITE,
            radius: 12,
            parent: e
          }).setPosition(0, 0), H({
            text: "隐私保护提示",
            fontSize: 19,
            bold: !0,
            parent: e
          }).setPosition(0, o / 2 - 28), H({
            text: "《我是CEO》是本地单机经营游戏。\n· 公司、员工、财务等经营数据仅保存在本设备，不上传、不采集；\n· 无广告、无内购、不申请位置/相机/麦克风等无关权限；\n· 平台登录仅用于完成 TapTap 必要的身份核验；\n· 关闭公司只清除本机本局经营档，不注销平台账号。\n点击“同意并继续”即表示你已阅读并同意《隐私政策》。",
            fontSize: 12,
            color: A.text,
            width: 268,
            lineHeight: 19,
            align: "left",
            parent: e
          }).setPosition(0, n ? 42 : 30), n && W({
            text: "查看《隐私政策》",
            width: 200,
            height: 38,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.primary,
            parent: e,
            onClick: function onClick() {
              return t.openPrivacyPolicy(S().privacyPolicyUrl);
            }
          }).setPosition(0, -o / 2 + 104), W({
            text: "同意并继续",
            width: 240,
            height: 48,
            parent: e,
            onClick: function onClick() {
              t.onAcceptPrivacy(e);
            }
          }).setPosition(0, -o / 2 + 34);
        }, u.onAcceptPrivacy = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(t) {
            return _regeneratorRuntime().wrap(function _callee3$(_context4) {
              while (1) switch (_context4.prev = _context4.next) {
                case 0:
                  _context4.t0 = this.platform;
                  if (!_context4.t0) {
                    _context4.next = 8;
                    break;
                  }
                  _context4.next = 4;
                  return w(this.platform);
                case 4:
                  t.destroy();
                  _context4.next = 7;
                  return this.ensurePlatformLogin(!1);
                case 7:
                  this.render();
                case 8:
                case "end":
                  return _context4.stop();
              }
            }, _callee3, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.openPrivacyPolicy = function (t) {
          var e = this.modalOverlay();
          b({
            width: 290,
            height: 190,
            color: r.WHITE,
            radius: 12,
            parent: e
          }).setPosition(0, 0), H({
            text: "隐私政策链接",
            fontSize: 17,
            bold: !0,
            parent: e
          }).setPosition(0, 66), H({
            text: t,
            fontSize: 12,
            color: A.primary,
            width: 240,
            parent: e
          }).setPosition(0, 16), H({
            text: "如未自动打开，请在浏览器访问以上地址查看完整政策。",
            fontSize: 11,
            color: A.textWeak,
            width: 240,
            parent: e
          }).setPosition(0, -24), W({
            text: "知道了",
            width: 180,
            height: 42,
            parent: e,
            onClick: function onClick() {
              return e.destroy();
            }
          }).setPosition(0, -68);
          try {
            var n = globalThis;
            null == n.open || n.open(t);
          } catch (t) {}
        }, u.onReturnForeground = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
            var t, e, n, o;
            return _regeneratorRuntime().wrap(function _callee4$(_context5) {
              while (1) switch (_context5.prev = _context5.next) {
                case 0:
                  if (!this.facade) {
                    _context5.next = 9;
                    break;
                  }
                  t = Date.now(), e = this.lastBackgroundMs || this.lastForegroundMs;
                  if (!(this.lastForegroundMs = t, Y.onAppShow(), this.ensurePlatformLogin(!0), e && !(t <= e))) {
                    _context5.next = 9;
                    break;
                  }
                  n = this.facade.getState();
                  if (!("RUNNING" === n.phase && 0 !== n.speed)) {
                    _context5.next = 9;
                    break;
                  }
                  _context5.next = 7;
                  return this.facade.settleOffline(t);
                case 7:
                  o = _context5.sent;
                  o.ok && o.payload.monthsSettled > 0 && (this.renderOfflineSummary(o.payload), this.render());
                case 9:
                case "end":
                  return _context5.stop();
              }
            }, _callee4, this);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), u.renderOfflineSummary = function (t) {
          var e = this.modalOverlay();
          b({
            width: 310,
            height: 260,
            color: r.WHITE,
            radius: 12,
            parent: e
          }).setPosition(0, 0), H({
            text: "欢迎回来",
            fontSize: 20,
            bold: !0,
            parent: e
          }).setPosition(0, 92), H({
            text: "离线期间结算 " + t.monthsSettled + " 个月" + (t.yearsClosed.length ? "（含 " + t.yearsClosed.length + " 个年度结算）" : "") + "\n现金：" + O(t.cashBefore) + " → " + O(t.cashAfter) + "\n净变化：" + O(t.cashAfter - t.cashBefore),
            fontSize: 14,
            color: A.text,
            width: 260,
            lineHeight: 24,
            parent: e
          }).setPosition(0, 20), W({
            text: "知道了",
            width: 180,
            height: 46,
            parent: e,
            onClick: function onClick() {
              return e.destroy();
            }
          }).setPosition(0, -84);
        }, u.clockTick = function () {
          var t = this;
          if (this.facade) {
            var e = this.facade.getState();
            "RUNNING" === e.phase && 0 !== e.speed && this.facade.advanceRealTime(200, e.runId).then(function (o) {
              if (o.ok && (0 !== o.payload.monthsAdvanced || 0 !== o.payload.yearsClosed.length)) {
                for (var i, r = n(o.payload.yearsClosed); !(i = r()).done;) {
                  var a = i.value,
                    s = t.facade.getAnnualReport(a);
                  s && (s.profitYuan >= 0 ? Y.yearProfit() : Y.yearLoss());
                }
                t.facade.getState().target3YearsAchieved && !e.target3YearsAchieved && Y.threeYearGoal(), t.render();
              }
            })["catch"](function () {});
          }
        }, u.buildRoot = function () {
          var t = this.node,
            e = b({
              name: "Backdrop",
              width: N,
              height: M,
              color: A.bg,
              radius: 0,
              parent: t
            });
          e.setPosition(0, 0), R(e), this.root = new a("AppRoot"), this.root.parent = t, this.root.addComponent(s).setContentSize(new d(N, M));
          var n = !1;
          if (this.platform) {
            var o = x(this.platform);
            o.applied && (this.root.setScale(new l(o.scale, o.scale, 1)), this.root.setPosition(o.offsetX, o.offsetY, 0), n = !0);
          }
          if (!n) {
            var i = h.getVisibleSize(),
              r = i.height > 0 ? i.height / M : 1;
            r < .98 && this.root.setScale(new l(r, r, 1));
          }
          var f = this.root.addComponent(c);
          f.isAlignTop = f.isAlignBottom = f.isAlignLeft = f.isAlignRight = !0, f.top = f.bottom = f.left = f.right = 0, f.enabled = !1;
        }, u.clearRoot = function () {
          this.root.destroyAllChildren(), this.toastNode = null;
        }, u.state = function () {
          return this.facade.getState();
        }, u.render = function () {
          this.clearRoot();
          var t = this.state();
          "CREATING" === t.phase ? ("" === this.customCompanyName && 0 === this.randomCompanyNames.length && (this.selectedIndustry = "TRADE", this.rollNames()), this.renderCreateCompany()) : "HIRING_INITIAL" === t.phase ? this.renderInitialHiring() : (this.renderMainShell(), "DISTRESS" === t.phase && this.renderDistressDialog());
        }, u.renderDistressDialog = function () {
          var t = this,
            e = this.state(),
            n = this.facade.assessRisk(),
            o = this.modalOverlay();
          b({
            width: 320,
            height: 320,
            color: r.WHITE,
            radius: 12,
            parent: o
          }).setPosition(0, 0), H({
            text: "经营困难",
            fontSize: 20,
            bold: !0,
            color: A.danger,
            parent: o
          }).setPosition(0, 122);
          var i = e.rescueCapitalUsed ? "救助资本已使用，无法再次领取。\n请裁员、降低工资支出或关闭公司重开。" : "当前现金 " + O(n.cash) + "，下月必要支出约 " + O(n.nextMonthNeed) + "。\n月结已暂停，时间不会继续推进。";
          H({
            text: i,
            fontSize: 13,
            color: A.text,
            width: 266,
            lineHeight: 22,
            parent: o
          }).setPosition(0, 50), e.rescueCapitalUsed || W({
            text: "领取 10 万元 CEO 救助资本",
            width: 250,
            height: 48,
            color: A.secondary,
            parent: o,
            onClick: function onClick() {
              t.onRescue(o);
            }
          }).setPosition(0, -56), W({
            text: "我再想想（去裁员/调整）",
            width: 220,
            height: 42,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.text,
            parent: o,
            onClick: function onClick() {
              return o.destroy();
            }
          }).setPosition(0, -112);
        }, u.onRescue = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5(t) {
            var e, n;
            return _regeneratorRuntime().wrap(function _callee5$(_context6) {
              while (1) switch (_context6.prev = _context6.next) {
                case 0:
                  e = this.state();
                  _context6.next = 3;
                  return this.facade.injectRescueCapital({
                    commandId: G("rescue"),
                    expectedRunId: e.runId
                  });
                case 3:
                  n = _context6.sent;
                  t.destroy(), n.ok ? (this.toast("已到账救助资本 " + O(n.payload.amountYuan) + "（不计收入/利润）"), this.render()) : this.toast(n.displayMessage);
                case 5:
                case "end":
                  return _context6.stop();
              }
            }, _callee5, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.rollNames = function () {
          var t = this.facade.rollCompanyNames(this.selectedIndustry, 3);
          this.randomCompanyNames = Array.from(t).map(function (t) {
            return String(t);
          }), this.selectedNameIndex = 0;
        }, u.renderCreateCompany = function () {
          var t,
            e = this,
            n = this.fullPanel();
          H({
            text: "《我是CEO》",
            fontSize: 26,
            bold: !0,
            color: A.primary,
            parent: n
          }).setPosition(0, 340), H({
            text: "1/3 创建公司",
            fontSize: 13,
            color: A.textWeak,
            parent: n
          }).setPosition(0, 308), H({
            text: "选择主营行业",
            fontSize: 14,
            bold: !0,
            parent: n
          }).setPosition(0, 268), H({
            text: "（创建后不可更换）",
            fontSize: 11,
            color: A.textWeak,
            parent: n
          }).setPosition(0, 250), Object.keys(D).forEach(function (t, o) {
            var i = e.selectedIndustry === t;
            W({
              text: D[t],
              width: 320,
              height: 48,
              color: i ? A.primary : r.WHITE,
              textColor: i ? r.WHITE : A.text,
              parent: n,
              onClick: function onClick() {
                e.selectedIndustry = t, e.rollNames(), e.render();
              }
            }).setPosition(0, 222 - 56 * o);
          }), H({
            text: "公司名称",
            fontSize: 14,
            bold: !0,
            parent: n
          }).setPosition(0, 56), this.randomCompanyNames.forEach(function (t, o) {
            var i = e.selectedNameIndex === o;
            W({
              text: t,
              width: 320,
              height: 44,
              fontSize: 13,
              color: i ? A.secondary : r.WHITE,
              textColor: i ? r.WHITE : A.text,
              parent: n,
              onClick: function onClick() {
                e.selectedNameIndex = o, e.render();
              }
            }).setPosition(0, 20 - 54 * o);
          }), W({
            text: "换一批",
            width: 100,
            height: 38,
            color: r.WHITE,
            textColor: A.primary,
            fontSize: 13,
            parent: n,
            onClick: function onClick() {
              e.rollNames(), e.render();
            }
          }).setPosition(0, -178), H({
            text: "（也可在后续版本使用自定义名称）",
            fontSize: 11,
            color: A.textWeak,
            width: 320,
            parent: n
          }).setPosition(0, -214);
          var o = null != (t = this.randomCompanyNames[this.selectedNameIndex]) ? t : "";
          W({
            text: "下一步：创建 CEO",
            width: 320,
            height: 50,
            parent: n,
            disabled: o.length < 2,
            onClick: function onClick() {
              return e.renderCreateCeo();
            }
          }).setPosition(0, -330);
        }, u.renderCreateCeo = function () {
          var t = this,
            e = this.fullPanel();
          H({
            text: "《我是CEO》",
            fontSize: 26,
            bold: !0,
            color: A.primary,
            parent: e
          }).setPosition(0, 340), H({
            text: "2/3 设定 CEO",
            fontSize: 13,
            color: A.textWeak,
            parent: e
          }).setPosition(0, 308), H({
            text: "CEO 姓名",
            fontSize: 14,
            bold: !0,
            parent: e
          }).setPosition(0, 262), this.customCeoName = this.customCeoName || "CEO" + Math.floor(900 * Math.random() + 100), H({
            text: this.customCeoName,
            fontSize: 16,
            color: A.primary,
            parent: e
          }).setPosition(0, 232), W({
            text: "随机姓名",
            width: 110,
            height: 36,
            color: r.WHITE,
            textColor: A.primary,
            fontSize: 13,
            parent: e,
            onClick: function onClick() {
              t.customCeoName = "CEO" + Math.floor(900 * Math.random() + 100), t.render();
            }
          }).setPosition(0, 198), H({
            text: "选择性格（决定年度成长方向）",
            fontSize: 14,
            bold: !0,
            parent: e
          }).setPosition(0, 150), Object.keys(L).forEach(function (n, o) {
            var i = L[n],
              s = t.selectedTrait === n,
              d = b({
                width: 330,
                height: 78,
                color: s ? new r().fromHEX("#EAF1FB") : r.WHITE,
                radius: 8,
                parent: e
              });
            d.setPosition(0, 100 - 92 * o), d.on(a.EventType.TOUCH_END, function () {
              t.selectedTrait = n, t.render();
            }), H({
              text: i.name,
              fontSize: 15,
              bold: !0,
              color: s ? A.primary : A.text,
              align: "left",
              width: 80,
              parent: d
            }).setPosition(-115, 18), H({
              text: i.desc,
              fontSize: 11,
              color: A.textWeak,
              align: "left",
              width: 220,
              parent: d
            }).setPosition(20, -10);
          }), H({
            text: "初始能力：商业 50 ｜ 管理 50 ｜ 财务 50",
            fontSize: 12,
            color: A.textWeak,
            parent: e
          }).setPosition(0, -180), W({
            text: "上一步",
            width: 150,
            height: 48,
            color: r.WHITE,
            textColor: A.text,
            parent: e,
            onClick: function onClick() {
              return t.render();
            }
          }).setPosition(-85, -300), W({
            text: "下一步：招聘员工",
            width: 150,
            height: 48,
            parent: e,
            onClick: function onClick() {
              t.submitCreateCompany();
            }
          }).setPosition(85, -300);
        }, u.submitCreateCompany = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
            var t, e, n, o;
            return _regeneratorRuntime().wrap(function _callee6$(_context7) {
              while (1) switch (_context7.prev = _context7.next) {
                case 0:
                  e = this.state();
                  n = null != (t = this.randomCompanyNames[this.selectedNameIndex]) ? t : "";
                  _context7.next = 4;
                  return this.facade.createCompany({
                    companyName: n,
                    industry: this.selectedIndustry,
                    ceoName: this.customCeoName,
                    ceoTrait: this.selectedTrait
                  }, {
                    commandId: G("create"),
                    expectedRunId: e.runId
                  });
                case 4:
                  o = _context7.sent;
                  o.ok ? this.render() : this.toast(o.displayMessage);
                case 6:
                case "end":
                  return _context7.stop();
              }
            }, _callee6, this);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), u.renderInitialHiring = function () {
          var t,
            e,
            n,
            o = this,
            i = this.fullPanel(),
            a = this.state();
          H({
            text: "3/3 初始招聘",
            fontSize: 22,
            bold: !0,
            color: A.primary,
            parent: i
          }).setPosition(0, 350), H({
            text: "已录用 " + a.onboarding.initialHiresCompleted + "/2（开始经营前需招聘 2 人）",
            fontSize: 13,
            color: A.textWeak,
            parent: i
          }).setPosition(0, 318), H({
            text: "现金 " + O(null != (t = null == (e = a.company) ? void 0 : e.cashYuan) ? t : 0),
            fontSize: 14,
            bold: !0,
            parent: i
          }).setPosition(0, 288);
          var s = null == (n = a.departments[0]) ? void 0 : n.deptId;
          if (s) {
            this.pendingOffer = this.facade.getOffer(s), H({
              text: "招聘费 = 1 个月月薪（确认时立即支付）",
              fontSize: 11,
              color: A.textWeak,
              width: 330,
              parent: i
            }).setPosition(0, 262), this.pendingOffer.candidates.forEach(function (t, e) {
              var n = b({
                width: 335,
                height: 112,
                color: r.WHITE,
                radius: 8,
                parent: i
              });
              n.setPosition(0, 196 - 118 * e);
              var a = "A" === t.archetype ? "即战力" : "B" === t.archetype ? "潜力股" : "经济型";
              H({
                text: t.name + "（" + a + "）",
                fontSize: 15,
                bold: !0,
                align: "left",
                width: 200,
                parent: n
              }).setPosition(-60, 36), H({
                text: "能力 " + t.skill + "  潜力 " + t.potential + "  协作 " + t.teamwork,
                fontSize: 12,
                align: "left",
                color: A.textWeak,
                width: 300,
                parent: n
              }).setPosition(-10, 10), H({
                text: "月薪 " + O(t.salaryMonthlyYuan) + " ｜ 招聘费 " + O(t.salaryMonthlyYuan),
                fontSize: 12,
                align: "left",
                color: A.primary,
                width: 230,
                parent: n
              }).setPosition(-42, -16), W({
                text: "录用",
                width: 72,
                height: 38,
                fontSize: 13,
                parent: n,
                onClick: function onClick() {
                  o.hireInitial(t.candidateId);
                }
              }).setPosition(124, -32);
            });
            var d = a.onboarding.initialHiresCompleted >= 2;
            W({
              text: d ? "进入公司" : "完成首聘后进入",
              width: 320,
              height: 50,
              parent: i,
              disabled: !d,
              onClick: function onClick() {
                o.startClock();
              }
            }).setPosition(0, -360);
          } else this.toast("部门数据异常");
        }, u.hireInitial = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7(t) {
            var e, n, o, i, r, a;
            return _regeneratorRuntime().wrap(function _callee7$(_context8) {
              while (1) switch (_context8.prev = _context8.next) {
                case 0:
                  o = this.state(), i = null == (e = o.departments[0]) ? void 0 : e.deptId, r = null == (n = this.pendingOffer) ? void 0 : n.offerId;
                  if (!(i && r)) {
                    _context8.next = 6;
                    break;
                  }
                  _context8.next = 4;
                  return this.facade.hireEmployee({
                    offerId: r,
                    candidateId: t,
                    departmentId: i
                  }, {
                    commandId: G("hire"),
                    expectedRunId: o.runId
                  });
                case 4:
                  a = _context8.sent;
                  a.ok ? (this.toast("已录用，支付招聘费 " + O(a.payload.feePaidYuan)), this.render()) : this.toast(a.displayMessage);
                case 6:
                case "end":
                  return _context8.stop();
              }
            }, _callee7, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.startClock = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
            var t, e;
            return _regeneratorRuntime().wrap(function _callee8$(_context9) {
              while (1) switch (_context9.prev = _context9.next) {
                case 0:
                  t = this.state();
                  _context9.next = 3;
                  return this.facade.startOperating({
                    commandId: G("start"),
                    expectedRunId: t.runId
                  });
                case 3:
                  e = _context9.sent;
                  e.ok ? this.render() : this.toast(e.displayMessage);
                case 5:
                case "end":
                  return _context9.stop();
              }
            }, _callee8, this);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), u.renderMainShell = function () {
          var t = this.fullPanel(),
            e = new a("Body");
          e.parent = t, e.addComponent(s).setContentSize(new d(375, 700)), e.setPosition(0, 0), "COMPANY" === this.activeTab ? this.renderCompanyTab(e) : "DEPARTMENT" === this.activeTab ? this.renderDepartmentTab(e) : "TALENT" === this.activeTab ? this.renderTalentTab(e) : this.renderRankTab(e), this.renderBottomTabs(t);
        }, u.renderCompanyTab = function (t) {
          var e,
            n,
            o,
            i,
            a,
            s,
            d,
            l = this,
            h = this.state(),
            c = h.company;
          if (c) {
            b({
              width: 375,
              height: 88,
              color: A.primary,
              radius: 0,
              parent: t
            }).setPosition(0, 356), H({
              text: c.name,
              fontSize: 17,
              bold: !0,
              color: r.WHITE,
              width: 240,
              parent: t
            }).setPosition(-38, 372), H({
              text: D[c.industry] + " · 创业第 " + h.gameYear + " 年 · 第 " + h.gameMonth + " 月",
              fontSize: 11,
              color: new r(220, 230, 245),
              parent: t
            }).setPosition(-38, 348), W({
              text: "设置",
              width: 56,
              height: 34,
              fontSize: 12,
              color: new r(255, 255, 255, 40),
              parent: t,
              onClick: function onClick() {
                return l.renderSettings();
              }
            }).setPosition(145, 360);
            var f = this.facade.getYearLedgers(h.gameYear),
              u = f.reduce(function (t, e) {
                return t + e.revenueYuan;
              }, 0),
              p = f.reduce(function (t, e) {
                return t + e.profitYuan;
              }, 0),
              y = p < 0 ? A.danger : A.profit;
            [["现金", O(c.cashYuan), A.text], ["本年收入", O(u), A.text], ["本年利润", (p < 0 ? "-" : "") + O(Math.abs(p)), y]].forEach(function (e, n) {
              var o = e[0],
                i = e[1],
                a = e[2],
                s = b({
                  width: 112,
                  height: 78,
                  color: r.WHITE,
                  radius: 8,
                  parent: t
                });
              s.setPosition(120 * n - 120, 276), H({
                text: o,
                fontSize: 12,
                color: A.textWeak,
                parent: s
              }).setPosition(0, 20), H({
                text: i,
                fontSize: 14,
                bold: !0,
                color: a,
                width: 104,
                parent: s
              }).setPosition(0, -8);
            }), this.renderTimeControl(t, 210);
            var m = b({
              width: 343,
              height: 56,
              color: r.WHITE,
              radius: 8,
              parent: t
            });
            m.setPosition(0, 146), H({
              text: (null != (e = null == (n = h.ceo) ? void 0 : n.name) ? e : "") + "（" + L[null != (o = null == (i = h.ceo) ? void 0 : i.trait) ? o : "STEADY"].name + "）",
              fontSize: 13,
              bold: !0,
              align: "left",
              width: 160,
              parent: m
            }).setPosition(-84, 8), H({
              text: "商业 " + (null == (a = h.ceo) ? void 0 : a.businessSkill) + " · 管理 " + (null == (s = h.ceo) ? void 0 : s.managementSkill) + " · 财务 " + (null == (d = h.ceo) ? void 0 : d.financeSkill),
              fontSize: 12,
              color: A.textWeak,
              align: "left",
              width: 220,
              parent: m
            }).setPosition(-56, -12), H({
              text: "员工 " + h.employees.length + " 人",
              fontSize: 12,
              color: A.primary,
              width: 90,
              parent: m
            }).setPosition(118, 0);
            var g = b({
              width: 343,
              height: 120,
              color: r.WHITE,
              radius: 8,
              parent: t
            });
            g.setPosition(0, 50), H({
              text: "业务资产：" + O(c.businessAssetBookYuan) + "（产能加成）",
              fontSize: 13,
              bold: !0,
              align: "left",
              width: 320,
              parent: g
            }).setPosition(0, 38), W({
              text: "扩大产能（1万起）",
              width: 158,
              height: 42,
              fontSize: 13,
              color: A.secondary,
              parent: g,
              onClick: function onClick() {
                return l.renderInvestDialog();
              }
            }).setPosition(-83, -14), W({
              text: "年度报告",
              width: 158,
              height: 42,
              fontSize: 13,
              color: r.WHITE,
              textColor: A.primary,
              parent: g,
              onClick: function onClick() {
                return l.renderAnnualReport();
              }
            }).setPosition(83, -14), H({
              text: h.target3YearsAchieved ? "已达成连续 3 年盈利目标，可继续自由经营" : "连续盈利：" + h.consecutiveProfitableYears + "/3 年",
              fontSize: 12,
              color: h.target3YearsAchieved ? A.profit : A.textWeak,
              width: 320,
              parent: t
            }).setPosition(0, -36), "TUTORIAL_DASHBOARD" === h.phase && this.renderStartOperatingBubble();
          }
        }, u.renderStartOperatingBubble = function () {
          var t = this,
            e = this.modalOverlay(!0);
          b({
            width: 308,
            height: 236,
            color: new r(39, 50, 68, 245),
            radius: 12,
            parent: e
          }).setPosition(0, 0), H({
            text: "新手提示",
            fontSize: 15,
            bold: !0,
            color: r.WHITE,
            parent: e
          }).setPosition(0, 86), H({
            text: "营收是卖出去多少；利润才是扣掉成本后赚的钱。\n\n公司会自动经营，你可以暂停或加速时间。",
            fontSize: 14,
            color: r.WHITE,
            width: 264,
            lineHeight: 22,
            parent: e
          }).setPosition(0, 16), W({
            text: "开始经营",
            width: 168,
            height: 46,
            color: A.secondary,
            parent: e,
            onClick: function onClick() {
              e.destroy(), t.startClock();
            }
          }).setPosition(0, -78);
        }, u.renderTimeControl = function (t, e) {
          var n = this,
            o = this.state(),
            i = b({
              width: 343,
              height: 52,
              color: r.WHITE,
              radius: 8,
              parent: t
            });
          i.setPosition(0, e), H({
            text: "时间",
            fontSize: 12,
            color: A.textWeak,
            parent: i
          }).setPosition(-140, 0);
          [["暂停", 0], ["1×", 1], ["2×", 2], ["5×", 5]].forEach(function (t, e) {
            var a = t[0],
              s = t[1],
              d = o.speed === s;
            W({
              text: a,
              width: 52,
              height: 36,
              fontSize: 13,
              color: d ? A.primary : new r(238, 241, 247),
              textColor: d ? r.WHITE : A.textWeak,
              parent: i,
              onClick: function onClick() {
                n.onSetSpeed(s);
              }
            }).setPosition(60 * e - 66, 0);
          });
        }, u.onSetSpeed = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee9(t) {
            var e, n;
            return _regeneratorRuntime().wrap(function _callee9$(_context10) {
              while (1) switch (_context10.prev = _context10.next) {
                case 0:
                  e = this.state();
                  _context10.next = 3;
                  return this.facade.setSpeed(t, {
                    commandId: G("speed"),
                    expectedRunId: e.runId
                  });
                case 3:
                  n = _context10.sent;
                  n.ok ? (Y.speedChange(), this.render()) : this.toast(n.displayMessage);
                case 5:
                case "end":
                  return _context10.stop();
              }
            }, _callee9, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.deptHeadcount = function (t, e) {
          return t.employees.filter(function (t) {
            return "ACTIVE" === t.status && t.departmentId === e;
          }).length;
        }, u.renderDepartmentTab = function (t) {
          var e = this,
            o = this.state();
          H({
            text: "部门",
            fontSize: 22,
            bold: !0,
            color: A.text,
            parent: t
          }).setPosition(0, 344), b({
            width: 343,
            height: 92,
            color: r.WHITE,
            radius: 8,
            parent: t
          }).setPosition(0, 282), H({
            text: "自动经营方针：" + U[o.policy].name + "（" + U[o.policy].desc + "）",
            fontSize: 12,
            color: A.textWeak,
            width: 320,
            parent: t
          }).setPosition(0, 312), ["GROWTH", "STEADY", "PROFIT"].forEach(function (n, i) {
            W({
              text: U[n].name,
              width: 88,
              height: 38,
              fontSize: 13,
              color: o.policy === n ? A.primary : A.divider,
              textColor: o.policy === n ? r.WHITE : A.text,
              parent: t,
              onClick: function onClick() {
                e.onSetPolicy(n);
              }
            }).setPosition(100 * i - 100, 268);
          });
          for (var i = o.departments.find(function (t) {
              return "BUSINESS" === t.type;
            }), a = new Set(o.departments.map(function (t) {
              return t.type;
            })), s = m.filter(function (t) {
              return !a.has(t);
            }), d = 214, l = 0, h = [i].concat(o.departments.filter(function (t) {
              return "BUSINESS" !== t.type;
            })); l < h.length; l++) {
            var c = h[l];
            this.renderDeptCard(t, o, c, d), d -= 104;
          }
          for (var f, u = n(s); !(f = u()).done;) {
            var p = f.value;
            this.renderUncreatedDept(t, p, d), d -= 66;
          }
        }, u.renderDeptCard = function (t, e, n, o) {
          var i = this,
            a = "BUSINESS" === n.type ? "主营业务部" : B[n.type].name,
            s = "BUSINESS" === n.type ? "交付主营产能" : B[n.type].desc,
            d = this.deptHeadcount(e, n.deptId),
            l = e.employees.filter(function (t) {
              return "ACTIVE" === t.status && t.departmentId === n.deptId;
            }).reduce(function (t, e) {
              return t + e.salaryMonthlyYuan;
            }, 0);
          b({
            width: 343,
            height: 92,
            color: r.WHITE,
            radius: 8,
            parent: t
          }).setPosition(0, o), H({
            text: a,
            fontSize: 15,
            bold: !0,
            width: 170,
            align: "left",
            parent: t
          }).setPosition(-77, o + 28), H({
            text: s,
            fontSize: 11,
            color: A.textWeak,
            width: 210,
            align: "left",
            parent: t
          }).setPosition(-57, o + 10), H({
            text: 0 === d && "BUSINESS" !== n.type ? "尚未配置人员：无部门效益" : "在岗 " + d + " 人｜月薪合计 " + O(l),
            fontSize: 11,
            color: 0 === d ? A.warning : A.secondary,
            width: 210,
            align: "left",
            parent: t
          }).setPosition(-57, o - 12), W({
            text: "AUTO" === n.staffingMode ? "自动" : "手动",
            width: 54,
            height: 34,
            fontSize: 12,
            color: "AUTO" === n.staffingMode ? A.secondary : A.divider,
            textColor: "AUTO" === n.staffingMode ? r.WHITE : A.text,
            parent: t,
            onClick: function onClick() {
              i.onToggleStaffing(n);
            }
          }).setPosition(106, o + 18), W({
            text: "招聘",
            width: 54,
            height: 34,
            fontSize: 12,
            parent: t,
            onClick: function onClick() {
              return i.openHireForDept(n.deptId);
            }
          }).setPosition(160, o + 18);
        }, u.renderUncreatedDept = function (t, e, n) {
          var o = this,
            i = B[e];
          b({
            width: 343,
            height: 56,
            color: r.WHITE,
            radius: 8,
            parent: t
          }).setPosition(0, n), H({
            text: i.name,
            fontSize: 14,
            bold: !0,
            width: 150,
            align: "left",
            parent: t
          }).setPosition(-87, n + 12), H({
            text: i.desc + "｜设立费 " + O(1e4),
            fontSize: 10,
            color: A.textWeak,
            width: 200,
            align: "left",
            parent: t
          }).setPosition(-62, n - 10), W({
            text: "创建",
            width: 54,
            height: 34,
            fontSize: 12,
            parent: t,
            onClick: function onClick() {
              return o.confirmCreateDept(e);
            }
          }).setPosition(150, n);
        }, u.onSetPolicy = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee10(t) {
            var e, n;
            return _regeneratorRuntime().wrap(function _callee10$(_context11) {
              while (1) switch (_context11.prev = _context11.next) {
                case 0:
                  e = this.state();
                  _context11.next = 3;
                  return this.facade.setPolicy(t, {
                    commandId: G("policy"),
                    expectedRunId: e.runId
                  });
                case 3:
                  n = _context11.sent;
                  n.ok ? this.render() : this.toast(n.displayMessage);
                case 5:
                case "end":
                  return _context11.stop();
              }
            }, _callee10, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.onToggleStaffing = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee11(t) {
            var e, n, o;
            return _regeneratorRuntime().wrap(function _callee11$(_context12) {
              while (1) switch (_context12.prev = _context12.next) {
                case 0:
                  e = this.state();
                  n = "AUTO" === t.staffingMode ? "LOCKED" : "AUTO";
                  _context12.next = 4;
                  return this.facade.setStaffingMode(t.deptId, n, {
                    commandId: G("mode"),
                    expectedRunId: e.runId
                  });
                case 4:
                  o = _context12.sent;
                  o.ok ? this.render() : this.toast(o.displayMessage);
                case 6:
                case "end":
                  return _context12.stop();
              }
            }, _callee11, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.confirmCreateDept = function (t) {
          var e = this,
            n = (this.state(), this.facade.previewCreateDepartment(t)),
            o = this.modalOverlay();
          b({
            width: 310,
            height: 250,
            color: r.WHITE,
            radius: 12,
            parent: o
          }).setPosition(0, 0), H({
            text: "创建" + B[t].name,
            fontSize: 18,
            bold: !0,
            parent: o
          }).setPosition(0, 86), H({
            text: B[t].desc + "\n设立费 " + O(n.feeYuan) + "（确认即扣现金）。\n创建后默认手动编制，不自动招人；0 员工无效益。",
            fontSize: 13,
            color: A.text,
            width: 256,
            align: "left",
            lineHeight: 22,
            parent: o
          }).setPosition(0, 24), W({
            text: "支付 " + O(n.feeYuan) + " 创建",
            width: 200,
            height: 46,
            parent: o,
            onClick: function onClick() {
              e.doCreateDept(t, o);
            }
          }).setPosition(0, -72), W({
            text: "取消",
            width: 120,
            height: 40,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.text,
            parent: o,
            onClick: function onClick() {
              return o.destroy();
            }
          }).setPosition(0, -112);
        }, u.doCreateDept = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee12(t, e) {
            var n, o;
            return _regeneratorRuntime().wrap(function _callee12$(_context13) {
              while (1) switch (_context13.prev = _context13.next) {
                case 0:
                  n = this.state();
                  _context13.next = 3;
                  return this.facade.createDepartment(t, {
                    commandId: G("dept"),
                    expectedRunId: n.runId
                  });
                case 3:
                  o = _context13.sent;
                  e.destroy(), o.ok ? (this.toast("已创建" + B[t].name + "，支付 " + O(o.payload.feePaidYuan)), Y.createDepartment(), this.render()) : this.toast(o.displayMessage);
                case 5:
                case "end":
                  return _context13.stop();
              }
            }, _callee12, this);
          }));
          return function (e, n) {
            return t.apply(this, arguments);
          };
        }(), u.renderTalentTab = function (t) {
          var e = this.state();
          H({
            text: "员工",
            fontSize: 22,
            bold: !0,
            color: A.text,
            parent: t
          }).setPosition(0, 344);
          var o = e.employees.filter(function (t) {
            return "ACTIVE" === t.status;
          });
          H({
            text: "在职 " + o.length + " 人（点击详情可裁员/调岗）",
            fontSize: 12,
            color: A.textWeak,
            parent: t
          }).setPosition(0, 316);
          for (var i, r = 282, a = n(o); !(i = a()).done;) {
            var s = i.value;
            this.renderEmployeeCard(t, e, s, r), r -= 84;
          }
        }, u.renderEmployeeCard = function (t, e, n, o) {
          var i = this,
            a = e.departments.find(function (t) {
              return t.deptId === n.departmentId;
            }),
            s = a ? "BUSINESS" === a.type ? "主营" : B[a.type].name.replace("部", "") : "—";
          b({
            width: 343,
            height: 72,
            color: r.WHITE,
            radius: 8,
            parent: t
          }).setPosition(0, o), H({
            text: n.name + "（" + s + "）",
            fontSize: 15,
            bold: !0,
            width: 200,
            align: "left",
            parent: t
          }).setPosition(-62, o + 18), H({
            text: "能力 " + n.skill + "｜潜力 " + n.potential + "｜协作 " + n.teamwork,
            fontSize: 12,
            color: A.textWeak,
            width: 220,
            align: "left",
            parent: t
          }).setPosition(-52, o - 2), H({
            text: "月薪 " + O(n.salaryMonthlyYuan),
            fontSize: 12,
            color: A.primary,
            width: 140,
            align: "left",
            parent: t
          }).setPosition(-92, o - 22), W({
            text: "详情",
            width: 56,
            height: 36,
            fontSize: 12,
            parent: t,
            onClick: function onClick() {
              return i.openEmployeeDetail(n.employeeId);
            }
          }).setPosition(138, o);
        }, u.openEmployeeDetail = function (t) {
          var e = this,
            n = this.state(),
            o = n.employees.find(function (e) {
              return e.employeeId === t;
            });
          if (o) {
            var i = n.departments.find(function (t) {
                return t.deptId === o.departmentId;
              }),
              a = i ? "BUSINESS" === i.type ? "主营业务部" : B[i.type].name : "—",
              s = this.modalOverlay();
            b({
              width: 320,
              height: 380,
              color: r.WHITE,
              radius: 12,
              parent: s
            }).setPosition(0, 0), H({
              text: o.name,
              fontSize: 18,
              bold: !0,
              parent: s
            }).setPosition(0, 156), H({
              text: "部门：" + a + "\n专业能力：" + o.skill + "（年末按潜力成长）\n成长潜力：" + o.potential + "\n团队协作：" + o.teamwork + "\n月薪：" + O(o.salaryMonthlyYuan) + "\n\n调岗：下月生效，无招聘费/赔偿；\n裁员：主动触发，按任职年数补偿。",
              fontSize: 13,
              color: A.text,
              width: 270,
              lineHeight: 22,
              align: "left",
              parent: s
            }).setPosition(0, 56), W({
              text: "调岗",
              width: 96,
              height: 44,
              fontSize: 14,
              color: A.secondary,
              parent: s,
              onClick: function onClick() {
                s.destroy(), e.openTransfer(t);
              }
            }).setPosition(-62, -110), W({
              text: "裁员",
              width: 96,
              height: 44,
              fontSize: 14,
              color: A.danger,
              parent: s,
              onClick: function onClick() {
                s.destroy(), e.openLayoffConfirm(t);
              }
            }).setPosition(62, -110), W({
              text: "关闭",
              width: 220,
              height: 40,
              fontSize: 13,
              color: r.WHITE,
              textColor: A.text,
              parent: s,
              onClick: function onClick() {
                return s.destroy();
              }
            }).setPosition(0, -158);
          }
        }, u.openTransfer = function (t) {
          var e = this,
            n = this.state(),
            o = n.employees.find(function (e) {
              return e.employeeId === t;
            });
          if (o) {
            var i = n.departments.filter(function (t) {
                return t.deptId !== o.departmentId;
              }),
              a = this.modalOverlay();
            b({
              width: 310,
              height: 80 + 54 * i.length,
              color: r.WHITE,
              radius: 12,
              parent: a
            }).setPosition(0, 0), H({
              text: "将 " + o.name + " 调往（下月生效）",
              fontSize: 16,
              bold: !0,
              parent: a
            }).setPosition(0, 27 * i.length + 14), i.forEach(function (n, o) {
              var r = "BUSINESS" === n.type ? "主营业务部" : B[n.type].name;
              W({
                text: r,
                width: 240,
                height: 42,
                fontSize: 14,
                parent: a,
                onClick: function onClick() {
                  e.doTransfer(t, n.deptId, a);
                }
              }).setPosition(0, 27 * i.length - 26 - 54 * o);
            }), W({
              text: "取消",
              width: 120,
              height: 36,
              fontSize: 13,
              color: r.WHITE,
              textColor: A.text,
              parent: a,
              onClick: function onClick() {
                return a.destroy();
              }
            }).setPosition(0, -(27 * i.length + 30));
          }
        }, u.doTransfer = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee13(t, e, n) {
            var o, i;
            return _regeneratorRuntime().wrap(function _callee13$(_context14) {
              while (1) switch (_context14.prev = _context14.next) {
                case 0:
                  o = this.state();
                  _context14.next = 3;
                  return this.facade.transferEmployee(t, e, {
                    commandId: G("transfer"),
                    expectedRunId: o.runId
                  });
                case 3:
                  i = _context14.sent;
                  n.destroy(), i.ok ? (this.toast("已安排调岗，下月生效"), this.render()) : this.toast(i.displayMessage);
                case 5:
                case "end":
                  return _context14.stop();
              }
            }, _callee13, this);
          }));
          return function (e, n, o) {
            return t.apply(this, arguments);
          };
        }(), u.openLayoffConfirm = function (t) {
          var e = this,
            n = this.facade.previewLayoff(t, Date.now());
          this.layoffToken = this.facade.createLayoffToken(n, Date.now());
          var o = this.modalOverlay();
          b({
            width: 312,
            height: 350,
            color: r.WHITE,
            radius: 12,
            parent: o
          }).setPosition(0, 0), H({
            text: "确认裁员？",
            fontSize: 18,
            bold: !0,
            color: A.danger,
            parent: o
          }).setPosition(0, 140), H({
            text: "员工：" + n.name + "\n任职：" + n.tenureYears + " 年（" + n.tenureMonths + " 个月）\n月薪：" + O(n.salaryMonthlyYuan) + "\n补偿月数：" + n.severanceMonths + " 个月\n\n补偿金额：" + O(n.severanceYuan) + "（确认即支付）\n次年约节约工资：" + O(n.nextYearSalarySavingYuan) + "\n裁后现金：" + O(n.cashAfterYuan),
            fontSize: 13,
            color: A.text,
            width: 266,
            lineHeight: 22,
            align: "left",
            parent: o
          }).setPosition(0, 28), W({
            text: "确认支付补偿 " + O(n.severanceYuan),
            width: 240,
            height: 48,
            color: A.danger,
            parent: o,
            onClick: function onClick() {
              e.doLayoff(o);
            }
          }).setPosition(0, -104), W({
            text: "再想想（取消）",
            width: 200,
            height: 40,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.text,
            parent: o,
            onClick: function onClick() {
              return o.destroy();
            }
          }).setPosition(0, -146);
        }, u.doLayoff = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee14(t) {
            var e, n, o;
            return _regeneratorRuntime().wrap(function _callee14$(_context15) {
              while (1) switch (_context15.prev = _context15.next) {
                case 0:
                  if (!this.layoffToken) {
                    _context15.next = 9;
                    break;
                  }
                  e = this.state();
                  n = this.layoffToken;
                  _context15.next = 5;
                  return this.facade.confirmLayoff(n, {
                    commandId: G("layoff"),
                    expectedRunId: e.runId
                  });
                case 5:
                  o = _context15.sent;
                  t.destroy(), this.layoffToken = null, o.ok ? (this.toast("已支付补偿 " + O(o.payload.severancePaidYuan) + "，次月离岗"), Y.layoff(), this.render()) : this.toast(o.displayMessage);
                  _context15.next = 10;
                  break;
                case 9:
                  t.destroy();
                case 10:
                case "end":
                  return _context15.stop();
              }
            }, _callee14, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.openHireForDept = function (t) {
          var e = this.facade.getOffer(t);
          this.pendingOffer = e, this.renderHireDialog(e, t);
        }, u.renderHireDialog = function (t, e) {
          var n = this,
            o = this.state(),
            i = this.modalOverlay();
          b({
            width: 340,
            height: 470,
            color: r.WHITE,
            radius: 12,
            parent: i
          }).setPosition(0, 0), H({
            text: "招聘候选人",
            fontSize: 18,
            bold: !0,
            parent: i
          }).setPosition(0, 206), H({
            text: "招聘费=1个月月薪（HR已生效可折扣），次月到岗",
            fontSize: 10,
            color: A.textWeak,
            width: 300,
            parent: i
          }).setPosition(0, 186), t.candidates.forEach(function (t, r) {
            var a = 150 - 108 * r;
            b({
              width: 308,
              height: 98,
              color: A.bg,
              radius: 8,
              parent: i
            }).setPosition(0, a);
            var s = "A" === t.archetype ? "即战力" : "B" === t.archetype ? "潜力股" : "经济型";
            H({
              text: t.name + "（" + s + "）",
              fontSize: 14,
              bold: !0,
              width: 180,
              align: "left",
              parent: i
            }).setPosition(-56, a + 32), H({
              text: "能力 " + t.skill + " 潜力 " + t.potential + " 协作 " + t.teamwork,
              fontSize: 11,
              color: A.textWeak,
              width: 200,
              align: "left",
              parent: i
            }).setPosition(-46, a + 12), H({
              text: "月薪 " + O(t.salaryMonthlyYuan) + "｜招聘费 " + O(t.salaryMonthlyYuan),
              fontSize: 11,
              color: A.primary,
              width: 200,
              align: "left",
              parent: i
            }).setPosition(-46, a - 8), W({
              text: "录用",
              width: 60,
              height: 38,
              fontSize: 13,
              parent: i,
              disabled: o.company.cashYuan < t.salaryMonthlyYuan,
              onClick: function onClick() {
                n.hireFromDialog(t.candidateId, e, i);
              }
            }).setPosition(124, a);
          }), W({
            text: "换一批",
            width: 96,
            height: 40,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.primary,
            parent: i,
            onClick: function onClick() {
              i.destroy(), n.refreshHire(e);
            }
          }).setPosition(-60, -206), W({
            text: "关闭",
            width: 96,
            height: 40,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.text,
            parent: i,
            onClick: function onClick() {
              return i.destroy();
            }
          }).setPosition(60, -206);
        }, u.refreshHire = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee15(t) {
            var e, n;
            return _regeneratorRuntime().wrap(function _callee15$(_context16) {
              while (1) switch (_context16.prev = _context16.next) {
                case 0:
                  e = this.state();
                  _context16.next = 3;
                  return this.facade.refreshOffer(t, {
                    commandId: G("refresh"),
                    expectedRunId: e.runId
                  });
                case 3:
                  n = _context16.sent;
                  n.ok ? (this.pendingOffer = n.payload, this.renderHireDialog(n.payload, t)) : this.toast(n.displayMessage);
                case 5:
                case "end":
                  return _context16.stop();
              }
            }, _callee15, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.hireFromDialog = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee16(t, e, n) {
            var o, i, r, a, s;
            return _regeneratorRuntime().wrap(function _callee16$(_context17) {
              while (1) switch (_context17.prev = _context17.next) {
                case 0:
                  r = this.state();
                  a = null != (o = null == (i = this.pendingOffer) ? void 0 : i.offerId) ? o : this.facade.getOffer(e).offerId;
                  _context17.next = 4;
                  return this.facade.hireEmployee({
                    offerId: a,
                    candidateId: t,
                    departmentId: e
                  }, {
                    commandId: G("hire"),
                    expectedRunId: r.runId
                  });
                case 4:
                  s = _context17.sent;
                  n.destroy(), s.ok ? (this.toast("已录用，支付招聘费 " + O(s.payload.feePaidYuan) + "，次月到岗"), Y.recruit(), this.render()) : this.toast(s.displayMessage);
                case 6:
                case "end":
                  return _context17.stop();
              }
            }, _callee16, this);
          }));
          return function (e, n, o) {
            return t.apply(this, arguments);
          };
        }(), u.renderRankTab = function (t) {
          var e = this;
          H({
            text: "本地模拟排行",
            fontSize: 22,
            bold: !0,
            color: A.text,
            parent: t
          }).setPosition(0, 336), W({
            text: "资产榜",
            width: 100,
            height: 38,
            fontSize: 14,
            color: "assets" === this.rankMode ? A.primary : A.divider,
            textColor: "assets" === this.rankMode ? r.WHITE : A.text,
            parent: t,
            onClick: function onClick() {
              e.rankMode = "assets", e.render();
            }
          }).setPosition(-58, 300), W({
            text: "年限榜",
            width: 100,
            height: 38,
            fontSize: 14,
            color: "years" === this.rankMode ? A.primary : A.divider,
            textColor: "years" === this.rankMode ? r.WHITE : A.text,
            parent: t,
            onClick: function onClick() {
              e.rankMode = "years", e.render();
            }
          }).setPosition(58, 300);
          var n = "assets" === this.rankMode ? this.facade.assetsLeaderboard() : this.facade.yearsLeaderboard();
          n.slice(0, 8).forEach(function (n, o) {
            var i = 252 - 52 * o;
            b({
              width: 343,
              height: 46,
              color: n.isPlayer ? new r(224, 236, 255) : r.WHITE,
              radius: 6,
              parent: t
            }).setPosition(0, i), H({
              text: "" + (o + 1),
              fontSize: 14,
              bold: !0,
              width: 30,
              color: o < 3 ? A.warning : A.textWeak,
              parent: t
            }).setPosition(-158, i), H({
              text: n.isPlayer ? n.name + "（你）" : n.name,
              fontSize: 13,
              bold: n.isPlayer,
              width: 170,
              align: "left",
              color: n.isPlayer ? A.primary : A.text,
              parent: t
            }).setPosition(-50, i);
            var a = "assets" === e.rankMode ? O(n.assetsYuan) : n.yearsOperated + " 年";
            H({
              text: a,
              fontSize: 13,
              width: 110,
              align: "right",
              color: A.text,
              parent: t
            }).setPosition(105, i);
          });
          var o = n,
            i = o.findIndex(function (t) {
              return t.isPlayer;
            }) + 1;
          H({
            text: i > 0 ? "你的排名：第 " + i + " / " + o.length + " 名" : "",
            fontSize: 12,
            color: A.textWeak,
            parent: t
          }).setPosition(0, -180);
        }, u.renderBottomTabs = function (t) {
          var e = this;
          b({
            width: 375,
            height: 72,
            color: r.WHITE,
            radius: 0,
            parent: t
          }).setPosition(0, -372), [["COMPANY", "公司"], ["DEPARTMENT", "部门"], ["TALENT", "人才"], ["RANK", "排行"]].forEach(function (n, o) {
            var i = n[0],
              a = n[1],
              s = e.activeTab === i,
              d = 94 * o - 141;
            W({
              text: a,
              width: 80,
              height: 56,
              fontSize: 13,
              color: new r(0, 0, 0, 0),
              textColor: s ? A.primary : A.textWeak,
              parent: t,
              onClick: function onClick() {
                e.activeTab = i, e.render();
              }
            }).setPosition(d, -372);
          });
        }, u.renderInvestDialog = function () {
          var t,
            e,
            n = this,
            o = this.state(),
            i = this.modalOverlay();
          b({
            width: 320,
            height: 400,
            color: r.WHITE,
            radius: 12,
            parent: i
          }).setPosition(0, -10), H({
            text: "扩大主营业务产能",
            fontSize: 18,
            bold: !0,
            parent: i
          }).setPosition(0, 150), H({
            text: "可用现金 " + O(null != (t = null == (e = o.company) ? void 0 : e.cashYuan) ? t : 0),
            fontSize: 13,
            color: A.textWeak,
            parent: i
          }).setPosition(0, 116), H({
            text: "每投入 1 万元，交付产能 +1.5%（封顶 +30%）。\n现金即时换为业务资产，不计当月利润，次年起按 10% 折旧。",
            fontSize: 11,
            color: A.textWeak,
            width: 300,
            lineHeight: 16,
            parent: i
          }).setPosition(0, 70);
          [1e4, 5e4, 1e5].forEach(function (t, e) {
            var o = n.facade.previewInvest(t),
              r = o.ok && o.payload.cashAfter >= 0;
            W({
              text: "投入 " + O(t) + (r ? "" : "（现金不足）"),
              width: 280,
              height: 42,
              fontSize: 13,
              color: r ? A.secondary : A.disabled,
              disabled: !r,
              parent: i,
              onClick: function onClick() {
                n.onInvest(t);
              }
            }).setPosition(0, 10 - 52 * e);
          }), W({
            text: "取消",
            width: 280,
            height: 42,
            color: r.WHITE,
            textColor: A.textWeak,
            fontSize: 14,
            parent: i,
            onClick: function onClick() {
              return i.destroy();
            }
          }).setPosition(0, -190);
        }, u.onInvest = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee17(t) {
            var e, n;
            return _regeneratorRuntime().wrap(function _callee17$(_context18) {
              while (1) switch (_context18.prev = _context18.next) {
                case 0:
                  e = this.state();
                  _context18.next = 3;
                  return this.facade.invest(t, {
                    commandId: G("invest"),
                    expectedRunId: e.runId
                  });
                case 3:
                  n = _context18.sent;
                  n.ok ? (this.toast("已投入 " + O(t) + "，产能加成已更新"), this.render()) : this.toast(n.displayMessage);
                case 5:
                case "end":
                  return _context18.stop();
              }
            }, _callee17, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), u.renderAnnualReport = function () {
          var t = this.state().annualReports.map(function (t) {
              return t.year;
            }).sort(function (t, e) {
              return e - t;
            }),
            e = t.length > 0 ? this.facade.getAnnualReport(t[0]) : null,
            n = this.modalOverlay();
          if (b({
            width: 324,
            height: 572,
            color: r.WHITE,
            radius: 12,
            parent: n
          }).setPosition(0, 54), H({
            text: e ? "第 " + e.year + " 年财务报告" : "年度财务报告",
            fontSize: 18,
            bold: !0,
            parent: n
          }).setPosition(0, 330), !e) return H({
            text: "首个经营年度尚未结束。\n完成 12 个月结算后可在此查看年报。",
            fontSize: 13,
            color: A.textWeak,
            width: 280,
            lineHeight: 20,
            parent: n
          }).setPosition(0, 80), void W({
            text: "知道了",
            width: 240,
            height: 46,
            parent: n,
            onClick: function onClick() {
              return n.destroy();
            }
          }).setPosition(0, -120);
          [["营业收入", e.revenueYuan, !1], ["直接成本", e.directCostYuan, !0], ["其他运营费", e.otherOperatingCostYuan, !0], ["售后费用", e.afterSalesCostYuan, !0], ["固定管理费", e.fixedCostYuan, !0], ["员工工资", e.payrollYuan, !0], ["招聘费", e.recruitmentCostYuan, !0], ["裁员赔偿", e.severanceCostYuan, !0], ["部门设置费", e.deptSetupCostYuan, !0], ["事件损益", e.eventCostYuan, !0], ["折旧", e.depreciationYuan, !0]].forEach(function (t, e) {
            var o = t[0],
              i = t[1],
              r = t[2];
            H({
              text: o,
              fontSize: 12,
              align: "left",
              color: A.textWeak,
              width: 150,
              parent: n
            }).setPosition(-78, 282 - 30 * e), H({
              text: 0 === i ? "¥0" : O(i),
              fontSize: 12,
              align: "right",
              color: r && 0 !== i ? A.danger : A.text,
              width: 150,
              parent: n
            }).setPosition(84, 282 - 30 * e);
          });
          var o = e.profitYuan < 0 ? A.danger : A.profit;
          b({
            width: 300,
            height: 76,
            color: new r(238, 244, 252),
            radius: 8,
            parent: n
          }).setPosition(0, -78), H({
            text: "本年净利润",
            fontSize: 12,
            color: A.textWeak,
            parent: n
          }).setPosition(0, -60), H({
            text: (e.profitYuan < 0 ? "-" : "") + O(Math.abs(e.profitYuan)),
            fontSize: 22,
            bold: !0,
            color: o,
            parent: n
          }).setPosition(0, -90), H({
            text: "期初现金 " + O(e.cashOpenYuan) + "　期末 " + O(e.cashCloseYuan) + "\n总资产 " + O(e.assetCloseYuan) + "　期末员工 " + e.headcountClose + " 人",
            fontSize: 11,
            color: A.textWeak,
            width: 300,
            lineHeight: 18,
            parent: n
          }).setPosition(0, -138), W({
            text: "关闭",
            width: 240,
            height: 46,
            parent: n,
            onClick: function onClick() {
              return n.destroy();
            }
          }).setPosition(0, -200);
        }, u.renderSettings = function () {
          var t = this,
            e = this.modalOverlay(),
            n = Y.getSettings();
          b({
            width: 320,
            height: 468,
            color: r.WHITE,
            radius: 12,
            parent: e
          }).setPosition(0, 0), H({
            text: "设置",
            fontSize: 18,
            bold: !0,
            parent: e
          }).setPosition(0, 198);
          var o = function o(t, n, _o, i) {
            H({
              text: n,
              fontSize: 14,
              width: 180,
              align: "left",
              parent: e
            }).setPosition(-60, t), W({
              text: _o ? "开" : "关",
              width: 64,
              height: 36,
              fontSize: 14,
              color: _o ? A.secondary : A.divider,
              textColor: _o ? r.WHITE : A.text,
              parent: e,
              onClick: i
            }).setPosition(116, t);
          };
          H({
            text: "声音",
            fontSize: 13,
            bold: !0,
            color: A.textWeak,
            width: 260,
            align: "left",
            parent: e
          }).setPosition(-20, 140), o(100, "总开关（关闭后全静音）", n.masterEnabled, function () {
            var n = Y.getSettings();
            Y.updateSettings({
              masterEnabled: !n.masterEnabled
            }), Y.uiTap(), t.rebuildSettings(e);
          }), o(56, "背景音乐", n.musicEnabled, function () {
            var n = Y.getSettings();
            Y.updateSettings({
              musicEnabled: !n.musicEnabled
            }), Y.uiTap(), t.rebuildSettings(e);
          }), o(12, "操作音效/提示", n.sfxEnabled, function () {
            var n = Y.getSettings();
            Y.updateSettings({
              sfxEnabled: !n.sfxEnabled
            }), n.sfxEnabled || Y.uiTap(), t.rebuildSettings(e);
          }), W({
            text: "重新查看操作指引",
            width: 240,
            height: 42,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.primary,
            parent: e,
            onClick: function onClick() {
              e.destroy(), t.replayTutorial();
            }
          }).setPosition(0, -40), W({
            text: "隐私政策",
            width: 240,
            height: 40,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.primary,
            parent: e,
            onClick: function onClick() {
              var e = S().privacyPolicyUrl;
              e ? t.openPrivacyPolicy(e) : t.toast("隐私政策地址将在正式上架前配置");
            }
          }).setPosition(0, -88), W({
            text: "关闭公司并重新创业",
            width: 240,
            height: 42,
            fontSize: 13,
            color: r.WHITE,
            textColor: A.danger,
            parent: e,
            onClick: function onClick() {
              e.destroy(), t.renderCloseConfirm();
            }
          }).setPosition(0, -136), W({
            text: "取消",
            width: 240,
            height: 40,
            color: A.textWeak,
            parent: e,
            onClick: function onClick() {
              return e.destroy();
            }
          }).setPosition(0, -184);
        }, u.rebuildSettings = function (t) {
          var e = this;
          this.scheduleOnce(function () {
            t.isValid && (t.destroy(), e.renderSettings());
          }, 0);
        }, u.replayTutorial = function () {
          var t = this.modalOverlay();
          b({
            width: 320,
            height: 360,
            color: r.WHITE,
            radius: 12,
            parent: t
          }).setPosition(0, 0), H({
            text: "操作指引",
            fontSize: 18,
            bold: !0,
            parent: t
          }).setPosition(0, 146), H({
            text: "公司页：实时现金/收入/利润、时间倍速、扩产与年报。\n部门页：创建采购/客服/市场/财务/HR，切自动或手动，招聘员工。\n人才页：查看员工详情，可调岗或裁员（有补偿）。\n离线：每 40 分钟结 1 个月，最多 36 个月。\n现金不足会暂停经营，可领一次 10 万救助。\n目标：连续 3 年盈利。",
            fontSize: 13,
            color: A.text,
            width: 272,
            lineHeight: 24,
            parent: t
          }).setPosition(0, 20), W({
            text: "知道了",
            width: 200,
            height: 46,
            parent: t,
            onClick: function onClick() {
              return t.destroy();
            }
          }).setPosition(0, -132);
        }, u.renderCloseConfirm = function () {
          var t,
            e,
            n,
            o,
            i = this,
            a = this.state(),
            s = this.modalOverlay();
          b({
            width: 320,
            height: 360,
            color: r.WHITE,
            radius: 12,
            parent: s
          }).setPosition(0, 0), H({
            text: "关闭公司并重来？",
            fontSize: 18,
            bold: !0,
            color: A.danger,
            parent: s
          }).setPosition(0, 140), H({
            text: "将永久清除本局：\n公司：" + (null != (t = null == (e = a.company) ? void 0 : e.name) ? t : "") + "\n员工：" + a.employees.length + " 人\n现金：" + O(null != (n = null == (o = a.company) ? void 0 : o.cashYuan) ? n : 0) + "\n已完成年度：" + a.annualReports.length + "\n\n此操作不可撤销，但不会注销你的平台账号。",
            fontSize: 13,
            color: A.text,
            width: 270,
            lineHeight: 20,
            align: "left",
            parent: s
          }).setPosition(0, 30);
          var d = this.facade.beginCloseCompany(Date.now());
          W({
            text: "永久清除本局",
            width: 250,
            height: 48,
            color: A.danger,
            parent: s,
            onClick: function onClick() {
              i.doClose(d.confirmationToken, d.expiresAtMs, d.oldRunId);
            }
          }).setPosition(0, -110), W({
            text: "再想想（取消）",
            width: 250,
            height: 44,
            color: A.textWeak,
            parent: s,
            onClick: function onClick() {
              return s.destroy();
            }
          }).setPosition(0, -162);
        }, u.doClose = function () {
          var t = o( /*#__PURE__*/_regeneratorRuntime().mark(function _callee18(t, e, n) {
            var o;
            return _regeneratorRuntime().wrap(function _callee18$(_context19) {
              while (1) switch (_context19.prev = _context19.next) {
                case 0:
                  _context19.next = 2;
                  return this.facade.confirmCloseCompany({
                    confirmationToken: t,
                    expiresAtMs: e,
                    oldRunId: n
                  }, Date.now());
                case 2:
                  o = _context19.sent;
                  o.ok ? (this.customCompanyName = "", this.customCeoName = "", this.randomCompanyNames = [], this.activeTab = "COMPANY", this.toast("公司已关闭，开始新的创业"), this.render()) : this.toast(o.displayMessage);
                case 4:
                case "end":
                  return _context19.stop();
              }
            }, _callee18, this);
          }));
          return function (e, n, o) {
            return t.apply(this, arguments);
          };
        }(), u.fullPanel = function () {
          var t = b({
            name: "FullPanel",
            width: N,
            height: M,
            color: A.bg,
            radius: 0,
            parent: this.root
          });
          return t.setPosition(0, 0), R(t), t;
        }, u.modalOverlay = function (t) {
          void 0 === t && (t = !1);
          var e = new a("ModalOverlay");
          if (e.parent = this.root, e.addComponent(s).setContentSize(new d(N, M)), !t) {
            var n = e.addComponent(f);
            n.fillColor = new r(0, 0, 0, 130), n.rect(-N / 2, -M / 2, N, M), n.fill();
          }
          return e.on(a.EventType.TOUCH_END, function (t) {
            return t.propagationStopped = !0;
          }), e;
        }, u.toast = function (t) {
          this.toastNode && this.toastNode.destroy();
          var e = b({
            width: 300,
            height: 44,
            color: new r(39, 50, 68, 235),
            radius: 8,
            parent: this.root
          });
          e.setPosition(0, -300), H({
            text: t,
            fontSize: 13,
            color: r.WHITE,
            width: 284,
            parent: e
          }).setPosition(0, 0), this.toastNode = e, this.scheduleOnce(function () {
            e.isValid && e.destroy();
          }, 2.2);
        }, i;
      }(u));
      i._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/AudioManager.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (t) {
  var e, i, n, s, r, a, u, o, l, c;
  return {
    setters: [function (t) {
      e = t["extends"], i = t.asyncToGenerator;
    }, function (t) {
      n = t.cclegacy, s = t.sys, r = t.Node, a = t.director, u = t.AudioSource, o = t.resources, l = t.AudioClip, c = t.game;
    }],
    execute: function execute() {
      n._RF.push({}, "d1eecKzCphDQ7J53N94ewUo", "AudioManager", void 0);
      var h = "ceo.audio.settings.v1",
        f = {
          masterEnabled: !0,
          musicEnabled: !0,
          sfxEnabled: !0
        },
        p = {
          ui_tap: "sfx/SFX_01_UITap",
          ui_select: "sfx/SFX_02_Select",
          ui_confirm: "sfx/SFX_03_Confirm",
          ui_back: "sfx/SFX_04_Back",
          ui_invalid: "sfx/SFX_05_Invalid",
          company_reroll_name: "sfx/SFX_06_RerollName",
          employee_recruited: "sfx/SFX_07_Recruit",
          department_created: "sfx/SFX_08_CreateDepartment",
          employee_laid_off: "sfx/SFX_09_Layoff",
          time_speed_change: "sfx/SFX_10_SpeedChange",
          cash_warning: "sfx/SFX_11_CashWarning",
          year_profit: "jingles/JNG_01_YearProfit",
          year_loss: "jingles/JNG_02_YearLoss",
          three_year_goal: "jingles/JNG_03_ThreeYearGoal"
        },
        _ = new Set(["year_profit", "year_loss", "three_year_goal"]),
        d = t("AudioManager", function () {
          function t() {
            this.source = null, this.settings = e({}, f), this.clips = new Map(), this.unlocked = !1, this.currentBgm = null, this.loadingPaths = new Set(), this.lastPlayedAt = new Map();
          }
          var n = t.prototype;
          return n.loadSettings = function () {
            try {
              if (s.localStorage) {
                var t = s.localStorage.getItem(h);
                t && (this.settings = e({}, f, JSON.parse(t)));
              }
            } catch (t) {
              this.settings = e({}, f);
            }
            return this.settings;
          }, n.persist = function () {
            try {
              var t;
              null == (t = s.localStorage) || t.setItem(h, JSON.stringify(this.settings));
            } catch (t) {}
          }, n.getSettings = function () {
            return e({}, this.settings);
          }, n.updateSettings = function (t) {
            var i;
            (this.settings = e({}, this.settings, t), this.persist(), this.canPlayMusic()) ? this.currentBgm && this.playBgm(this.currentBgm) : null == (i = this.source) || i.pause();
          }, n.canPlayMusic = function () {
            return this.unlocked && this.settings.masterEnabled && this.settings.musicEnabled;
          }, n.canPlaySfx = function () {
            return this.unlocked && this.settings.masterEnabled && this.settings.sfxEnabled;
          }, n.unlock = function () {
            this.unlocked || (this.unlocked = !0, this.ensureSource(), this.currentBgm && this.canPlayMusic() && this.playBgm(this.currentBgm));
          }, n.ensureSource = function () {
            var t;
            if (!this.source) {
              var e = new r("AudioManager");
              null == (t = a.getScene()) || t.addChild(e), a.addPersistRootNode(e), this.source = e.addComponent(u);
            }
          }, n.preload = function (t) {
            var e = this;
            return this.clips.has(t) ? Promise.resolve(this.clips.get(t)) : this.loadingPaths.has(t) ? Promise.resolve(null) : (this.loadingPaths.add(t), new Promise(function (i) {
              o.load(t, l, function (n, s) {
                e.loadingPaths["delete"](t), !n && s ? (e.clips.set(t, s), i(s)) : i(null);
              });
            }));
          }, n.playBgm = function () {
            var t = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee19(t) {
              var e, i;
              return _regeneratorRuntime().wrap(function _callee19$(_context20) {
                while (1) switch (_context20.prev = _context20.next) {
                  case 0:
                    if (!(this.currentBgm = t, this.canPlayMusic())) {
                      _context20.next = 7;
                      break;
                    }
                    this.ensureSource();
                    e = "startup" === t ? "bgm/BGM_01_StartupLoop" : "bgm/BGM_02_OfficeLoop";
                    _context20.next = 5;
                    return this.preload(e);
                  case 5:
                    i = _context20.sent;
                    i && this.source && this.canPlayMusic() && this.currentBgm === t && (this.source.clip === i && this.source.playing || (this.source.stop(), this.source.clip = i, this.source.loop = !0, this.source.volume = .6, this.source.play()));
                  case 7:
                  case "end":
                    return _context20.stop();
                }
              }, _callee19, this);
            }));
            return function (e) {
              return t.apply(this, arguments);
            };
          }(), n.playSfx = function () {
            var t = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee20(t) {
              var e, i, n, s, r, a;
              return _regeneratorRuntime().wrap(function _callee20$(_context21) {
                while (1) switch (_context21.prev = _context21.next) {
                  case 0:
                    if (!this.canPlaySfx()) {
                      _context21.next = 9;
                      break;
                    }
                    n = c.totalTime;
                    if ((null != (e = this.lastPlayedAt.get(t)) ? e : -999) + 80 > n) {
                      _context21.next = 9;
                      break;
                    }
                    this.lastPlayedAt.set(t, n);
                    s = p[t];
                    _context21.next = 7;
                    return this.preload(s);
                  case 7:
                    r = _context21.sent;
                    if (r && this.canPlaySfx()) {
                      a = _.has(t) ? .7 : 1;
                      null == (i = this.source) || i.playOneShot(r, a);
                    }
                  case 9:
                  case "end":
                    return _context21.stop();
                }
              }, _callee20, this);
            }));
            return function (e) {
              return t.apply(this, arguments);
            };
          }(), n.uiTap = function () {
            return this.playSfx("ui_tap");
          }, n.uiSelect = function () {
            return this.playSfx("ui_select");
          }, n.uiConfirm = function () {
            return this.playSfx("ui_confirm");
          }, n.uiBack = function () {
            return this.playSfx("ui_back");
          }, n.uiInvalid = function () {
            return this.playSfx("ui_invalid");
          }, n.rerollName = function () {
            return this.playSfx("company_reroll_name");
          }, n.recruit = function () {
            return this.playSfx("employee_recruited");
          }, n.createDepartment = function () {
            return this.playSfx("department_created");
          }, n.layoff = function () {
            return this.playSfx("employee_laid_off");
          }, n.speedChange = function () {
            return this.playSfx("time_speed_change");
          }, n.cashWarning = function () {
            return this.playSfx("cash_warning");
          }, n.yearProfit = function () {
            return this.playSfx("year_profit");
          }, n.yearLoss = function () {
            return this.playSfx("year_loss");
          }, n.threeYearGoal = function () {
            return this.playSfx("three_year_goal");
          }, n.onAppHide = function () {
            var t;
            null == (t = this.source) || t.pause();
          }, n.onAppShow = function () {
            var t;
            this.canPlayMusic() && (null == (t = this.source) || t.play());
          }, t;
        }());
      t("audioManager", new d());
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/AuthService.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./errors.ts"], function (t) {
  var e, n, i, s;
  return {
    setters: [function (t) {
      e = t.asyncToGenerator;
    }, function (t) {
      n = t.cclegacy;
    }, function (t) {
      i = t.GameError, s = t.GameErrorCode;
    }],
    execute: function execute() {
      n._RF.push({}, "e4993Tu3RdLdJU/CH5LUycV", "AuthService", void 0);
      var o = t("SESSION_STORAGE_KEY", "ceo/auth/session");
      t("AuthService", function () {
        function t(t, e) {
          var n, i, s;
          void 0 === e && (e = {}), this.platform = void 0, this.endpoint = void 0, this.timeoutMs = void 0, this.now = void 0, this.session = null, this.platform = t, this.endpoint = (null != (n = e.endpoint) ? n : "").replace(/\/+$/, ""), this.timeoutMs = null != (i = e.timeoutMs) ? i : 8e3, this.now = null != (s = e.now) ? s : function () {
            return Date.now();
          };
        }
        var n = t.prototype;
        return n.isTapRuntime = function () {
          return "TAPTAP" === this.platform.getEnvironment();
        }, n.ensureAuthenticated = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee21() {
            var t, e, n;
            return _regeneratorRuntime().wrap(function _callee21$(_context22) {
              while (1) switch (_context22.prev = _context22.next) {
                case 0:
                  if (!(null != (t = this.session))) {
                    _context22.next = 4;
                    break;
                  }
                  _context22.t0 = t;
                  _context22.next = 7;
                  break;
                case 4:
                  _context22.next = 6;
                  return this.readStored();
                case 6:
                  _context22.t0 = _context22.sent;
                case 7:
                  e = _context22.t0;
                  if (!(e && this.isSessionValid(e))) {
                    _context22.next = 10;
                    break;
                  }
                  return _context22.abrupt("return", (this.session = e, e));
                case 10:
                  if (this.isTapRuntime()) {
                    _context22.next = 13;
                    break;
                  }
                  n = {
                    kind: "mock",
                    sessionToken: "mock-editor-session",
                    expiresAtMs: 0
                  };
                  return _context22.abrupt("return", (this.session = n, n));
                case 13:
                  return _context22.abrupt("return", this.loginFresh());
                case 14:
                case "end":
                  return _context22.stop();
              }
            }, _callee21, this);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), n.loginFresh = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee22() {
            var t, e, n, o;
            return _regeneratorRuntime().wrap(function _callee22$(_context23) {
              while (1) switch (_context23.prev = _context23.next) {
                case 0:
                  if (this.isTapRuntime()) {
                    _context23.next = 3;
                    break;
                  }
                  t = {
                    kind: "mock",
                    sessionToken: "mock-editor-session",
                    expiresAtMs: 0
                  };
                  return _context23.abrupt("return", (this.session = t, t));
                case 3:
                  if (this.endpoint) {
                    _context23.next = 5;
                    break;
                  }
                  throw new i(s.PLATFORM_UNAVAILABLE, {
                    api: "auth",
                    cause: "auth endpoint not configured"
                  });
                case 5:
                  _context23.next = 7;
                  return this.platform.login();
                case 7:
                  e = _context23.sent;
                  if (e.code) {
                    _context23.next = 10;
                    break;
                  }
                  throw new i(s.AUTH_REQUIRED, {
                    api: "auth",
                    cause: "empty login code"
                  });
                case 10:
                  _context23.next = 12;
                  return this.exchangeCode(e.code);
                case 12:
                  n = _context23.sent;
                  o = {
                    kind: "taptap",
                    sessionToken: n.sessionToken,
                    expiresAtMs: this.now() + 1e3 * n.expiresInSec,
                    endpoint: this.endpoint
                  };
                  this.session = o;
                  _context23.next = 17;
                  return this.writeStored(o);
                case 17:
                  return _context23.abrupt("return", o);
                case 18:
                case "end":
                  return _context23.stop();
              }
            }, _callee22, this);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), n.isSessionValid = function (t) {
          return "mock" === t.kind || t.expiresAtMs > this.now();
        }, n.hasValidSession = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee23() {
            var t, e;
            return _regeneratorRuntime().wrap(function _callee23$(_context24) {
              while (1) switch (_context24.prev = _context24.next) {
                case 0:
                  if (!(null != (t = this.session))) {
                    _context24.next = 4;
                    break;
                  }
                  _context24.t0 = t;
                  _context24.next = 7;
                  break;
                case 4:
                  _context24.next = 6;
                  return this.readStored();
                case 6:
                  _context24.t0 = _context24.sent;
                case 7:
                  e = _context24.t0;
                  return _context24.abrupt("return", !!e && this.isSessionValid(e));
                case 9:
                case "end":
                  return _context24.stop();
              }
            }, _callee23, this);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), n.clearSession = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee24() {
            return _regeneratorRuntime().wrap(function _callee24$(_context25) {
              while (1) switch (_context25.prev = _context25.next) {
                case 0:
                  this.session = null;
                  _context25.next = 3;
                  return this.platform.remove(o)["catch"](function () {});
                case 3:
                case "end":
                  return _context25.stop();
              }
            }, _callee24, this);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), n.exchangeCode = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee25(t) {
            var e, n, o, r, u;
            return _regeneratorRuntime().wrap(function _callee25$(_context26) {
              while (1) switch (_context26.prev = _context26.next) {
                case 0:
                  _context26.prev = 0;
                  _context26.next = 3;
                  return this.platform.request({
                    url: this.endpoint + "/v1/auth/taptap/exchange",
                    method: "POST",
                    data: {
                      code: t
                    },
                    headers: {
                      "Content-Type": "application/json"
                    },
                    timeoutMs: this.timeoutMs
                  });
                case 3:
                  n = _context26.sent;
                  _context26.next = 9;
                  break;
                case 6:
                  _context26.prev = 6;
                  _context26.t0 = _context26["catch"](0);
                  throw new i(s.PLATFORM_UNAVAILABLE, {
                    api: "exchange",
                    cause: _context26.t0 instanceof Error ? _context26.t0.message : String(_context26.t0)
                  });
                case 9:
                  if (!(200 === n.statusCode)) {
                    _context26.next = 14;
                    break;
                  }
                  o = n.data;
                  if (!(o && "string" == typeof o.sessionToken && o.sessionToken.length > 0 && "number" == typeof o.expiresInSec && o.expiresInSec > 0)) {
                    _context26.next = 13;
                    break;
                  }
                  return _context26.abrupt("return", o);
                case 13:
                  throw new i(s.AUTH_REQUIRED, {
                    api: "exchange",
                    cause: "malformed 200 response"
                  });
                case 14:
                  u = n.data;
                  if (!(401 === n.statusCode || "TAPTAP_CODE_INVALID" === (null == u ? void 0 : u.code))) {
                    _context26.next = 17;
                    break;
                  }
                  throw new i(s.AUTH_REQUIRED, {
                    api: "exchange",
                    cause: null != (r = null == u ? void 0 : u.code) ? r : "code invalid"
                  });
                case 17:
                  throw new i(s.PLATFORM_UNAVAILABLE, {
                    api: "exchange",
                    cause: null != (e = null == u ? void 0 : u.code) ? e : "http " + n.statusCode
                  });
                case 18:
                case "end":
                  return _context26.stop();
              }
            }, _callee25, this, [[0, 6]]);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), n.readStored = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee26() {
            return _regeneratorRuntime().wrap(function _callee26$(_context27) {
              while (1) switch (_context27.prev = _context27.next) {
                case 0:
                  _context27.prev = 0;
                  _context27.next = 3;
                  return this.platform.get(o);
                case 3:
                  return _context27.abrupt("return", _context27.sent);
                case 6:
                  _context27.prev = 6;
                  _context27.t0 = _context27["catch"](0);
                  return _context27.abrupt("return", null);
                case 9:
                case "end":
                  return _context27.stop();
              }
            }, _callee26, this, [[0, 6]]);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), n.writeStored = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee27(t) {
            return _regeneratorRuntime().wrap(function _callee27$(_context28) {
              while (1) switch (_context28.prev = _context28.next) {
                case 0:
                  _context28.prev = 0;
                  _context28.next = 3;
                  return this.platform.set(o, t);
                case 3:
                  _context28.next = 7;
                  break;
                case 5:
                  _context28.prev = 5;
                  _context28.t0 = _context28["catch"](0);
                case 7:
                case "end":
                  return _context28.stop();
              }
            }, _callee27, this, [[0, 5]]);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), t;
      }());
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/AutoHireService.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./ids.ts", "./CandidateGenerator.ts", "./monthEntry.ts"], function (e) {
  var t, n, a, r, o, i;
  return {
    setters: [function (e) {
      t = e.createForOfIteratorHelperLoose;
    }, function (e) {
      n = e.cclegacy;
    }, function (e) {
      a = e.newId;
    }, function (e) {
      r = e.generateCandidates, o = e.recruitmentFee;
    }, function (e) {
      i = e.monthIndexOf;
    }],
    execute: function execute() {
      function u(e) {
        var t = (e.salaryMonthlyYuan - 4e3) / 4e3 * 100;
        return .45 * e.skill + .25 * e.potential + .15 * e.teamwork + .15 * (100 - t);
      }
      function d(e, t, n) {
        var a = e.employees.filter(function (e) {
            return "ACTIVE" === e.status;
          }).reduce(function (e, t) {
            return e + t.salaryMonthlyYuan;
          }, 0),
          r = t.industry[e.company.industry].fixedManagementAnnualYuan / 12;
        return Math.round((a + r) * n);
      }
      function s(e, t, n, a) {
        var r = e.company.industry,
          o = t.industry[r];
        if ("BUSINESS" === n.type) {
          var u = t.productivity.skillBaseBps + a.skill * t.productivity.skillPerPointBps,
            d = Math.round(o.baseAnnualCapacityPerSkill60EmployeeYuan * u / 1e4),
            s = e.gameYear,
            c = Math.round(o.firstYearDemandYuan * Math.pow(1 + t.demand.naturalAnnualGrowthBps / 1e4, s - 1)),
            l = i(e),
            p = e.departments.find(function (e) {
              return "BUSINESS" === e.type;
            }),
            f = e.employees.filter(function (e) {
              return "ACTIVE" === e.status && p && e.departmentId === p.deptId && e.effectiveFromMonthIndex <= l;
            }).reduce(function (e, n) {
              var a = t.productivity.skillBaseBps + n.skill * t.productivity.skillPerPointBps;
              return e + o.baseAnnualCapacityPerSkill60EmployeeYuan * a / 1e4;
            }, 0),
            m = Math.max(0, c - f),
            h = Math.min(d, m),
            y = 1e4 - o.directCostBps;
          return Math.round(h * y / 1e4);
        }
        var I = t.departments.effects,
          M = o.firstYearDemandYuan;
        switch (n.type) {
          case "PROCUREMENT":
            var v = I.PROCUREMENT.oneQualifiedStaffBps,
              Y = o.procurementEligibleDirectCostBps,
              g = M * o.directCostBps * Y / Math.pow(1e4, 2);
            return Math.round(g * v / 1e4);
          case "CUSTOMER_SERVICE":
            var C = I.CUSTOMER_SERVICE.oneQualifiedStaffBps,
              E = M * o.afterSalesCostBps / 1e4;
            return Math.round(E * C / 1e4);
          case "FINANCE":
            var A = I.FINANCE.oneQualifiedStaffBps,
              B = o.fixedManagementAnnualYuan;
            return Math.round(B * A / 1e4);
          case "MARKETING":
            var S = M * I.MARKETING.oneQualifiedStaffBps / 1e4,
              R = 1e4 - o.directCostBps;
            return Math.round(S * R / 1e4);
          case "HR":
            var T = I.HR.businessCapacityOneStaffBps,
              k = 2 * o.baseAnnualCapacityPerSkill60EmployeeYuan;
            return Math.round(k * T / 1e4);
          default:
            return 0;
        }
      }
      e({
        appendAutomationLog: function appendAutomationLog(e, t) {
          var n, r;
          e.automationLogs.push({
            logId: a("alog", e.runId, e.automationLogs.length + 1),
            year: e.gameYear,
            month: e.gameMonth,
            kind: t.hired ? "AUTO_HIRE" : "AUTO_SKIP",
            deptType: null != (n = t.deptType) ? n : null,
            candidateId: null == (r = t.candidate) ? void 0 : r.candidateId,
            projectedBenefitYuan: t.projectedBenefitYuan,
            projectedCostYuan: t.projectedCostYuan,
            reason: t.reason
          }), e.automationLogs.length > 50 && (e.automationLogs = e.automationLogs.slice(-50));
        },
        candidateScore: u,
        committedCostMonths: d,
        runMonthlyAutoHire: function runMonthlyAutoHire(e, n) {
          var c,
            l = function l(e) {
              return {
                hired: !1,
                reason: e
              };
            };
          if (!e.company) return l("公司不存在");
          if ("RUNNING" !== e.phase) return l("非经营中，跳过自动招聘");
          if ("NORMAL" !== e.cashRisk) return l("现金风险，冻结自动招聘");
          var p = e.gameYear,
            f = null != (c = e.autoHireCountByYear[p]) ? c : 0;
          if (f >= n.recruitment.maxAutoHiresPerYear) return l("本年自动招聘已达上限 " + n.recruitment.maxAutoHiresPerYear + " 人");
          var m = n.policies[e.policy],
            h = m.cashReserveMonths,
            y = m.autoHireMarginThresholdBps,
            I = i(e),
            M = e.departments.filter(function (e) {
              return e.enabled && "AUTO" === e.staffingMode;
            });
          if (0 === M.length) return l("无 AUTO 编制部门");
          for (var v, Y = [], g = t(M); !(v = g()).done;) {
            var C = v.value,
              E = 1e4 + 100 * I + e.departments.indexOf(C),
              A = r({
                runSeed: e.seed,
                deptId: "auto:" + C.deptId,
                offerSequence: E
              }),
              B = [].concat(A).sort(function (e, t) {
                return u(t) - u(e);
              })[0],
              S = o(B.salaryMonthlyYuan),
              R = 12 * B.salaryMonthlyYuan + S,
              T = s(e, n, C, B);
            Y.push({
              dept: C,
              candidate: B,
              feeYuan: S,
              benefit12: T,
              cost12: R,
              score: u(B)
            });
          }
          Y.sort(function (e, t) {
            return t.benefit12 - t.cost12 - (e.benefit12 - e.cost12);
          });
          for (var k, b = function b() {
              var t = O[N];
              if (1e4 * t.benefit12 < t.cost12 * y) return 0;
              var r = d(e, n, h);
              if (e.company.cashYuan - t.feeYuan < r) return {
                v: l("现金安全线：需保留约 " + r + " 元覆盖 " + h + " 个月刚性费用")
              };
              if (e.employees.some(function (e) {
                return e.candidateId === t.candidate.candidateId;
              })) return 0;
              var o = "emp_" + e.runId + "_auto_" + p + "_" + e.gameMonth + "_" + t.dept.type;
              return e.company.cashYuan -= t.feeYuan, e.employees.push({
                employeeId: o,
                name: t.candidate.name,
                avatarId: t.candidate.avatarId,
                departmentId: t.dept.deptId,
                skill: t.candidate.skill,
                potential: t.candidate.potential,
                teamwork: t.candidate.teamwork,
                personality: t.candidate.personality,
                salaryMonthlyYuan: t.candidate.salaryMonthlyYuan,
                hiredAtMonthIndex: I,
                effectiveFromMonthIndex: I + 1,
                dismissedAtMonthIndex: null,
                status: "ACTIVE",
                hireCommandId: a("autohire", e.runId + ":" + p + ":" + e.gameMonth, 1),
                candidateId: t.candidate.candidateId
              }), e.pendingEntries.push({
                entryId: a("je", e.runId + ":AUTO_RECRUIT:" + o, e.pendingEntries.length + 1),
                monthKey: e.runId + ":" + e.gameYear + ":" + e.gameMonth,
                category: "RECRUITMENT",
                amountYuan: -t.feeYuan,
                isCash: !0,
                alreadyPaid: !0,
                refId: o
              }), e.autoHireCountByYear[p] = f + 1, {
                v: {
                  hired: !0,
                  deptId: t.dept.deptId,
                  deptType: t.dept.type,
                  candidate: t.candidate,
                  feeYuan: t.feeYuan,
                  projectedBenefitYuan: t.benefit12,
                  projectedCostYuan: t.cost12,
                  reason: "ROI 达标（预计年贡献 " + t.benefit12 + " ≥ 成本 " + t.cost12 + " × " + y / 1e4 + "）"
                }
              };
            }, N = 0, O = Y; N < O.length; N++) if (0 !== (k = b()) && k) return k.v;
          return l("无满足 ROI 门槛的自动招聘候选");
        }
      }), n._RF.push({}, "e30bbxFIypB5LXz62bvMNi2", "AutoHireService", void 0), n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/Bootstrap.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./AppView.ts"], function (t) {
  var o, n, e, i, s, r, c;
  return {
    setters: [function (t) {
      o = t.inheritsLoose;
    }, function (t) {
      n = t.cclegacy, e = t._decorator, i = t.view, s = t.ResolutionPolicy, r = t.Component;
    }, function (t) {
      c = t.AppView;
    }],
    execute: function execute() {
      var p;
      n._RF.push({}, "fd28ftZA1JO97QoUj9Jou0F", "Bootstrap", void 0);
      var u = e.ccclass;
      t("Bootstrap", u("Bootstrap")(p = function (t) {
        function n() {
          return t.apply(this, arguments) || this;
        }
        return o(n, t), n.prototype.onLoad = function () {
          i.setDesignResolutionSize(375, 812, s.FIXED_WIDTH), this.getComponent(c) || this.addComponent(c);
        }, n;
      }(r)) || p);
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/BootTrap.ts", ["cc"], function (n) {
  var t, e, o, r, i, l;
  return {
    setters: [function (n) {
      t = n.cclegacy, e = n.view, o = n.Node, r = n.UITransform, i = n.Label, l = n.Color;
    }],
    execute: function execute() {
      n({
        bootTrapError: function bootTrapError(n) {
          d("[boot]", n);
        },
        bootTrapReady: function bootTrapReady() {
          c = !0, null !== u && (clearTimeout(u), u = null);
          f && (f.destroy(), f = null);
        },
        bootTrapWatchdog: function bootTrapWatchdog(n) {
          if (g(), null !== u) return;
          var t = e.getVisibleSize();
          (f = new o("BootTrapLabel")).layer = n.layer, f.addComponent(r).setContentSize(t.width - 40, t.height - 160);
          var a = f.addComponent(i);
          f.setPosition(0, -40, 0), a.string = "", a.fontSize = 16, a.lineHeight = 22, a.color = new l(255, 80, 80), a.overflow = i.Overflow.SHRINK, a.horizontalAlign = i.HorizontalAlign.LEFT, a.verticalAlign = i.VerticalAlign.TOP, n.addChild(f), u = setTimeout(function () {
            c || p(!0);
          }, 8e3);
        },
        installBootTrap: g
      }), t._RF.push({}, "7ec95Q3XixHpKuf52EaUPjJ", "BootTrap", void 0);
      var a = [],
        c = !1,
        u = null,
        f = null,
        s = !1;
      function d(n, t) {
        var e;
        e = t instanceof Error ? t.name + ": " + t.message : String(t && "object" == _typeof(t) && "reason" in t ? t.reason : t), a.push((n + " " + e).slice(0, 500)), c || p();
      }
      function g() {
        if (!s) {
          s = !0;
          var n = globalThis;
          try {
            "function" == typeof n.addEventListener && (n.addEventListener("error", function (n) {
              var t,
                e,
                o = n;
              d("[error]", null != (t = null != (e = o.error) ? e : o.message) ? t : n);
            }), n.addEventListener("unhandledrejection", function (n) {
              return d("[unhandled]", n);
            }));
          } catch (n) {}
        }
      }
      function p(n) {
        void 0 === n && (n = !1);
        var t = function (n) {
          return ((n && 0 === a.length ? "BOOT TIMEOUT：8 秒未完成启动，且未捕获到 JS 错误（疑似引擎/运行时级卡死）" : "启动失败，请截图发给开发：") + "\n" + a.join("\n")).slice(0, 1500);
        }(n);
        if (f) {
          var e = f.getComponent(i);
          e && (e.string = t);
        } else try {
          var o = globalThis.canvas,
            r = o && "function" == typeof o.getContext ? o.getContext("2d") : null;
          if (r && "function" == typeof r.fillText) r.fillStyle = "#ff5050", r.font = "24px sans-serif", t.split("\n").forEach(function (n, t) {
            return r.fillText(n, 30, 120 + 36 * t);
          });
        } catch (n) {}
      }
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/CandidateGenerator.ts", ["cc", "./rng.ts", "./ids.ts", "./peopleNames.ts"], function (e) {
  var t, n, a, r, i, o;
  return {
    setters: [function (e) {
      t = e.cclegacy;
    }, function (e) {
      n = e.Rng, a = e.deriveSeed;
    }, function (e) {
      r = e.newId;
    }, function (e) {
      i = e.SURNAMES, o = e.GIVEN_NAMES;
    }],
    execute: function execute() {
      e({
        generateCandidates: function generateCandidates(e) {
          var t = p(e);
          return c.map(function (n, a) {
            var c = t.nextInt(n.skill[0], n.skill[1]),
              p = t.nextInt(n.potential[0], n.potential[1]),
              s = t.nextInt(n.teamwork[0], n.teamwork[1]),
              u = t.nextInt(n.salary[0], n.salary[1]),
              d = t.pick(l),
              f = "" + t.pick(i) + t.pick(o);
            return {
              candidateId: r("cand", e.runSeed + ":" + e.deptId + ":" + e.offerSequence, a + 1),
              name: f,
              avatarId: "avatar_" + String(t.nextInt(0, 7) % 8 + 1).padStart(2, "0"),
              skill: c,
              potential: p,
              teamwork: s,
              personality: d,
              salaryMonthlyYuan: u,
              archetype: n.archetype
            };
          });
        },
        offerRngFor: p,
        recruitmentFee: function recruitmentFee(e, t) {
          void 0 === t && (t = 0);
          var n = Math.max(0, 1e4 - t);
          return Math.round(e * n / 1e4);
        }
      }), t._RF.push({}, "06b0e6jeHpPo43Qgp+hR9LT", "CandidateGenerator", void 0);
      var c = [{
          archetype: "A",
          skill: [75, 90],
          potential: [45, 75],
          teamwork: [45, 85],
          salary: [6200, 8e3]
        }, {
          archetype: "B",
          skill: [50, 70],
          potential: [80, 98],
          teamwork: [50, 90],
          salary: [5e3, 7200]
        }, {
          archetype: "C",
          skill: [45, 72],
          potential: [50, 85],
          teamwork: [55, 90],
          salary: [4e3, 5800]
        }],
        l = ["BOLD", "STEADY", "COLLABORATIVE"];
      function p(e) {
        var t = e.runSeed,
          r = e.deptId,
          i = e.offerSequence;
        return new n(a(t, "offer:" + r, i));
      }
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/canonical.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (r) {
  var e, n;
  return {
    setters: [function (r) {
      e = r.createForOfIteratorHelperLoose;
    }, function (r) {
      n = r.cclegacy;
    }],
    execute: function execute() {
      function t(r) {
        if (Array.isArray(r)) return r.map(t);
        if (null !== r && "object" == _typeof(r)) {
          for (var n, o = r, c = Object.keys(o).sort(), i = {}, u = e(c); !(n = u()).done;) {
            var a = n.value;
            i[a] = t(o[a]);
          }
          return i;
        }
        return r;
      }
      r("canonicalStringify", function (r) {
        return JSON.stringify(t(r));
      }), n._RF.push({}, "07458btUjBDpqloLwzhR0sO", "canonical", void 0), n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/capacity.ts", ["cc", "./money.ts"], function (e) {
  var t, n;
  return {
    setters: [function (e) {
      t = e.cclegacy;
    }, function (e) {
      n = e.roundHalfUp;
    }],
    execute: function execute() {
      function i(e, t) {
        return e.productivity.skillBaseBps + t * e.productivity.skillPerPointBps;
      }
      function o(e, t) {
        if (0 === t.length) return 1e4;
        var n,
          i,
          o,
          r = (t.reduce(function (e, t) {
            return e + t.teamwork;
          }, 0) / t.length - 50) * e.productivity.teamworkPerPointFrom50Bps;
        return n = 1e4 + r, i = e.productivity.minGroupModifierBps, o = e.productivity.maxGroupModifierBps, Math.min(o, Math.max(i, n));
      }
      function r(e, t) {
        return t ? 1e4 + (t.managementSkill - 50) * e.productivity.ceoManagementPerPointFrom50Bps : 1e4;
      }
      function a(e, t) {
        var n = Math.floor(t / 1e4) * e.productivity.businessAssetPer10000YuanBps;
        return 1e4 + Math.min(n, e.productivity.businessAssetCapBps);
      }
      e({
        businessAssetCoeffBps: a,
        ceoManagementCoeffBps: r,
        collaborationCoeffBps: o,
        monthlyCapacity: function monthlyCapacity(e, t, u, s) {
          var c,
            p = e.industry[t].baseAnnualCapacityPerSkill60EmployeeYuan,
            l = u.businessEmployees.filter(function (e) {
              return e.effectiveFromMonthIndex <= s;
            }),
            f = o(e, l),
            m = r(e, u.ceo),
            y = 1e4 + (null != (c = u.hrCapacityBps) ? c : 0),
            d = a(e, u.businessCapacityInvestmentYuan),
            h = f * m * y * d / Math.pow(1e4, 3),
            v = l.map(function (t) {
              var o = i(e, t.skill),
                r = n(p * o / 1e4),
                a = s % 12,
                u = Math.trunc(r / 12),
                c = n((11 === a ? r - 11 * u : u) * h / 1e4);
              return {
                employeeId: t.employeeId,
                skill: t.skill,
                monthlyYuan: c
              };
            }),
            B = v.reduce(function (e, t) {
              return e + t.monthlyYuan;
            }, 0);
          return {
            monthlyCapacityYuan: B,
            annualizedCapacityYuan: 12 * B,
            collaborationBps: f,
            ceoManagementBps: m,
            assetBps: d,
            headcount: l.length,
            perEmployee: v
          };
        },
        skillCoeffBps: i
      }), t._RF.push({}, "b9253tKOmdNFo69cZkouL03", "capacity", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/CocosPlatform.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./errors.ts", "./CocosStorageAdapter.ts"], function (t) {
  var e, n, o, r, i, u, a, s, c, f;
  return {
    setters: [function (t) {
      e = t.asyncToGenerator, n = t["extends"];
    }, function (t) {
      o = t.cclegacy, r = t.view, i = t.screen, u = t.game, a = t.sys;
    }, function (t) {
      s = t.GameError, c = t.GameErrorCode;
    }, function (t) {
      f = t.CocosStorageAdapter;
    }],
    execute: function execute() {
      o._RF.push({}, "a7bcaQYB2xLb7aTNeKiX1ot", "CocosPlatform", void 0);
      t("CocosPlatform", function () {
        function t() {
          this.storageBackend = void 0, this.storageBackend = new f();
        }
        var o = t.prototype;
        return o.getEnvironment = function () {
          return "EDITOR";
        }, o.getWindowInfo = function () {
          var t = r.getVisibleSize();
          return {
            width: t.width,
            height: t.height,
            pixelRatio: i.devicePixelRatio
          };
        }, o.onShow = function (t) {
          return u.on(u.EVENT_SHOW, t), function () {
            return u.off(u.EVENT_SHOW, t);
          };
        }, o.onHide = function (t) {
          return u.on(u.EVENT_HIDE, t), function () {
            return u.off(u.EVENT_HIDE, t);
          };
        }, o.login = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee28() {
            return _regeneratorRuntime().wrap(function _callee28$(_context29) {
              while (1) switch (_context29.prev = _context29.next) {
                case 0:
                  return _context29.abrupt("return", {
                    mock: !0
                  });
                case 1:
                case "end":
                  return _context29.stop();
              }
            }, _callee28);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), o.getNetworkState = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee29() {
            return _regeneratorRuntime().wrap(function _callee29$(_context30) {
              while (1) switch (_context30.prev = _context30.next) {
                case 0:
                  return _context30.abrupt("return", a.isBrowser && !1 === navigator.onLine ? "offline" : "online");
                case 1:
                case "end":
                  return _context30.stop();
              }
            }, _callee29);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), o.get = function (t) {
          return this.storageBackend.get(t);
        }, o.set = function (t, e) {
          return this.storageBackend.set(t, e);
        }, o.remove = function (t) {
          return this.storageBackend.remove(t);
        }, o.request = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee30(t) {
            var e, o, r, i, u, a, f;
            return _regeneratorRuntime().wrap(function _callee30$(_context31) {
              while (1) switch (_context31.prev = _context31.next) {
                case 0:
                  o = "undefined" != typeof AbortController ? new AbortController() : void 0, r = setTimeout(function () {
                    return null == o ? void 0 : o.abort();
                  }, null != (e = t.timeoutMs) ? e : 8e3);
                  _context31.prev = 1;
                  if (!("function" == typeof fetch)) {
                    _context31.next = 10;
                    break;
                  }
                  _context31.next = 5;
                  return fetch(t.url, {
                    method: null != (i = t.method) ? i : "GET",
                    headers: n({
                      "Content-Type": "application/json"
                    }, null != (u = t.headers) ? u : {}),
                    body: void 0 !== t.data ? JSON.stringify(t.data) : void 0,
                    signal: null == o ? void 0 : o.signal
                  });
                case 5:
                  a = _context31.sent;
                  _context31.next = 8;
                  return a.json()["catch"](function () {
                    return null;
                  });
                case 8:
                  f = _context31.sent;
                  return _context31.abrupt("return", {
                    statusCode: a.status,
                    data: f
                  });
                case 10:
                  _context31.next = 12;
                  return this.xhrRequest(t);
                case 12:
                  return _context31.abrupt("return", _context31.sent);
                case 15:
                  _context31.prev = 15;
                  _context31.t0 = _context31["catch"](1);
                  throw new s(c.PLATFORM_UNAVAILABLE, {
                    api: "request",
                    cause: _context31.t0 instanceof Error ? _context31.t0.message : String(_context31.t0)
                  });
                case 18:
                  _context31.prev = 18;
                  clearTimeout(r);
                  return _context31.finish(18);
                case 21:
                case "end":
                  return _context31.stop();
              }
            }, _callee30, this, [[1, 15, 18, 21]]);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), o.xhrRequest = function (t) {
          return new Promise(function (e, n) {
            var o,
              r,
              i = new XMLHttpRequest();
            i.open(null != (o = t.method) ? o : "GET", t.url), i.timeout = null != (r = t.timeoutMs) ? r : 8e3, i.setRequestHeader("Content-Type", "application/json"), i.onload = function () {
              try {
                e({
                  statusCode: i.status,
                  data: JSON.parse(i.responseText)
                });
              } catch (t) {
                e({
                  statusCode: i.status,
                  data: null
                });
              }
            }, i.onerror = function () {
              return n(new s(c.PLATFORM_UNAVAILABLE, {
                api: "request",
                cause: "xhr error"
              }));
            }, i.ontimeout = function () {
              return n(new s(c.PLATFORM_UNAVAILABLE, {
                api: "request",
                cause: "xhr timeout"
              }));
            }, i.send(void 0 !== t.data ? JSON.stringify(t.data) : void 0);
          });
        }, t;
      }());
      o._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/CocosStorageAdapter.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (t) {
  var r, e, n;
  return {
    setters: [function (t) {
      r = t.asyncToGenerator;
    }, function (t) {
      e = t.cclegacy, n = t.sys;
    }],
    execute: function execute() {
      e._RF.push({}, "3cc236eyOtHVqEjkmtVO2ms", "CocosStorageAdapter", void 0);
      t("CocosStorageAdapter", function () {
        function t() {
          this.storage = void 0;
          var t = n.localStorage;
          if (!t) throw new Error("localStorage unavailable on this runtime");
          this.storage = t;
        }
        var e = t.prototype;
        return e.get = function () {
          var t = r( /*#__PURE__*/_regeneratorRuntime().mark(function _callee31(t) {
            var r;
            return _regeneratorRuntime().wrap(function _callee31$(_context32) {
              while (1) switch (_context32.prev = _context32.next) {
                case 0:
                  r = this.storage.getItem(t);
                  return _context32.abrupt("return", null == r || "" === r ? null : JSON.parse(r));
                case 2:
                case "end":
                  return _context32.stop();
              }
            }, _callee31, this);
          }));
          return function (r) {
            return t.apply(this, arguments);
          };
        }(), e.set = function () {
          var t = r( /*#__PURE__*/_regeneratorRuntime().mark(function _callee32(t, r) {
            return _regeneratorRuntime().wrap(function _callee32$(_context33) {
              while (1) switch (_context33.prev = _context33.next) {
                case 0:
                  this.storage.setItem(t, JSON.stringify(r));
                case 1:
                case "end":
                  return _context33.stop();
              }
            }, _callee32, this);
          }));
          return function (r, e) {
            return t.apply(this, arguments);
          };
        }(), e.remove = function () {
          var t = r( /*#__PURE__*/_regeneratorRuntime().mark(function _callee33(t) {
            return _regeneratorRuntime().wrap(function _callee33$(_context34) {
              while (1) switch (_context34.prev = _context34.next) {
                case 0:
                  this.storage.removeItem(t);
                case 1:
                case "end":
                  return _context34.stop();
              }
            }, _callee33, this);
          }));
          return function (r) {
            return t.apply(this, arguments);
          };
        }(), t;
      }());
      e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/command.ts", ["cc"], function (e) {
  var n;
  return {
    setters: [function (e) {
      n = e.cclegacy;
    }],
    execute: function execute() {
      e("assertCommandBase", function (e) {
        if ("string" != typeof e.commandId || 0 === e.commandId.length) throw new Error("commandId is required");
        if ("string" != typeof e.expectedRunId || 0 === e.expectedRunId.length) throw new Error("expectedRunId is required");
      }), n._RF.push({}, "aa271YRnGJJ/4XIc7SY5Lly", "command", void 0);
      e("EXECUTED_COMMAND_ID_KEEP", 200);
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/companyNames.ts", ["cc"], function (N) {
  var c;
  return {
    setters: [function (N) {
      c = N.cclegacy;
    }],
    execute: function execute() {
      c._RF.push({}, "accdf/qwt5JnZ8/gByeYh6/", "companyNames", void 0);
      N("COMPANY_NAME_PREFIXES", ["今天也盈利", "老板有点忙", "一条咸鱼", "明天上市吗", "亿点点梦想", "元气满满", "不想加班", "万事开头难", "稳中带赢", "小而美", "摸鱼也要赢", "星河滚烫", "早起的鸟儿", "向阳而生", "乘风破浪", "闷声发财", "鹏程万里", "步步为营", "日进斗金", "认真搞钱", "好事发生", "轻装上阵", "大器晚成", "野蛮生长", "长期主义", "全力以赴", "人间清醒", "好运连连", "乘风破浪的", "宝藏小队", "逆风翻盘", "蒸蒸日上"]), N("INDUSTRY_SUFFIXES", {
        TRADE: ["优品商城", "好物严选", "环球货仓", "甄选百货", "云货架", "好物集", "买卖通", "优选电商"],
        SOFTWARE: ["智能科技", "数造软件", "云启技术", "码力工坊", "极客软件", "智算科技", "云端工作室", "数科"],
        SERVICE: ["企业管家", "省心服务", "通力企服", "好搭档", "企业好帮手", "精诚服务", "企服中心", "护航者"]
      }), N("COMPANY_NAME_ENDINGS", ["有限公司", "工作室", "团队", "铺子", "事务所"]), N("FORBIDDEN_NAME_WORDS", ["官方", "国企", "中央", "政府", "行政", "腾讯", "阿里巴巴", "字节跳动", "百度"]), N("COMPANY_NAME_MIN", 2), N("COMPANY_NAME_MAX", 20);
      c._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/CompanyService.ts", ["cc", "./errors.ts", "./MutationContext.ts", "./validators.ts", "./ids.ts", "./validation.ts"], function (n) {
  var a, e, t, r, o, i, s, d, u, c, I;
  return {
    setters: [function (n) {
      a = n.cclegacy;
    }, function (n) {
      e = n.GameErrorCode;
    }, function (n) {
      t = n.ensureRunId, r = n.hasCommand, o = n.INITIAL_CAPITAL_YUAN, i = n.recordCommand;
    }, null, function (n) {
      s = n.newId;
    }, function (n) {
      d = n.validateCompanyName, u = n.validatePersonName, c = n.isValidIndustry, I = n.isValidCeoTrait;
    }],
    execute: function execute() {
      n({
        createCompany: function createCompany(n, a, m) {
          if (t(n, m.expectedRunId), r(n, m.commandId) && n.company) return {
            companyId: n.company.companyId,
            runId: n.runId,
            cashYuan: n.company.cashYuan
          };
          if ("CREATING" !== n.phase || null !== n.company || n.initializedCapital) throw new Error(e.NOT_READY);
          var p = d(a.companyName);
          if (!p.ok) throw new Error(e.INVALID_NAME);
          var l = u(a.ceoName);
          if (!l.ok) throw new Error(e.INVALID_NAME);
          if (!c(a.industry)) throw new Error(e.INVALID_INDUSTRY);
          if (!I(a.ceoTrait)) throw new Error(e.INVALID_TRAIT);
          var y = s("co", n.runId, 0),
            C = {
              companyId: y,
              name: p.name,
              industry: a.industry,
              foundedYear: n.gameYear,
              cashYuan: o,
              initialCapitalYuan: o,
              paidInCapitalYuan: o,
              businessAssetBookYuan: 0,
              businessCapacityInvestmentYuan: 0,
              businessCapacityBonusBps: 0,
              marketDemandIndexBps: 1e4
            },
            N = {
              name: l.name,
              trait: a.ceoTrait,
              businessSkill: 50,
              managementSkill: 50,
              financeSkill: 50
            };
          return n.departments = [{
            deptId: s("dp", n.runId + ":BUSINESS", 0),
            type: "BUSINESS",
            enabled: !0,
            staffingMode: "AUTO",
            targetCount: 0,
            createdMonthIndex: 0,
            setupPaid: !0
          }], n.company = C, n.ceo = N, n.initializedCapital = !0, n.yearOpenCashYuan = {
            1: o
          }, n.phase = "HIRING_INITIAL", n.speed = 0, n.onboarding.stepId = "TUT-03", n.onboarding.lastKnownStep = "TUT-03", i(n, m.commandId), {
            companyId: y,
            runId: n.runId,
            cashYuan: C.cashYuan
          };
        },
        rollCeoName: function rollCeoName(n) {
          return "" + n.pick(["林", "陈", "赵", "王", "李", "周", "孙", "何"]) + n.pick(["启航", "稳", "亲和", "远征", "思源", "明达", "一诺", "静宜"]);
        }
      }), a._RF.push({}, "6e059da63JJ5IHeo8h33Lor", "CompanyService", void 0), a._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/configLoader.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./types.ts"], function (e) {
  var n, i, t, o, a;
  return {
    setters: [function (e) {
      n = e.inheritsLoose, i = e.createForOfIteratorHelperLoose, t = e.wrapNativeSuper;
    }, function (e) {
      o = e.cclegacy;
    }, function (e) {
      a = e.INDUSTRIES;
    }],
    execute: function execute() {
      e({
        getConfig: function getConfig() {
          if (!c) throw new u("economy config not loaded");
          return c;
        },
        industryConfig: function industryConfig(e, n) {
          var i = e.industry[n];
          if (!i) throw new u("no config for industry " + n);
          return i;
        },
        registerConfig: function registerConfig(e) {
          return c = s(e);
        },
        validateEconomyConfig: s
      }), o._RF.push({}, "a71f6E67SVDz5R5zxcpfCJw", "configLoader", void 0);
      var r = e("ECONOMY_CONFIG_VERSION", "economy-v1.0.0"),
        u = e("ConfigValidationError", function (e) {
          function i(n) {
            var i;
            return (i = e.call(this, n) || this).name = "ConfigValidationError", i;
          }
          return n(i, e), i;
        }(t(Error)));
      function l(e, n) {
        if (!e) throw new u(n);
      }
      function s(e) {
        var n, t, o, u, s, c, d, f, m, p, v, y, g, C, Y, b, E, h, S;
        l("object" == _typeof(e) && null !== e, "config must be object");
        var R = e;
        l(R.configVersion === r, "bad configVersion: " + String(R.configVersion)), l("CNY" === R.currency, "currency must be CNY"), l("bps" === R.ratioUnit, "ratioUnit must be bps"), l(3e5 === (null == (n = R.player) ? void 0 : n.initialCapitalYuan), "initialCapital must be 300000"), l(2 === (null == (t = R.player) ? void 0 : t.initialEmployeeCount), "initialEmployeeCount must be 2"), l(3 === (null == (o = R.player) ? void 0 : o.continuousProfitYearsForGoal), "goal years must be 3"), l(12 === (null == (u = R.time) ? void 0 : u.monthsPerYear), "monthsPerYear must be 12"), l(3e5 === (null == (s = R.time) ? void 0 : s.onlineYearDurationMsAt1x), "1x year must be 300000ms"), l(JSON.stringify(null == (c = R.time) ? void 0 : c.onlineSpeedMultipliers) === JSON.stringify([1, 2, 5]), "speed multipliers must be [1,2,5]"), l(24e5 === (null == (d = R.time) ? void 0 : d.offlineRealMsPerGameMonth), "offline month must be 40min"), l(36 === (null == (f = R.time) ? void 0 : f.maxOfflineMonthsPerSession), "offline cap must be 36"), l(3 === (null == (m = R.recruitment) ? void 0 : m.candidateCount), "candidate count must be 3"), l(4e3 === (null == (p = R.recruitment) ? void 0 : p.salaryMonthlyYuanMin), "salary min 4000"), l(8e3 === (null == (v = R.recruitment) ? void 0 : v.salaryMonthlyYuanMax), "salary max 8000"), l(1e4 === (null == (y = R.departments) ? void 0 : y.setupFeeYuan), "dept setup fee 10000");
        for (var x, M = i(a); !(x = M()).done;) {
          var A,
            D = x.value,
            P = null == (A = R.industry) ? void 0 : A[D];
          l(!!P, "missing industry " + D), l(P.firstYearDemandYuan > 0, D + " demand > 0"), l(P.baseAnnualCapacityPerSkill60EmployeeYuan > 0, D + " capacity > 0"), l(P.directCostBps > 0 && P.directCostBps < 1e4, D + " direct bps range"), l(48e3 === P.fixedManagementAnnualYuan, D + " fixed cost 48000");
        }
        return l(72e4 === R.industry.TRADE.firstYearDemandYuan, "TRADE demand 720000"), l(4e5 === R.industry.TRADE.baseAnnualCapacityPerSkill60EmployeeYuan, "TRADE per-capacity 400000"), l(4e5 === R.industry.SOFTWARE.firstYearDemandYuan, "SOFTWARE demand 400000"), l(45e4 === R.industry.SERVICE.firstYearDemandYuan, "SERVICE demand 450000"), l(1e5 === (null == (g = R.risk) ? void 0 : g.oneTimeRescueCapitalYuan), "rescue 100000"), l(2500 === (null == (C = R.risk) ? void 0 : C.eventAnnualChanceBps), "event chance 25%"), l(1 === (null == (Y = R.save) ? void 0 : Y.schemaVersion), "schema v1"), l(5e5 === (null == (b = R.save) ? void 0 : b.targetMaxBytesPerSlot), "save slot 500KB"), l(12 === (null == (E = R.localBots) ? void 0 : E.count), "12 bots"), l(375 === (null == (h = R.ui) ? void 0 : h.designWidthLogicalPx) && 812 === (null == (S = R.ui) ? void 0 : S.designHeightLogicalPx), "ui 375x812"), R;
      }
      var c = null;
      o._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/crc32.ts", ["cc"], function (r) {
  var t;
  return {
    setters: [function (r) {
      t = r.cclegacy;
    }],
    execute: function execute() {
      r({
        crc32Bytes: e,
        crc32String: function crc32String(r) {
          return e(c.encode(r)).toString(16).padStart(8, "0");
        }
      }), t._RF.push({}, "9cdf4iWwBtLs5pEwSGWO+X1", "crc32", void 0);
      var n = function () {
          for (var r = new Uint32Array(256), t = 0; t < 256; t++) {
            for (var n = t, c = 0; c < 8; c++) n = 1 & n ? 3988292384 ^ n >>> 1 : n >>> 1;
            r[t] = n >>> 0;
          }
          return r;
        }(),
        c = new TextEncoder();
      function e(r) {
        for (var t = 4294967295, c = 0; c < r.length; c++) {
          var e = r[c];
          t = n[255 & (t ^ e)] ^ t >>> 8;
        }
        return (4294967295 ^ t) >>> 0;
      }
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/departments.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./money.ts"], function (e) {
  var t, n, r;
  return {
    setters: [function (e) {
      t = e.createForOfIteratorHelperLoose;
    }, function (e) {
      n = e.cclegacy;
    }, function (e) {
      r = e.roundHalfUp;
    }],
    execute: function execute() {
      function f(e, t) {
        return e.pendingDepartmentId && "number" == typeof e.transferFromMonthIndex && t >= e.transferFromMonthIndex ? e.pendingDepartmentId : e.departmentId;
      }
      function a(e, t, n) {
        var r = e.departments.find(function (e) {
          return e.type === t && e.enabled;
        });
        return r ? e.employees.filter(function (e) {
          return "ACTIVE" === e.status && f(e, n) === r.deptId && e.effectiveFromMonthIndex <= n;
        }) : [];
      }
      function s(e, t) {
        var n = e.productivity.skillBaseBps + t * e.productivity.skillPerPointBps;
        return Math.min(e.departments.maxSkillFactorBps, Math.max(e.departments.minSkillFactorBps, n));
      }
      function p(e, t) {
        var n,
          r = e.departments.staffMultiplierBps;
        return t <= 0 || 0 === r.length ? 0 : null != (n = r[Math.min(t, r.length - 1)]) ? n : 0;
      }
      function i(e, t, n, f, a) {
        var i = n.length,
          c = 0 === i ? 0 : n.reduce(function (e, t) {
            return e + t.skill;
          }, 0) / i,
          u = p(e, i),
          o = 0 === i ? 0 : s(e, c),
          d = 0 === i ? 0 : f * u * o / Math.pow(1e4, 2);
        return {
          type: t,
          headcount: i,
          avgSkill: c,
          staffBps: u,
          skillBps: o,
          effectBps: Math.min(a, r(d))
        };
      }
      function c(e, t) {
        return i(e, "PROCUREMENT", t, e.departments.effects.PROCUREMENT.oneQualifiedStaffBps, e.departments.effects.PROCUREMENT.capBps);
      }
      function u(e, t) {
        return i(e, "CUSTOMER_SERVICE", t, e.departments.effects.CUSTOMER_SERVICE.oneQualifiedStaffBps, e.departments.effects.CUSTOMER_SERVICE.capBps);
      }
      function o(e, t) {
        return i(e, "FINANCE", t, e.departments.effects.FINANCE.oneQualifiedStaffBps, e.departments.effects.FINANCE.capBps);
      }
      function d(e, t) {
        return i(e, "MARKETING", t, e.departments.effects.MARKETING.oneQualifiedStaffBps, e.departments.effects.MARKETING.capBps);
      }
      function m(e, t) {
        return i(e, "HR", t, e.departments.effects.HR.businessCapacityOneStaffBps, e.departments.effects.HR.businessCapacityCapBps);
      }
      function l(e, t) {
        var n = e.departments.effects.HR.recruitmentDiscountOneStaffBps,
          r = e.departments.effects.HR.recruitmentDiscountCapBps;
        return Math.min(r, t.length * n);
      }
      e({
        activeStaffInDept: a,
        applyDueTransfers: function applyDueTransfers(e, n) {
          for (var r, f = t(e.employees); !(r = f()).done;) {
            var a = r.value;
            a.pendingDepartmentId && "number" == typeof a.transferFromMonthIndex && n + 1 >= a.transferFromMonthIndex && (a.departmentId = a.pendingDepartmentId, a.pendingDepartmentId = void 0, a.transferFromMonthIndex = null);
          }
        },
        computeSupportEffects: function computeSupportEffects(e, t, n) {
          var r = a(t, "PROCUREMENT", n),
            f = a(t, "CUSTOMER_SERVICE", n),
            s = a(t, "FINANCE", n),
            p = a(t, "MARKETING", n),
            i = a(t, "HR", n);
          return {
            procurement: c(e, r),
            customerService: u(e, f),
            finance: o(e, s),
            marketing: d(e, p),
            hrCapacity: m(e, i),
            hrRecruitmentDiscountBps: l(e, i)
          };
        },
        customerServiceEffect: u,
        deptIdAtMonth: f,
        deptSkillFactorBps: s,
        financeEffect: o,
        hrCapacityEffect: m,
        hrRecruitmentDiscountBps: l,
        marketingEffect: d,
        procurementEffect: c,
        staffCountMultiplierBps: p
      }), n._RF.push({}, "f78d9P9nZNJk4XZNK46k2mL", "departments", void 0), n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/DepartmentService.ts", ["cc", "./errors.ts", "./ids.ts", "./types.ts", "./MutationContext.ts", "./monthEntry.ts"], function (e) {
  var n, t, r, a, o, u, d, c, i;
  return {
    setters: [function (e) {
      n = e.cclegacy;
    }, function (e) {
      t = e.GameErrorCode;
    }, function (e) {
      r = e.newId;
    }, function (e) {
      a = e.SUPPORT_DEPARTMENTS;
    }, function (e) {
      o = e.ensureRunId, u = e.hasCommand, d = e.recordCommand;
    }, function (e) {
      c = e.monthIndexOf, i = e.addPendingEntry;
    }],
    execute: function execute() {
      function s(e) {
        return a.includes(e);
      }
      e({
        createDepartment: function createDepartment(e, n, a, f) {
          if (o(e, f.expectedRunId), !e.company) throw new Error(t.NOT_READY);
          if (!s(a)) throw new Error(t.INVALID_TARGET);
          if ("RUNNING" !== e.phase && "DISTRESS" !== e.phase) throw new Error(t.NOT_READY);
          if (u(e, f.commandId)) {
            var p = e.departments.find(function (e) {
              return e.type === a;
            });
            if (p) return {
              department: p,
              feePaidYuan: 0,
              cashAfterYuan: e.company.cashYuan
            };
          }
          if (e.departments.some(function (e) {
            return e.type === a;
          })) throw new Error(t.DEPT_ALREADY_EXISTS);
          var m = n.departments.setupFeeYuan;
          if (e.company.cashYuan < m) throw new Error(t.INSUFFICIENT_CASH);
          var E = c(e),
            I = {
              deptId: r("dp", e.runId + ":" + a, e.departments.length),
              type: a,
              enabled: !0,
              staffingMode: "LOCKED",
              targetCount: 0,
              createdMonthIndex: E,
              setupPaid: !0
            };
          return e.company.cashYuan -= m, i(e, "DEPT_SETUP", -m, f.commandId), e.departments.push(I), d(e, f.commandId), {
            department: I,
            feePaidYuan: m,
            cashAfterYuan: e.company.cashYuan
          };
        },
        isSupportDeptType: s,
        previewCreateDepartment: function previewCreateDepartment(e, n, t) {
          var r,
            a,
            o = n.departments.setupFeeYuan,
            u = e.departments.some(function (e) {
              return e.type === t;
            });
          return {
            feeYuan: o,
            cashAfterYuan: (null != (r = null == (a = e.company) ? void 0 : a.cashYuan) ? r : 0) - o,
            alreadyExists: u
          };
        },
        setStaffingMode: function setStaffingMode(e, n, r, a) {
          o(e, a.expectedRunId);
          var u = e.departments.find(function (e) {
            return e.deptId === n;
          });
          if (!u) throw new Error(t.DEPT_NOT_FOUND);
          if ("AUTO" !== r && "LOCKED" !== r) throw new Error(t.INVALID_TARGET);
          return u.staffingMode = r, d(e, a.commandId), u;
        },
        setTargetCount: function setTargetCount(e, n, r, a) {
          o(e, a.expectedRunId);
          var u = e.departments.find(function (e) {
            return e.deptId === n;
          });
          if (!u) throw new Error(t.DEPT_NOT_FOUND);
          if (!Number.isSafeInteger(r) || r < 0 || r > 50) throw new Error(t.INVALID_TARGET);
          return u.targetCount = r, d(e, a.commandId), u;
        }
      }), n._RF.push({}, "af51eFIpf9GLKeynxJFi/TE", "DepartmentService", void 0), n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/EconomyConfig.ts", ["cc"], function () {
  var c;
  return {
    setters: [function (n) {
      c = n.cclegacy;
    }],
    execute: function execute() {
      c._RF.push({}, "bfc583DW9VIq4k2ZDO+KhRl", "EconomyConfig", void 0), c._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/EditorMockPlatform.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./MemoryStorage.ts"], function (t) {
  var n, e, r, o;
  return {
    setters: [function (t) {
      n = t.createForOfIteratorHelperLoose, e = t.asyncToGenerator;
    }, function (t) {
      r = t.cclegacy;
    }, function (t) {
      o = t.MemoryStorage;
    }],
    execute: function execute() {
      r._RF.push({}, "f5abauzUsFGzruJa0CDNRXR", "EditorMockPlatform", void 0);
      t("EditorMockPlatform", function () {
        function t(t, n) {
          this.storage = void 0, this.showListeners = new Set(), this.hideListeners = new Set(), this.network = "online", this.windowInfo = void 0, this.httpHandler = null, this.storage = null != t ? t : new o(), this.windowInfo = null != n ? n : {
            width: 375,
            height: 812,
            pixelRatio: 2,
            safeArea: {
              top: 44,
              bottom: 34,
              left: 0,
              right: 0
            }
          };
        }
        var r = t.prototype;
        return r.setHttpHandler = function (t) {
          this.httpHandler = t;
        }, r.getEnvironment = function () {
          return "EDITOR";
        }, r.getWindowInfo = function () {
          return this.windowInfo;
        }, r.setWindowInfo = function (t) {
          this.windowInfo = t;
        }, r.onShow = function (t) {
          var n = this;
          return this.showListeners.add(t), function () {
            return n.showListeners["delete"](t);
          };
        }, r.onHide = function (t) {
          var n = this;
          return this.hideListeners.add(t), function () {
            return n.hideListeners["delete"](t);
          };
        }, r.emitShow = function () {
          for (var t, e = n(this.showListeners); !(t = e()).done;) {
            (0, t.value)();
          }
        }, r.emitHide = function () {
          for (var t, e = n(this.hideListeners); !(t = e()).done;) {
            (0, t.value)();
          }
        }, r.login = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee34() {
            return _regeneratorRuntime().wrap(function _callee34$(_context35) {
              while (1) switch (_context35.prev = _context35.next) {
                case 0:
                  return _context35.abrupt("return", {
                    mock: !0
                  });
                case 1:
                case "end":
                  return _context35.stop();
              }
            }, _callee34);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), r.getNetworkState = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee35() {
            return _regeneratorRuntime().wrap(function _callee35$(_context36) {
              while (1) switch (_context36.prev = _context36.next) {
                case 0:
                  return _context36.abrupt("return", this.network);
                case 1:
                case "end":
                  return _context36.stop();
              }
            }, _callee35, this);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), r.setNetworkState = function (t) {
          this.network = t;
        }, r.get = function (t) {
          return this.storage.get(t);
        }, r.set = function (t, n) {
          return this.storage.set(t, n);
        }, r.remove = function (t) {
          return this.storage.remove(t);
        }, r.request = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee36(t) {
            return _regeneratorRuntime().wrap(function _callee36$(_context37) {
              while (1) switch (_context37.prev = _context37.next) {
                case 0:
                  if (!this.httpHandler) {
                    _context37.next = 6;
                    break;
                  }
                  _context37.next = 3;
                  return this.httpHandler(t);
                case 3:
                  _context37.t0 = _context37.sent;
                  _context37.next = 7;
                  break;
                case 6:
                  _context37.t0 = {
                    statusCode: 503,
                    data: {
                      code: "TAPTAP_UPSTREAM_UNAVAILABLE"
                    }
                  };
                case 7:
                  return _context37.abrupt("return", _context37.t0);
                case 8:
                case "end":
                  return _context37.stop();
              }
            }, _callee36, this);
          }));
          return function (n) {
            return t.apply(this, arguments);
          };
        }(), t;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/errors.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (E) {
  var I, _, A, N;
  return {
    setters: [function (E) {
      I = E.inheritsLoose, _ = E["extends"], A = E.wrapNativeSuper;
    }, function (E) {
      N = E.cclegacy;
    }],
    execute: function execute() {
      E("errorMessage", function (E, I) {
        var _ = D[E];
        if (I) for (var A = 0, N = Object.entries(I); A < N.length; A++) {
          var O = N[A],
            T = O[0],
            L = O[1];
          _ = _.replace("{" + T + "}", String(L));
        }
        return _;
      }), N._RF.push({}, "9ab40aVHt9OYJySCrxHOFd0", "errors", void 0);
      E("GameErrorCode", {
        NOT_READY: "NOT_READY",
        RUN_CHANGED: "RUN_CHANGED",
        REVISION_CONFLICT: "REVISION_CONFLICT",
        INVALID_NAME: "INVALID_NAME",
        INVALID_INDUSTRY: "INVALID_INDUSTRY",
        INVALID_TRAIT: "INVALID_TRAIT",
        INVALID_POLICY: "INVALID_POLICY",
        INVALID_SPEED: "INVALID_SPEED",
        INVALID_AMOUNT: "INVALID_AMOUNT",
        INVALID_TARGET: "INVALID_TARGET",
        ONBOARDING_INCOMPLETE: "ONBOARDING_INCOMPLETE",
        OFFER_EXPIRED: "OFFER_EXPIRED",
        INSUFFICIENT_CASH: "INSUFFICIENT_CASH",
        DEPT_ALREADY_EXISTS: "DEPT_ALREADY_EXISTS",
        DEPT_NOT_FOUND: "DEPT_NOT_FOUND",
        EMPLOYEE_NOT_FOUND: "EMPLOYEE_NOT_FOUND",
        EMPLOYEE_NOT_DISMISSIBLE: "EMPLOYEE_NOT_DISMISSIBLE",
        CONFIRMATION_EXPIRED: "CONFIRMATION_EXPIRED",
        AUTOMATION_LOCKED: "AUTOMATION_LOCKED",
        MONTH_ALREADY_SETTLED: "MONTH_ALREADY_SETTLED",
        ALREADY_USED: "ALREADY_USED",
        SAVE_FAILED: "SAVE_FAILED",
        SAVE_CORRUPT: "SAVE_CORRUPT",
        RESET_IN_PROGRESS: "RESET_IN_PROGRESS",
        PLATFORM_UNAVAILABLE: "PLATFORM_UNAVAILABLE",
        AUTH_REQUIRED: "AUTH_REQUIRED"
      });
      var D = {
        NOT_READY: "当前还不能进行该操作。",
        RUN_CHANGED: "公司已重新创建，旧操作已取消。",
        REVISION_CONFLICT: "状态已变化，请刷新后重试。",
        INVALID_NAME: "名称不合法，请检查长度或内容后重试。",
        INVALID_INDUSTRY: "请选择一个有效的主营行业。",
        INVALID_TRAIT: "请选择一个有效的 CEO 性格。",
        INVALID_POLICY: "经营方针无效。",
        INVALID_SPEED: "时间速度无效。",
        INVALID_AMOUNT: "金额无效。",
        INVALID_TARGET: "目标人数无效。",
        ONBOARDING_INCOMPLETE: "请先完成初始招聘。",
        OFFER_EXPIRED: "候选人信息已经更新，请重新选择。",
        INSUFFICIENT_CASH: "当前现金不足，还需要 ¥{gap}。",
        DEPT_ALREADY_EXISTS: "已创建此部门，可进入管理。",
        DEPT_NOT_FOUND: "部门不存在。",
        EMPLOYEE_NOT_FOUND: "员工不存在。",
        EMPLOYEE_NOT_DISMISSIBLE: "该员工当前不可裁员。",
        CONFIRMATION_EXPIRED: "确认已失效，请重新查看费用后确认。",
        AUTOMATION_LOCKED: "该部门已手动锁定，自动经营不会改动。",
        MONTH_ALREADY_SETTLED: "本月已结算。",
        ALREADY_USED: "该一次性机会已经使用过。",
        SAVE_FAILED: "保存失败，本次操作未确认保存，请重试。",
        SAVE_CORRUPT: "本地存档损坏且无法自动恢复。",
        RESET_IN_PROGRESS: "正在关闭旧公司，暂不能执行其他操作。",
        PLATFORM_UNAVAILABLE: "平台能力暂不可用，可先进行本地游玩。",
        AUTH_REQUIRED: "需要完成平台登录后才能继续。"
      };
      E("GameError", function (E) {
        function A(I, A, N) {
          var O;
          return (O = E.call(this, null != N ? N : D[I]) || this).code = void 0, O.details = void 0, O.name = "GameError", O.code = I, void 0 !== A && (O.details = _({}, A)), O;
        }
        return I(A, E), A.prototype.toDisplayMessage = function (E) {
          var I = D[this.code];
          if (E) for (var _ = 0, A = Object.entries(E); _ < A.length; _++) {
            var N = A[_],
              O = N[0],
              T = N[1];
            I = I.replace("{" + O + "}", String(T));
          }
          return I;
        }, A;
      }(A(Error)));
      N._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/GameClock.ts", ["cc", "./errors.ts", "./advanceMonth.ts"], function (e) {
  var t, r, n;
  return {
    setters: [function (e) {
      t = e.cclegacy;
    }, function (e) {
      r = e.GameErrorCode;
    }, function (e) {
      n = e.advanceMonth;
    }],
    execute: function execute() {
      e("msPerMonth", o), t._RF.push({}, "565dcs0rf1FiZH/k2CRO639", "GameClock", void 0);
      var s = e("SPEED_TO_MS_PER_YEAR", {
        0: 0,
        1: 3e5,
        2: 15e4,
        5: 6e4
      });
      function o(e, t) {
        var r;
        return (null != (r = s[t]) ? r : 0) / e.time.monthsPerYear;
      }
      e("GameClock", function () {
        function e() {
          this.beforeMonthSettle = null, this.afterMonthSettle = null;
        }
        var t = e.prototype;
        return t.tick = function (e, t, r, s) {
          var a,
            h = null != s ? s : e.speed,
            c = {
              monthsAdvanced: 0,
              yearsClosed: []
            };
          if (0 === h || "RUNNING" !== e.phase) return c;
          var l = o(t, h);
          if (l <= 0) return c;
          for (e.progressMsInMonth = (null != (a = e.progressMsInMonth) ? a : 0) + r; e.progressMsInMonth >= l && "RUNNING" === e.phase;) {
            var u;
            e.progressMsInMonth -= l, null == (u = this.beforeMonthSettle) || u.call(this, e, t);
            var i = n(e, t);
            if (c.monthsAdvanced += 1, i.yearClosed && c.yearsClosed.push(e.gameYear - 1), this.afterMonthSettle && !this.afterMonthSettle(e, t)) {
              e.phase = "DISTRESS", e.speed = 0;
              break;
            }
          }
          return e.progressMsInMonth < 0 && (e.progressMsInMonth = 0), c;
        }, t.setSpeed = function (e, t) {
          if (0 !== t && 1 !== t && 2 !== t && 5 !== t) throw new Error(r.INVALID_SPEED);
          e.speed = t;
        }, e;
      }());
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/GameFacade.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./errors.ts", "./result.ts", "./GameStore.ts", "./CompanyService.ts", "./OfferService.ts", "./RecruitmentService.ts", "./ResetService.ts", "./gameStateFactory.ts", "./NameGenerator.ts", "./rng.ts", "./GameClock.ts", "./InvestmentService.ts", "./DepartmentService.ts", "./LayoffService.ts", "./AutoHireService.ts", "./TransferService.ts", "./RiskService.ts", "./offline.ts", "./leaderboard.ts"], function (t) {
  var e, r, n, u, i, o, s, c, a, f, h, d, l, v, p, y, m, R, I, g, S, C, Y, w, L, A, D, E, k, G, O, x, T, b, N, P, M, _, F;
  return {
    setters: [function (t) {
      e = t.asyncToGenerator;
    }, function (t) {
      r = t.cclegacy;
    }, function (t) {
      n = t.GameErrorCode, u = t.errorMessage, i = t.GameError;
    }, function (t) {
      o = t.ok, s = t.fail;
    }, function (t) {
      c = t.GameStore;
    }, function (t) {
      a = t.createCompany;
    }, function (t) {
      f = t.getOffer, h = t.refreshOffer;
    }, function (t) {
      d = t.hireEmployee, l = t.startOperating;
    }, function (t) {
      v = t.closeCompanyPreview, p = t.confirmCloseCompany;
    }, function (t) {
      y = t.createInitialState;
    }, function (t) {
      m = t.NameGenerator;
    }, function (t) {
      R = t.Rng, I = t.deriveSeed;
    }, function (t) {
      g = t.GameClock;
    }, function (t) {
      S = t.previewInvest, C = t.investInBusiness;
    }, function (t) {
      Y = t.previewCreateDepartment, w = t.createDepartment, L = t.setStaffingMode, A = t.setTargetCount;
    }, function (t) {
      D = t.previewLayoff, E = t.createLayoffToken, k = t.confirmLayoff;
    }, function (t) {
      G = t.runMonthlyAutoHire, O = t.appendAutomationLog;
    }, function (t) {
      x = t.previewTransfer, T = t.transferEmployee;
    }, function (t) {
      b = t.assessRisk, N = t.refreshRisk, P = t.injectRescueCapital;
    }, function (t) {
      M = t.settleOffline;
    }, function (t) {
      _ = t.assetsLeaderboard, F = t.yearsLeaderboard;
    }],
    execute: function execute() {
      function j(t) {
        var e = t instanceof i ? t.code : t instanceof Error && t.message in B ? t.message : n.NOT_READY;
        return s(e, u(e));
      }
      r._RF.push({}, "e1910i2LAlL0qG+YY+WCGlg", "GameFacade", void 0);
      var B = Object.fromEntries(Object.values(n).map(function (t) {
        return [t, !0];
      }));
      t("GameFacade", function () {
        function t(t, e, r) {
          var n = this;
          this.store = void 0, this.platform = void 0, this.cfg = void 0, this.clock = new g(), this.platform = t, this.store = e, this.cfg = r, this.clock.beforeMonthSettle = function (t) {
            var e = G(t, n.cfg);
            O(t, e);
          }, this.clock.afterMonthSettle = function (t) {
            return "DISTRESS" !== N(t, n.cfg);
          };
        }
        t.bootstrap = function () {
          var r = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee37(e, r) {
            var n;
            return _regeneratorRuntime().wrap(function _callee37$(_context38) {
              while (1) switch (_context38.prev = _context38.next) {
                case 0:
                  _context38.next = 2;
                  return c.load(e);
                case 2:
                  n = _context38.sent;
                  return _context38.abrupt("return", new t(e, null != n ? n : new c(e, y(Date.now())), r));
                case 4:
                case "end":
                  return _context38.stop();
              }
            }, _callee37);
          }));
          return function (t, e) {
            return r.apply(this, arguments);
          };
        }(), t.fromStorage = function () {
          var r = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee38(e, r) {
            return _regeneratorRuntime().wrap(function _callee38$(_context39) {
              while (1) switch (_context39.prev = _context39.next) {
                case 0:
                  return _context39.abrupt("return", t.bootstrap(e, r));
                case 1:
                case "end":
                  return _context39.stop();
              }
            }, _callee38);
          }));
          return function (t, e) {
            return r.apply(this, arguments);
          };
        }();
        var r = t.prototype;
        return r.getState = function () {
          return this.store.current;
        }, r.getRevision = function () {
          return this.store.currentRevision;
        }, r.rollCompanyNames = function (t, e) {
          void 0 === e && (e = 3);
          var r = this.store.current,
            n = new R(I(r.seed, "companyName", r.rngCounter));
          return new m(n.derive("names:" + r.rngCounter)).rollCompanyNames(t, e);
        }, r.createCompany = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee39(t, e) {
            var r, n, u;
            return _regeneratorRuntime().wrap(function _callee39$(_context40) {
              while (1) switch (_context40.prev = _context40.next) {
                case 0:
                  _context40.prev = 0;
                  _context40.next = 3;
                  return this.store.mutate(function (r) {
                    return a(r, t, e);
                  }, e.expectedRunId);
                case 3:
                  r = _context40.sent;
                  n = r.result;
                  u = r.revision;
                  return _context40.abrupt("return", o(this.store.current.runId, u, {
                    companyId: n.companyId,
                    cashYuan: n.cashYuan
                  }));
                case 9:
                  _context40.prev = 9;
                  _context40.t0 = _context40["catch"](0);
                  return _context40.abrupt("return", j(_context40.t0));
                case 12:
                case "end":
                  return _context40.stop();
              }
            }, _callee39, this, [[0, 9]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.getOffer = function (t) {
          return this.store.read(function (e) {
            return f(e, t);
          });
        }, r.refreshOffer = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee40(t, e) {
            var r, n, u;
            return _regeneratorRuntime().wrap(function _callee40$(_context41) {
              while (1) switch (_context41.prev = _context41.next) {
                case 0:
                  _context41.prev = 0;
                  _context41.next = 3;
                  return this.store.mutate(function (e) {
                    return h(e, t);
                  }, e.expectedRunId);
                case 3:
                  r = _context41.sent;
                  n = r.result;
                  u = r.revision;
                  return _context41.abrupt("return", o(this.store.current.runId, u, n));
                case 9:
                  _context41.prev = 9;
                  _context41.t0 = _context41["catch"](0);
                  return _context41.abrupt("return", j(_context41.t0));
                case 12:
                case "end":
                  return _context41.stop();
              }
            }, _callee40, this, [[0, 9]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.hireEmployee = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee41(t, e) {
            var r, n, u, i;
            return _regeneratorRuntime().wrap(function _callee41$(_context42) {
              while (1) switch (_context42.prev = _context42.next) {
                case 0:
                  r = this;
                  _context42.prev = 1;
                  _context42.next = 4;
                  return this.store.mutate(function (n) {
                    return d(n, r.cfg, t, e);
                  }, e.expectedRunId);
                case 4:
                  n = _context42.sent;
                  u = n.result;
                  i = n.revision;
                  return _context42.abrupt("return", o(this.store.current.runId, i, {
                    employee: u.employee,
                    feePaidYuan: u.feePaidYuan,
                    cashAfterYuan: u.cashAfterYuan
                  }));
                case 10:
                  _context42.prev = 10;
                  _context42.t0 = _context42["catch"](1);
                  return _context42.abrupt("return", j(_context42.t0));
                case 13:
                case "end":
                  return _context42.stop();
              }
            }, _callee41, this, [[1, 10]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.startOperating = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee42(t) {
            var e;
            return _regeneratorRuntime().wrap(function _callee42$(_context43) {
              while (1) switch (_context43.prev = _context43.next) {
                case 0:
                  _context43.prev = 0;
                  _context43.next = 3;
                  return this.store.mutate(function (e) {
                    return l(e, t);
                  }, t.expectedRunId);
                case 3:
                  e = _context43.sent.revision;
                  return _context43.abrupt("return", o(this.store.current.runId, e, !0));
                case 7:
                  _context43.prev = 7;
                  _context43.t0 = _context43["catch"](0);
                  return _context43.abrupt("return", j(_context43.t0));
                case 10:
                case "end":
                  return _context43.stop();
              }
            }, _callee42, this, [[0, 7]]);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), r.beginCloseCompany = function (t) {
          return void 0 === t && (t = Date.now()), this.store.read(function (e) {
            return v(e, t);
          });
        }, r.confirmCloseCompany = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee43(t, e) {
            var r, n, u, i;
            return _regeneratorRuntime().wrap(function _callee43$(_context44) {
              while (1) switch (_context44.prev = _context44.next) {
                case 0:
                  void 0 === e && (e = Date.now());
                  _context44.prev = 1;
                  r = this.store.current, n = p(r, t, e), u = n.oldRunId, i = n.newState;
                  _context44.next = 5;
                  return this.store.replaceWithNewRun(i, u, e);
                case 5:
                  return _context44.abrupt("return", o(i.runId, this.store.currentRevision, {
                    newRunId: i.runId
                  }));
                case 8:
                  _context44.prev = 8;
                  _context44.t0 = _context44["catch"](1);
                  return _context44.abrupt("return", j(_context44.t0));
                case 11:
                case "end":
                  return _context44.stop();
              }
            }, _callee43, this, [[1, 8]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.getEnvironment = function () {
          return this.platform.getEnvironment();
        }, r.setSpeed = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee44(t, e) {
            var r;
            return _regeneratorRuntime().wrap(function _callee44$(_context45) {
              while (1) switch (_context45.prev = _context45.next) {
                case 0:
                  r = this;
                  _context45.prev = 1;
                  _context45.next = 4;
                  return this.store.mutate(function (e) {
                    return r.clock.setSpeed(e, t), {
                      revision: 0
                    };
                  }, e.expectedRunId);
                case 4:
                  return _context45.abrupt("return", o(this.store.current.runId, this.store.currentRevision, !0));
                case 7:
                  _context45.prev = 7;
                  _context45.t0 = _context45["catch"](1);
                  return _context45.abrupt("return", j(_context45.t0));
                case 10:
                case "end":
                  return _context45.stop();
              }
            }, _callee44, this, [[1, 7]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.advanceRealTime = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee45(t, e) {
            var r, n;
            return _regeneratorRuntime().wrap(function _callee45$(_context46) {
              while (1) switch (_context46.prev = _context46.next) {
                case 0:
                  r = this;
                  _context46.prev = 1;
                  _context46.next = 4;
                  return this.store.mutate(function (e) {
                    return r.clock.tick(e, r.cfg, t);
                  }, e);
                case 4:
                  n = _context46.sent;
                  return _context46.abrupt("return", o(this.store.current.runId, this.store.currentRevision, n.result));
                case 8:
                  _context46.prev = 8;
                  _context46.t0 = _context46["catch"](1);
                  return _context46.abrupt("return", j(_context46.t0));
                case 11:
                case "end":
                  return _context46.stop();
              }
            }, _callee45, this, [[1, 8]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.previewInvest = function (t) {
          try {
            return o(this.store.current.runId, this.store.currentRevision, S(this.store.current, this.cfg, t));
          } catch (t) {
            return j(t);
          }
        }, r.invest = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee46(t, e) {
            var r, n;
            return _regeneratorRuntime().wrap(function _callee46$(_context47) {
              while (1) switch (_context47.prev = _context47.next) {
                case 0:
                  r = this;
                  _context47.prev = 1;
                  _context47.next = 4;
                  return this.store.mutate(function (e) {
                    return C(e, r.cfg, t);
                  }, e.expectedRunId);
                case 4:
                  n = _context47.sent.result;
                  return _context47.abrupt("return", o(this.store.current.runId, this.store.currentRevision, n));
                case 8:
                  _context47.prev = 8;
                  _context47.t0 = _context47["catch"](1);
                  return _context47.abrupt("return", j(_context47.t0));
                case 11:
                case "end":
                  return _context47.stop();
              }
            }, _callee46, this, [[1, 8]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.getAnnualReport = function (t) {
          return this.store.read(function (e) {
            var r;
            return null != (r = e.annualReports.find(function (e) {
              return e.year === t;
            })) ? r : null;
          });
        }, r.getYearLedgers = function (t) {
          var e = this.store.current.runId;
          return this.store.read(function (r) {
            return r.monthlyLedgersRolling.filter(function (r) {
              return r.runId === e && r.year === t;
            });
          });
        }, r.previewCreateDepartment = function (t) {
          var e = this;
          return this.store.read(function (r) {
            return Y(r, e.cfg, t);
          });
        }, r.createDepartment = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee47(t, e) {
            var r, n;
            return _regeneratorRuntime().wrap(function _callee47$(_context48) {
              while (1) switch (_context48.prev = _context48.next) {
                case 0:
                  r = this;
                  _context48.prev = 1;
                  _context48.next = 4;
                  return this.store.mutate(function (n) {
                    return w(n, r.cfg, t, e);
                  }, e.expectedRunId);
                case 4:
                  n = _context48.sent.result;
                  return _context48.abrupt("return", o(this.store.current.runId, this.store.currentRevision, {
                    department: n.department,
                    feePaidYuan: n.feePaidYuan,
                    cashAfterYuan: n.cashAfterYuan
                  }));
                case 8:
                  _context48.prev = 8;
                  _context48.t0 = _context48["catch"](1);
                  return _context48.abrupt("return", j(_context48.t0));
                case 11:
                case "end":
                  return _context48.stop();
              }
            }, _callee47, this, [[1, 8]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.setStaffingMode = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee48(t, e, r) {
            return _regeneratorRuntime().wrap(function _callee48$(_context49) {
              while (1) switch (_context49.prev = _context49.next) {
                case 0:
                  _context49.prev = 0;
                  _context49.next = 3;
                  return this.store.mutate(function (n) {
                    return L(n, t, e, r), {
                      revision: 0
                    };
                  }, r.expectedRunId);
                case 3:
                  return _context49.abrupt("return", o(this.store.current.runId, this.store.currentRevision, !0));
                case 6:
                  _context49.prev = 6;
                  _context49.t0 = _context49["catch"](0);
                  return _context49.abrupt("return", j(_context49.t0));
                case 9:
                case "end":
                  return _context49.stop();
              }
            }, _callee48, this, [[0, 6]]);
          }));
          return function (e, r, n) {
            return t.apply(this, arguments);
          };
        }(), r.setTargetCount = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee49(t, e, r) {
            return _regeneratorRuntime().wrap(function _callee49$(_context50) {
              while (1) switch (_context50.prev = _context50.next) {
                case 0:
                  _context50.prev = 0;
                  _context50.next = 3;
                  return this.store.mutate(function (n) {
                    return A(n, t, e, r), {
                      revision: 0
                    };
                  }, r.expectedRunId);
                case 3:
                  return _context50.abrupt("return", o(this.store.current.runId, this.store.currentRevision, !0));
                case 6:
                  _context50.prev = 6;
                  _context50.t0 = _context50["catch"](0);
                  return _context50.abrupt("return", j(_context50.t0));
                case 9:
                case "end":
                  return _context50.stop();
              }
            }, _callee49, this, [[0, 6]]);
          }));
          return function (e, r, n) {
            return t.apply(this, arguments);
          };
        }(), r.setPolicy = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee50(t, e) {
            return _regeneratorRuntime().wrap(function _callee50$(_context51) {
              while (1) switch (_context51.prev = _context51.next) {
                case 0:
                  if (!("STEADY" !== t && "GROWTH" !== t && "PROFIT" !== t)) {
                    _context51.next = 2;
                    break;
                  }
                  return _context51.abrupt("return", s(n.INVALID_POLICY, u(n.INVALID_POLICY)));
                case 2:
                  _context51.prev = 2;
                  _context51.next = 5;
                  return this.store.mutate(function (e) {
                    return e.policy = t, {
                      revision: 0
                    };
                  }, e.expectedRunId);
                case 5:
                  return _context51.abrupt("return", o(this.store.current.runId, this.store.currentRevision, !0));
                case 8:
                  _context51.prev = 8;
                  _context51.t0 = _context51["catch"](2);
                  return _context51.abrupt("return", j(_context51.t0));
                case 11:
                case "end":
                  return _context51.stop();
              }
            }, _callee50, this, [[2, 8]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.getAutomationLogs = function (t) {
          return void 0 === t && (t = 20), this.store.read(function (e) {
            return e.automationLogs.slice(-t).reverse();
          });
        }, r.previewLayoff = function (t, e) {
          return void 0 === e && (e = Date.now()), this.store.read(function (r) {
            return D(r, t, e);
          });
        }, r.createLayoffToken = function (t, e) {
          return void 0 === e && (e = Date.now()), E(t, e);
        }, r.confirmLayoff = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee51(t, e, r) {
            var n, u;
            return _regeneratorRuntime().wrap(function _callee51$(_context52) {
              while (1) switch (_context52.prev = _context52.next) {
                case 0:
                  n = this;
                  void 0 === r && (r = Date.now());
                  _context52.prev = 2;
                  _context52.next = 5;
                  return this.store.mutate(function (u) {
                    return k(u, n.cfg, t, e, r);
                  }, e.expectedRunId);
                case 5:
                  u = _context52.sent.result;
                  return _context52.abrupt("return", o(this.store.current.runId, this.store.currentRevision, {
                    employee: u.employee,
                    severancePaidYuan: u.severancePaidYuan,
                    cashAfterYuan: u.cashAfterYuan
                  }));
                case 9:
                  _context52.prev = 9;
                  _context52.t0 = _context52["catch"](2);
                  return _context52.abrupt("return", j(_context52.t0));
                case 12:
                case "end":
                  return _context52.stop();
              }
            }, _callee51, this, [[2, 9]]);
          }));
          return function (e, r, n) {
            return t.apply(this, arguments);
          };
        }(), r.previewTransfer = function (t, e) {
          return this.store.read(function (r) {
            return x(r, t, e);
          });
        }, r.transferEmployee = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee52(t, e, r) {
            return _regeneratorRuntime().wrap(function _callee52$(_context53) {
              while (1) switch (_context53.prev = _context53.next) {
                case 0:
                  _context53.prev = 0;
                  _context53.next = 3;
                  return this.store.mutate(function (n) {
                    return T(n, t, e, r), {
                      revision: 0
                    };
                  }, r.expectedRunId);
                case 3:
                  return _context53.abrupt("return", o(this.store.current.runId, this.store.currentRevision, !0));
                case 6:
                  _context53.prev = 6;
                  _context53.t0 = _context53["catch"](0);
                  return _context53.abrupt("return", j(_context53.t0));
                case 9:
                case "end":
                  return _context53.stop();
              }
            }, _callee52, this, [[0, 6]]);
          }));
          return function (e, r, n) {
            return t.apply(this, arguments);
          };
        }(), r.assessRisk = function () {
          var t = this;
          return this.store.read(function (e) {
            return b(e, t.cfg);
          });
        }, r.assetsLeaderboard = function () {
          var t = this;
          return this.store.read(function (e) {
            return _(e, t.cfg);
          });
        }, r.yearsLeaderboard = function () {
          var t = this;
          return this.store.read(function (e) {
            return F(e, t.cfg);
          });
        }, r.injectRescueCapital = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee53(t) {
            var e, r;
            return _regeneratorRuntime().wrap(function _callee53$(_context54) {
              while (1) switch (_context54.prev = _context54.next) {
                case 0:
                  e = this;
                  _context54.prev = 1;
                  _context54.next = 4;
                  return this.store.mutate(function (r) {
                    return P(r, e.cfg, t);
                  }, t.expectedRunId);
                case 4:
                  r = _context54.sent.result;
                  if (!r.granted) {
                    _context54.next = 13;
                    break;
                  }
                  _context54.t1 = "DISTRESS" === this.store.current.phase;
                  if (!_context54.t1) {
                    _context54.next = 10;
                    break;
                  }
                  _context54.next = 10;
                  return this.store.mutate(function (t) {
                    return t.phase = "RUNNING", {
                      revision: 0
                    };
                  }, t.expectedRunId);
                case 10:
                  _context54.t0 = o(this.store.current.runId, this.store.currentRevision, {
                    amountYuan: r.amountYuan,
                    cashAfterYuan: r.cashAfterYuan
                  });
                  _context54.next = 14;
                  break;
                case 13:
                  _context54.t0 = s(n.ALREADY_USED, u(n.ALREADY_USED));
                case 14:
                  return _context54.abrupt("return", _context54.t0);
                case 17:
                  _context54.prev = 17;
                  _context54.t2 = _context54["catch"](1);
                  return _context54.abrupt("return", j(_context54.t2));
                case 20:
                case "end":
                  return _context54.stop();
              }
            }, _callee53, this, [[1, 17]]);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), r.settleOffline = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee54(t) {
            var e, r, n, u, i, s;
            return _regeneratorRuntime().wrap(function _callee54$(_context55) {
              while (1) switch (_context55.prev = _context55.next) {
                case 0:
                  e = this, r = this.store.current.runId;
                  _context55.prev = 1;
                  _context55.next = 4;
                  return this.store.mutate(function (r) {
                    return M({
                      state: r,
                      cfg: e.cfg,
                      nowMs: t
                    });
                  }, r);
                case 4:
                  i = _context55.sent;
                  s = i.result;
                  return _context55.abrupt("return", o(this.store.current.runId, i.revision, {
                    monthsSettled: s.monthsSettled,
                    yearsClosed: s.yearsClosed,
                    interrupted: s.interrupted,
                    cashBefore: s.cashBefore,
                    cashAfter: null != (n = null == (u = this.store.current.company) ? void 0 : u.cashYuan) ? n : s.cashBefore,
                    newRemainderMs: s.newRemainderMs
                  }));
                case 9:
                  _context55.prev = 9;
                  _context55.t0 = _context55["catch"](1);
                  return _context55.abrupt("return", j(_context55.t0));
                case 12:
                case "end":
                  return _context55.stop();
              }
            }, _callee54, this, [[1, 9]]);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), t;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/gameStateFactory.ts", ["cc", "./rng.ts", "./ids.ts"], function (e) {
  var t, n, a;
  return {
    setters: [function (e) {
      t = e.cclegacy;
    }, function (e) {
      n = e.randomSeed;
    }, function (e) {
      a = e.newRunId;
    }],
    execute: function execute() {
      function s(e, t) {
        var s = null != t ? t : n();
        return {
          phase: "CREATING",
          runId: a(s, e),
          seed: s,
          rngCounter: 0,
          initializedCapital: !1,
          gameYear: 1,
          gameMonth: 1,
          progressMsInMonth: 0,
          speed: 0,
          lastWallClockMs: e,
          lastSettledMonthKey: null,
          offlineRemainderMs: 0,
          onboarding: {
            stepId: "TUT-01",
            completedSteps: [],
            skipped: !1,
            lastKnownStep: "TUT-01",
            tutorialVersion: 1,
            initialHiresCompleted: 0
          },
          company: null,
          ceo: null,
          employees: [],
          departments: [],
          offers: [],
          policy: "STEADY",
          monthlyLedgersRolling: [],
          annualReports: [],
          pendingEntries: [],
          eventHistory: [],
          annualEvents: [],
          botCompanies: [],
          consecutiveProfitableYears: 0,
          target3YearsAchieved: !1,
          rescueCapitalUsed: !1,
          cashRisk: "NORMAL",
          autoHireCountByYear: {},
          automationLogs: [],
          yearOpenCashYuan: {},
          executedCommandIds: []
        };
      }
      e({
        createFreshRunState: function createFreshRunState(e) {
          return s(e);
        },
        createInitialState: s
      }), t._RF.push({}, "3c833yzLSpPOqy/7cZTg+a2", "gameStateFactory", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/GameStore.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./errors.ts", "./SaveRepository.ts", "./gameStateFactory.ts"], function (t) {
  var e, r, n, i, s, o;
  return {
    setters: [function (t) {
      e = t.createClass, r = t.asyncToGenerator;
    }, function (t) {
      n = t.cclegacy;
    }, function (t) {
      i = t.GameErrorCode;
    }, function (t) {
      s = t.SaveRepository;
    }, function (t) {
      o = t.createInitialState;
    }],
    execute: function execute() {
      n._RF.push({}, "5aabc3EldJFVqbyuwjLlEZa", "GameStore", void 0);
      t("GameStore", function () {
        function t(t, e, r) {
          this.state = void 0, this.revision = 0, this.resetGeneration = 0, this.repo = void 0, this.mutationInProgress = !1, this.repo = new s(t), this.state = null != e ? e : o(Date.now()), r && (this.revision = r.revision, this.resetGeneration = r.resetGeneration);
        }
        var n = t.prototype;
        return n.repository = function () {
          return this.repo;
        }, n.mutate = function () {
          var t = r( /*#__PURE__*/_regeneratorRuntime().mark(function _callee55(t, e) {
            var r, n;
            return _regeneratorRuntime().wrap(function _callee55$(_context56) {
              while (1) switch (_context56.prev = _context56.next) {
                case 0:
                  if (!this.mutationInProgress) {
                    _context56.next = 2;
                    break;
                  }
                  throw new Error(i.RESET_IN_PROGRESS);
                case 2:
                  if (!(this.state.runId !== e)) {
                    _context56.next = 4;
                    break;
                  }
                  throw new Error(i.RUN_CHANGED);
                case 4:
                  this.mutationInProgress = !0;
                  r = structuredClone(this.state);
                  _context56.prev = 6;
                  n = t(this.state);
                  if (!(this.state.runId !== e)) {
                    _context56.next = 10;
                    break;
                  }
                  throw this.state = r, new Error(i.RUN_CHANGED);
                case 10:
                  _context56.next = 12;
                  return this.persist();
                case 12:
                  return _context56.abrupt("return", {
                    result: n,
                    revision: this.revision
                  });
                case 15:
                  _context56.prev = 15;
                  _context56.t0 = _context56["catch"](6);
                  throw this.state = r, _context56.t0;
                case 18:
                  _context56.prev = 18;
                  this.mutationInProgress = !1;
                  return _context56.finish(18);
                case 21:
                case "end":
                  return _context56.stop();
              }
            }, _callee55, this, [[6, 15, 18, 21]]);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), n.read = function (t) {
          return t(this.state);
        }, n.persist = function () {
          var t = r( /*#__PURE__*/_regeneratorRuntime().mark(function _callee56() {
            return _regeneratorRuntime().wrap(function _callee56$(_context57) {
              while (1) switch (_context57.prev = _context57.next) {
                case 0:
                  this.revision += 1;
                  _context57.prev = 1;
                  _context57.next = 4;
                  return this.repo.commit(this.state, {
                    revision: this.revision,
                    resetGeneration: this.resetGeneration
                  });
                case 4:
                  _context57.next = 9;
                  break;
                case 6:
                  _context57.prev = 6;
                  _context57.t0 = _context57["catch"](1);
                  throw this.revision -= 1, _context57.t0;
                case 9:
                case "end":
                  return _context57.stop();
              }
            }, _callee56, this, [[1, 6]]);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), n.replaceWithNewRun = function () {
          var t = r( /*#__PURE__*/_regeneratorRuntime().mark(function _callee57(t, e, r) {
            return _regeneratorRuntime().wrap(function _callee57$(_context58) {
              while (1) switch (_context58.prev = _context58.next) {
                case 0:
                  if (!this.mutationInProgress) {
                    _context58.next = 2;
                    break;
                  }
                  throw new Error(i.RESET_IN_PROGRESS);
                case 2:
                  this.mutationInProgress = !0;
                  _context58.prev = 3;
                  this.resetGeneration += 1;
                  _context58.next = 7;
                  return this.repo.writeTombstone({
                    oldRunId: e,
                    newResetGeneration: this.resetGeneration,
                    resetAtMs: r
                  });
                case 7:
                  this.state = t;
                  this.revision = 0;
                  _context58.next = 11;
                  return this.repo.commit(t, {
                    revision: 1,
                    resetGeneration: this.resetGeneration
                  });
                case 11:
                  this.revision = 1;
                  _context58.next = 14;
                  return this.repo.clearRunSlots(e);
                case 14:
                  _context58.prev = 14;
                  this.mutationInProgress = !1;
                  return _context58.finish(14);
                case 17:
                case "end":
                  return _context58.stop();
              }
            }, _callee57, this, [[3,, 14, 17]]);
          }));
          return function (e, r, n) {
            return t.apply(this, arguments);
          };
        }(), t.load = function () {
          var e = r( /*#__PURE__*/_regeneratorRuntime().mark(function _callee58(e) {
            var r, n, i;
            return _regeneratorRuntime().wrap(function _callee58$(_context59) {
              while (1) switch (_context59.prev = _context59.next) {
                case 0:
                  n = new s(e);
                  _context59.next = 3;
                  return n.load();
                case 3:
                  i = _context59.sent;
                  return _context59.abrupt("return", i ? new t(e, i.state, {
                    revision: i.envelope.revision,
                    resetGeneration: null != (r = i.envelope.resetGeneration) ? r : 0
                  }) : null);
                case 5:
                case "end":
                  return _context59.stop();
              }
            }, _callee58);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), e(t, [{
          key: "current",
          get: function get() {
            return this.state;
          }
        }, {
          key: "currentRevision",
          get: function get() {
            return this.revision;
          }
        }, {
          key: "currentResetGeneration",
          get: function get() {
            return this.resetGeneration;
          }
        }]), t;
      }());
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/ids.ts", ["cc", "./rng.ts"], function (n) {
  var t, e;
  return {
    setters: [function (n) {
      t = n.cclegacy;
    }, function (n) {
      e = n.deriveSeed;
    }],
    execute: function execute() {
      n({
        newId: function newId(n, t, r) {
          return n + "_" + e(t, r).toString(36) + u(16777215 & r);
        },
        newRunId: function newRunId(n, t) {
          return "run_" + e(n, t).toString(36) + u(4294967295 & r++);
        },
        resetNonceForTest: function resetNonceForTest(n) {
          void 0 === n && (n = 0);
          r = n;
        },
        uniqueToken: function uniqueToken(n) {
          return r += 1, n + "_" + Date.now().toString(36) + u(16777215 & r);
        }
      }), t._RF.push({}, "83730SHuIZF6JNG2geeMuQs", "ids", void 0);
      var r = 0;
      function u(n) {
        return n.toString(36).padStart(6, "0");
      }
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/InvestmentService.ts", ["cc", "./errors.ts", "./capacity.ts"], function (s) {
  var e, n, t;
  return {
    setters: [function (s) {
      e = s.cclegacy;
    }, function (s) {
      n = s.GameErrorCode;
    }, function (s) {
      t = s.businessAssetCoeffBps;
    }],
    execute: function execute() {
      function a(s, e, t) {
        var a = s.company;
        if (!a) throw new Error(n.NOT_READY);
        if ("RUNNING" !== s.phase && "DISTRESS" !== s.phase) throw new Error(n.NOT_READY);
        var u = e.productivity.businessAssetInvestStepYuan;
        if (!Number.isInteger(t) || t <= 0 || t % u != 0) throw new Error(n.INVALID_AMOUNT);
        if (t > a.cashYuan) throw new Error(n.INSUFFICIENT_CASH);
      }
      s({
        depreciateBusinessAssets: function depreciateBusinessAssets(s, e) {
          var n = s.company;
          if (!n) return 0;
          var t = e.productivity.annualDepreciationBpsFromNextYear / 1e4,
            a = Math.round(n.businessAssetBookYuan * t);
          return a <= 0 ? 0 : (n.businessAssetBookYuan -= a, n.businessCapacityInvestmentYuan = Math.max(0, n.businessCapacityInvestmentYuan - a), a);
        },
        investInBusiness: function investInBusiness(s, e, n) {
          a(s, e, n);
          var u = s.company,
            i = t(e, u.businessCapacityInvestmentYuan);
          u.cashYuan -= n, u.businessAssetBookYuan += n, u.businessCapacityInvestmentYuan += n;
          var r = t(e, u.businessCapacityInvestmentYuan);
          return {
            amount: n,
            cashAfter: u.cashYuan,
            assetBookAfter: u.businessAssetBookYuan,
            capacityCoeffBeforeBps: i,
            capacityCoeffAfterBps: r,
            valid: !0
          };
        },
        previewInvest: function previewInvest(s, e, n) {
          var a,
            u,
            i,
            r,
            o = s.company,
            c = t(e, null != (a = null == o ? void 0 : o.businessCapacityInvestmentYuan) ? a : 0),
            v = t(e, (null != (u = null == o ? void 0 : o.businessCapacityInvestmentYuan) ? u : 0) + n);
          return {
            amount: n,
            cashAfter: (null != (i = null == o ? void 0 : o.cashYuan) ? i : 0) - n,
            assetBookAfter: (null != (r = null == o ? void 0 : o.businessAssetBookYuan) ? r : 0) + n,
            capacityCoeffBeforeBps: c,
            capacityCoeffAfterBps: v,
            valid: !0
          };
        },
        validateInvestAmount: a
      }), e._RF.push({}, "21060VX7eRJIpSnYLJEN9Vg", "InvestmentService", void 0), e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/ITapPlatform.ts", ["cc"], function () {
  var t;
  return {
    setters: [function (c) {
      t = c.cclegacy;
    }],
    execute: function execute() {
      t._RF.push({}, "f13aauAGddOxYP4VVXrn42l", "ITapPlatform", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/LayoffService.ts", ["cc", "./errors.ts", "./MutationContext.ts", "./monthEntry.ts"], function (e) {
  var n, r, a, t, o, u, s;
  return {
    setters: [function (e) {
      n = e.cclegacy;
    }, function (e) {
      r = e.GameErrorCode;
    }, function (e) {
      a = e.ensureRunId, t = e.hasCommand, o = e.recordCommand;
    }, function (e) {
      u = e.monthIndexOf, s = e.addPendingEntry;
    }],
    execute: function execute() {
      e({
        confirmLayoff: function confirmLayoff(e, n, d, f, m) {
          if (a(e, f.expectedRunId), !e.company) throw new Error(r.NOT_READY);
          if (m > d.expiresAtMs) throw new Error(r.CONFIRMATION_EXPIRED);
          if (t(e, f.commandId)) {
            var h = e.employees.find(function (e) {
              return e.employeeId === d.employeeId;
            });
            if (h && "ACTIVE" !== h.status) {
              var y = e.pendingEntries.find(function (e) {
                return e.refId === f.commandId && "SEVERANCE" === e.category;
              });
              return {
                employee: h,
                severancePaidYuan: y ? Math.abs(y.amountYuan) : 0,
                cashAfterYuan: e.company.cashYuan
              };
            }
          }
          var I = c(e, d.employeeId),
            l = u(e),
            p = Math.max(0, l - I.hiredAtMonthIndex),
            E = Math.floor(p / 12),
            M = I.salaryMonthlyYuan * i(E);
          if (M !== d.severanceYuan) throw new Error(r.CONFIRMATION_EXPIRED);
          if (e.company.cashYuan < M) throw new Error(r.INSUFFICIENT_CASH);
          return e.company.cashYuan -= M, s(e, "SEVERANCE", -M, f.commandId), I.status = "PENDING_DISMISSAL", I.dismissedAtMonthIndex = l + 1, o(e, f.commandId), {
            employee: I,
            severancePaidYuan: M,
            cashAfterYuan: e.company.cashYuan
          };
        },
        createLayoffToken: function createLayoffToken(e, n) {
          return {
            employeeId: e.employeeId,
            severanceYuan: e.severanceYuan,
            expiresAtMs: n + 6e4,
            previewedAtMs: e.previewedAtMs
          };
        },
        effectiveDismissalMonthIndex: function effectiveDismissalMonthIndex(e, n) {
          return e.status, n + 1;
        },
        previewLayoff: function previewLayoff(e, n, r) {
          var a,
            t,
            o,
            s = c(e, n),
            d = u(e),
            f = Math.max(0, d - s.hiredAtMonthIndex),
            m = Math.floor(f / 12),
            h = i(m),
            y = s.salaryMonthlyYuan * h,
            I = e.departments.find(function (e) {
              return e.deptId === s.departmentId;
            });
          return {
            employeeId: s.employeeId,
            name: s.name,
            deptType: null != (a = null == I ? void 0 : I.type) ? a : "",
            salaryMonthlyYuan: s.salaryMonthlyYuan,
            tenureMonths: f,
            tenureYears: m,
            severanceMonths: h,
            severanceYuan: y,
            nextYearSalarySavingYuan: 12 * s.salaryMonthlyYuan,
            cashAfterYuan: (null != (t = null == (o = e.company) ? void 0 : o.cashYuan) ? t : 0) - y,
            previewedAtMs: r
          };
        },
        severanceMonthsFor: i
      }), n._RF.push({}, "56bcd/n9RJAmqK9ap/uN4c4", "LayoffService", void 0);
      function c(e, n) {
        var a = e.employees.find(function (e) {
          return e.employeeId === n;
        });
        if (!a) throw new Error(r.EMPLOYEE_NOT_FOUND);
        if ("ACTIVE" !== a.status) throw new Error(r.EMPLOYEE_NOT_DISMISSIBLE);
        return a;
      }
      function i(e) {
        return Math.min(3, Math.max(1, Math.ceil(e / 2)));
      }
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/leaderboard.ts", ["cc", "./rng.ts"], function (e) {
  var t, a, s;
  return {
    setters: [function (e) {
      t = e.cclegacy;
    }, function (e) {
      a = e.Rng, s = e.deriveSeed;
    }],
    execute: function execute() {
      function n(e) {
        for (var t = new a(s(e.localBots.sharedSeed, "bots-v1")), n = e.localBots.count, r = [], o = 0; o < n; o++) {
          var u = t.nextInt(e.localBots.initialAssetYuanMin, e.localBots.initialAssetYuanMax),
            i = t.nextInt(e.localBots.initialCompletedYearsMin, e.localBots.initialCompletedYearsMax),
            l = t.nextInt(e.localBots.baseAnnualAssetGrowthBpsMin, e.localBots.baseAnnualAssetGrowthBpsMax);
          r.push({
            botId: "bot_" + (o + 1),
            name: "模拟企业 " + String(o + 1).padStart(2, "0"),
            assetsYuan: u,
            yearsOperated: i,
            initialAssetsYuan: u,
            baseGrowthBps: l
          });
        }
        return r;
      }
      function r(e, t) {
        return e.botCompanies.length !== t.localBots.count && (e.botCompanies = n(t)), e.botCompanies;
      }
      function o(e) {
        return e.company ? e.company.cashYuan + e.company.businessAssetBookYuan : 0;
      }
      function u(e) {
        return e.annualReports.filter(function (e) {
          return e.settled;
        }).length;
      }
      function i(e, t) {
        var a = r(e, t).map(function (e) {
          return {
            id: e.botId,
            name: e.name,
            isPlayer: !1,
            assetsYuan: e.assetsYuan,
            yearsOperated: e.yearsOperated
          };
        });
        return e.company && a.push({
          id: "player",
          name: e.company.name,
          isPlayer: !0,
          assetsYuan: o(e),
          yearsOperated: u(e)
        }), a;
      }
      e({
        advanceBotsOneYear: function advanceBotsOneYear(e, t, n) {
          r(e, t).forEach(function (e, r) {
            var o = new a(s(t.localBots.sharedSeed, e.botId, n)).nextInt(t.localBots.yearJitterBpsMin, t.localBots.yearJitterBpsMax),
              u = e.baseGrowthBps + o,
              i = Math.round(e.assetsYuan * u / 1e4);
            e.assetsYuan = Math.max(0, e.assetsYuan + i), e.yearsOperated += 1;
          });
        },
        assetsLeaderboard: function assetsLeaderboard(e, t) {
          return i(e, t).sort(function (e, t) {
            return t.assetsYuan - e.assetsYuan;
          });
        },
        ensureBots: r,
        generateBots: n,
        playerAssets: o,
        playerYears: u,
        yearsLeaderboard: function yearsLeaderboard(e, t) {
          return i(e, t).sort(function (e, t) {
            return t.yearsOperated - e.yearsOperated || t.assetsYuan - e.assetsYuan;
          });
        }
      }), t._RF.push({}, "3c7299qD8lMs5d9+dqUgbz+", "leaderboard", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/loadConfig.ts", ["cc", "./configLoader.ts"], function (n) {
  var o, e, c, t, i;
  return {
    setters: [function (n) {
      o = n.cclegacy, e = n.resources, c = n.JsonAsset;
    }, function (n) {
      t = n.validateEconomyConfig, i = n.registerConfig;
    }],
    execute: function execute() {
      n("loadEconomyConfig", function () {
        return new Promise(function (n, o) {
          e.load("config/economy.v1", c, function (e, c) {
            if (e) o(e);else try {
              var r = t(c.json);
              n(i(r));
            } catch (n) {
              o(n);
            }
          });
        });
      }), o._RF.push({}, "2b6066XPgdBl5DybCJn701m", "loadConfig", void 0), o._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/loadRuntimeConfig.ts", ["cc", "./runtimeConfig.ts"], function (n) {
  var t, o, e, i;
  return {
    setters: [function (n) {
      t = n.cclegacy, o = n.resources, e = n.JsonAsset;
    }, function (n) {
      i = n.setRuntimeConfig;
    }],
    execute: function execute() {
      n("loadRuntimeConfig", function () {
        return new Promise(function (n) {
          o.load("config/runtime.config", e, function (t, o) {
            var e;
            n(i(t ? null : null != (e = o.json) ? e : null));
          });
        });
      }), t._RF.push({}, "644dcUe8lJEVoDNudtEX1xx", "loadRuntimeConfig", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/main", ["./AutoHireService.ts", "./CompanyService.ts", "./DepartmentService.ts", "./GameFacade.ts", "./GameStore.ts", "./InvestmentService.ts", "./LayoffService.ts", "./MutationContext.ts", "./OfferService.ts", "./RecruitmentService.ts", "./ResetService.ts", "./RiskService.ts", "./TransferService.ts", "./monthEntry.ts", "./validators.ts", "./EconomyConfig.ts", "./configLoader.ts", "./CandidateGenerator.ts", "./NameGenerator.ts", "./command.ts", "./companyNames.ts", "./errors.ts", "./gameStateFactory.ts", "./ids.ts", "./money.ts", "./peopleNames.ts", "./result.ts", "./types.ts", "./validation.ts", "./SaveCodec.ts", "./SaveMigration.ts", "./SaveRepository.ts", "./SaveTypes.ts", "./canonical.ts", "./crc32.ts", "./stateIntegrity.ts", "./statePrune.ts", "./AuthService.ts", "./EditorMockPlatform.ts", "./ITapPlatform.ts", "./MemoryStorage.ts", "./TapPlatform.ts", "./privacyConsent.ts", "./safeArea.ts", "./GameClock.ts", "./RandomStreams.ts", "./advanceMonth.ts", "./annual.ts", "./annualEvent.ts", "./capacity.ts", "./departments.ts", "./leaderboard.ts", "./market.ts", "./monthly.ts", "./offline.ts", "./rng.ts", "./Bootstrap.ts", "./AudioManager.ts", "./BootTrap.ts", "./CocosPlatform.ts", "./CocosStorageAdapter.ts", "./PlatformFactory.ts", "./SafeArea2.ts", "./loadConfig.ts", "./loadRuntimeConfig.ts", "./runtimeConfig.ts", "./AppView.ts", "./UiFactory.ts", "./theme.ts"], function () {
  return {
    setters: [null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null],
    execute: function execute() {}
  };
});
System.register("chunks:///_virtual/market.ts", ["cc", "./money.ts"], function (n) {
  var t, a, e;
  return {
    setters: [function (n) {
      t = n.cclegacy;
    }, function (n) {
      a = n.clampMoney, e = n.roundHalfUp;
    }],
    execute: function execute() {
      function r(n, t, e) {
        var r = n.industry[t].firstYearDemandYuan,
          u = n.demand.naturalAnnualGrowthBps / 1e4,
          o = e <= 1 ? r : a(Math.round(r * Math.pow(1 + u, e - 1)));
        return {
          year: e,
          annualDemandYuan: o,
          demandIndexBps: Math.round(o / r * 1e4)
        };
      }
      n({
        annualDemand: r,
        distributeMonthly: function distributeMonthly(n) {
          var t = Math.trunc(n / 12),
            a = new Array(12).fill(t),
            e = 12 * t;
          return a[11] = n - e + t, a;
        },
        monthlyPotentialOrder: function monthlyPotentialOrder(n, t, a, u, o, c) {
          void 0 === c && (c = 0);
          var d = r(n, t, a).annualDemandYuan,
            i = e(d * o * (1e4 + c) / Math.pow(1e4, 2)),
            l = Math.trunc(i / 12);
          return 12 === u ? i - 11 * l : l;
        }
      }), t._RF.push({}, "761b8u9t7tJxKnBnUVqBIOP", "market", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/MemoryStorage.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (t) {
  var e, r;
  return {
    setters: [function (t) {
      e = t.asyncToGenerator;
    }, function (t) {
      r = t.cclegacy;
    }],
    execute: function execute() {
      r._RF.push({}, "005e1vIay9EWJk9z8G4QfYv", "MemoryStorage", void 0);
      t("MemoryStorage", function () {
        function t() {
          this.data = new Map(), this.writes = [], this.failReadKeys = new Set(), this.failWriteKeys = new Set(), this.corruptKeys = new Set();
        }
        var r = t.prototype;
        return r.get = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee59(t) {
            var e;
            return _regeneratorRuntime().wrap(function _callee59$(_context60) {
              while (1) switch (_context60.prev = _context60.next) {
                case 0:
                  if (!this.failReadKeys.has(t)) {
                    _context60.next = 2;
                    break;
                  }
                  throw new Error("simulated read failure: " + t);
                case 2:
                  if (this.data.has(t)) {
                    _context60.next = 4;
                    break;
                  }
                  return _context60.abrupt("return", null);
                case 4:
                  e = this.data.get(t);
                  return _context60.abrupt("return", this.corruptKeys.has(t) ? "{__corrupt__" : e);
                case 6:
                case "end":
                  return _context60.stop();
              }
            }, _callee59, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), r.set = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee60(t, e) {
            return _regeneratorRuntime().wrap(function _callee60$(_context61) {
              while (1) switch (_context61.prev = _context61.next) {
                case 0:
                  if (!this.failWriteKeys.has(t)) {
                    _context61.next = 2;
                    break;
                  }
                  throw new Error("simulated write failure: " + t);
                case 2:
                  this.data.set(t, structuredClone(e)), this.writes.push({
                    key: t,
                    size: JSON.stringify(e).length
                  });
                case 3:
                case "end":
                  return _context61.stop();
              }
            }, _callee60, this);
          }));
          return function (e, r) {
            return t.apply(this, arguments);
          };
        }(), r.remove = function () {
          var t = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee61(t) {
            return _regeneratorRuntime().wrap(function _callee61$(_context62) {
              while (1) switch (_context62.prev = _context62.next) {
                case 0:
                  this.data["delete"](t);
                case 1:
                case "end":
                  return _context62.stop();
              }
            }, _callee61, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), r.peekRaw = function (t) {
          return this.data.has(t) ? this.data.get(t) : null;
        }, r.overwriteRaw = function (t, e) {
          this.data.set(t, e);
        }, t;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/money.ts", ["cc"], function (n) {
  var e;
  return {
    setters: [function (n) {
      e = n.cclegacy;
    }],
    execute: function execute() {
      n({
        applyBps: function applyBps(n, e) {
          if (!Number.isFinite(n) || !Number.isFinite(e)) throw new Error("non-finite bps calc: " + n + ", " + e);
          var r = n < 0 ? -1 : 1,
            o = Math.abs(n) * Math.abs(e);
          return r * i(o / t);
        },
        assertSafeMoney: function assertSafeMoney(n, e) {
          void 0 === e && (e = "money");
          if (!o(n)) throw new Error("invalid " + e + ": " + n);
          return n;
        },
        clampMoney: function clampMoney(n) {
          var e = Math.trunc(n);
          return e > r ? r : e < -r ? -r : e;
        },
        formatWan: function formatWan(n) {
          return (n / 1e4).toFixed(2);
        },
        isSafeMoney: o,
        roundHalfUp: function roundHalfUp(n) {
          return (n < 0 ? -1 : 1) * i(Math.abs(n));
        }
      }), e._RF.push({}, "70e9fiEUF9GgobMD4LbdEVx", "money", void 0);
      var r = n("MAX_MONEY_YUAN", 1e11),
        t = n("BPS_DENOMINATOR", 1e4);
      function o(n) {
        return "number" == typeof n && Number.isSafeInteger(n) && Math.abs(n) <= r;
      }
      function i(n) {
        return Math.floor(n + .5);
      }
      e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/monthEntry.ts", ["cc", "./ids.ts", "./departments.ts"], function (n) {
  var t, e, r;
  return {
    setters: [function (n) {
      t = n.cclegacy;
    }, function (n) {
      e = n.newId;
    }, function (t) {
      r = t.deptIdAtMonth, n("applyDueTransfers", t.applyDueTransfers);
    }],
    execute: function execute() {
      function u(n) {
        return n.runId + ":" + n.gameYear + ":" + n.gameMonth;
      }
      n({
        addPendingEntry: function addPendingEntry(n, t, r, o, a) {
          void 0 === a && (a = !0);
          var d = {
            entryId: e("je", n.runId + ":" + t + ":" + o, n.pendingEntries.length + 1),
            monthKey: u(n),
            category: t,
            amountYuan: r,
            isCash: !0,
            alreadyPaid: a,
            refId: o
          };
          return n.pendingEntries.push(d), d;
        },
        deptIdAtMonth: function deptIdAtMonth(n, t) {
          return r(n, t);
        },
        monthIndexOf: function monthIndexOf(n) {
          return 12 * (n.gameYear - 1) + (n.gameMonth - 1);
        }
      }), t._RF.push({}, "6b9d6oU6FBPZIVwLtdLlUAo", "monthEntry", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/monthly.ts", ["cc", "./money.ts", "./capacity.ts", "./market.ts", "./departments.ts"], function (t) {
  var e, n, r, a, u, s;
  return {
    setters: [function (t) {
      e = t.cclegacy;
    }, function (t) {
      n = t.roundHalfUp;
    }, function (t) {
      r = t.monthlyCapacity;
    }, function (t) {
      a = t.monthlyPotentialOrder;
    }, function (t) {
      u = t.computeSupportEffects, s = t.deptIdAtMonth;
    }],
    execute: function execute() {
      function i(t, e) {
        return t.pendingEntries.filter(function (t) {
          return t.monthKey === e;
        }).map(function (t) {
          return {
            category: t.category,
            amountAbs: Math.abs(t.amountYuan),
            alreadyPaid: t.alreadyPaid,
            isCash: t.isCash
          };
        });
      }
      function o(t, e) {
        return t.employees.filter(function (t) {
          return ("ACTIVE" === t.status || "PENDING_DISMISSAL" === t.status) && t.effectiveFromMonthIndex <= e && (null === t.dismissedAtMonthIndex || t.dismissedAtMonthIndex > e);
        });
      }
      t({
        activeEmployeesAt: o,
        collectPendingFees: i,
        settleMonth: function settleMonth(t) {
          var e,
            c,
            f,
            d = t.cfg,
            p = t.industry,
            l = t.year,
            m = t.month,
            h = t.monthIndex,
            y = t.state,
            M = d.industry[p],
            C = u(d, y, h),
            I = o(y, h),
            g = y.departments.find(function (t) {
              return "BUSINESS" === t.type;
            }),
            E = g ? I.filter(function (t) {
              return s(t, h) === g.deptId;
            }) : [],
            v = C.marketing.effectBps + (null != (e = t.eventDemandBps) ? e : 0),
            S = a(d, p, l, m, t.acqMultiplierBps, v),
            b = r(d, p, {
              businessEmployees: E,
              ceo: y.ceo,
              departments: y.departments,
              businessCapacityInvestmentYuan: t.businessCapacityInvestmentYuan,
              hrCapacityBps: C.hrCapacity.effectBps
            }, h),
            x = n(Math.min(S, b.monthlyCapacityYuan)),
            B = y.monthlyLedgersRolling.filter(function (t) {
              return t.runId === y.runId && t.year === l;
            }),
            Y = B.reduce(function (t, e) {
              return t + e.revenueYuan;
            }, 0),
            A = B.reduce(function (t, e) {
              return t + Math.abs(e.directCostYuan);
            }, 0),
            P = B.reduce(function (t, e) {
              return t + Math.abs(e.otherOperatingCostYuan);
            }, 0),
            T = B.reduce(function (t, e) {
              return t + Math.abs(e.afterSalesCostYuan);
            }, 0),
            D = B.reduce(function (t, e) {
              return t + Math.abs(e.fixedCostYuan);
            }, 0),
            N = Y + x,
            R = n(N * M.directCostBps / 1e4),
            L = n(R * M.procurementEligibleDirectCostBps * C.procurement.effectBps / Math.pow(1e4, 2)),
            U = Math.max(0, R - L) - A,
            _ = n(N * M.afterSalesCostBps / 1e4),
            F = n(_ * (1e4 - C.customerService.effectBps) / 1e4),
            O = Math.max(0, F - T),
            k = n(N * M.otherOperatingCostBps / 1e4),
            w = M.fixedManagementAnnualYuan,
            V = n((w + k) * C.finance.effectBps / 1e4),
            H = Math.min(w, V),
            K = Math.max(0, V - H),
            q = w - H,
            G = 12 === m ? q - D : Math.round(q / 12),
            W = Math.max(0, k - K),
            j = Math.max(0, W - P),
            z = I.reduce(function (t, e) {
              return t + e.salaryMonthlyYuan;
            }, 0),
            J = y.runId + ":" + l + ":" + m,
            Q = i(y, J),
            X = function X(t) {
              return Q.filter(function (e) {
                return e.category === t;
              }).reduce(function (t, e) {
                return t + e.amountAbs;
              }, 0);
            },
            Z = X("RECRUITMENT"),
            $ = X("SEVERANCE"),
            tt = X("DEPT_SETUP"),
            et = X("EVENT") + (null != (c = t.eventLossYuan) ? c : 0),
            nt = x - U - j - O - G - z - Z - $ - tt - et - 0,
            rt = x - U - j - O - G - z,
            at = rt + -(Z + $ + tt + et + 0),
            ut = -Q.filter(function (t) {
              return t.isCash && !t.alreadyPaid;
            }).reduce(function (t, e) {
              return t + e.amountAbs;
            }, 0),
            st = rt + ut - (null != (f = t.eventLossYuan) ? f : 0);
          return {
            revenue: x,
            directCost: U,
            otherOperating: j,
            afterSales: O,
            fixed: G,
            payroll: z,
            recruitment: Z,
            severance: $,
            deptSetup: tt,
            event: et,
            depreciation: 0,
            profit: nt,
            cashDelta: at,
            unpaidCashDelta: st,
            paidRecruitmentNow: 0,
            headcount: I.length
          };
        }
      }), e._RF.push({}, "8db96MUnL1H5KwTlIdaTeWc", "monthly", void 0), e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/MutationContext.ts", ["cc"], function (e) {
  var n;
  return {
    setters: [function (e) {
      n = e.cclegacy;
    }],
    execute: function execute() {
      e({
        ensureRevision: function ensureRevision(e, n) {},
        ensureRunId: function ensureRunId(e, n) {
          if (e.runId !== n) throw new Error("RUN_CHANGED");
        },
        hasCommand: function hasCommand(e, n) {
          return e.executedCommandIds.includes(n);
        },
        recordCommand: function recordCommand(e, n) {
          e.executedCommandIds.push(n), e.executedCommandIds.length > 200 && (e.executedCommandIds = e.executedCommandIds.slice(-200));
        }
      }), n._RF.push({}, "66ce7Az8LJGfqJX1Xq0asAf", "MutationContext", void 0);
      e("INITIAL_CAPITAL_YUAN", 3e5);
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/NameGenerator.ts", ["cc", "./companyNames.ts", "./peopleNames.ts"], function (n) {
  var r, t, e, o, i, c;
  return {
    setters: [function (n) {
      r = n.cclegacy;
    }, function (n) {
      t = n.COMPANY_NAME_PREFIXES, e = n.COMPANY_NAME_ENDINGS, o = n.INDUSTRY_SUFFIXES;
    }, function (n) {
      i = n.SURNAMES, c = n.GIVEN_NAMES;
    }],
    execute: function execute() {
      r._RF.push({}, "35fb5osjz1GcIOotiKVhGve", "NameGenerator", void 0);
      n("NameGenerator", function () {
        function n(n) {
          this.rng = n;
        }
        var r = n.prototype;
        return r.rollCompanyNames = function (n, r) {
          var i;
          void 0 === r && (r = 3);
          for (var c = null != (i = o[n]) ? i : [], s = [], a = 0; s.length < r && a < 80 * r;) {
            a += 1;
            var u = this.rng.pick(t),
              N = this.rng.pick(c),
              p = "" + u + N + this.rng.pick(e),
              f = Array.from(p).length <= 20 ? p : "" + u + N;
            s.includes(f) || s.push(f);
          }
          return s;
        }, r.rollPersonName = function () {
          return "" + this.rng.pick(i) + this.rng.pick(c);
        }, n;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/OfferService.ts", ["cc", "./CandidateGenerator.ts", "./errors.ts", "./ids.ts"], function (e) {
  var r, n, t, f;
  return {
    setters: [function (e) {
      r = e.cclegacy;
    }, function (e) {
      n = e.generateCandidates;
    }, function (e) {
      t = e.GameErrorCode;
    }, function (e) {
      f = e.newId;
    }],
    execute: function execute() {
      function o(e, r) {
        var n = e.departments.find(function (e) {
          return e.deptId === r;
        });
        if (!n) throw new Error(t.DEPT_NOT_FOUND);
        return n;
      }
      function u(e, r) {
        var t = function (e, r) {
            return e.offers.filter(function (e) {
              return e.deptId === r;
            }).length;
          }(e, r),
          o = n({
            runSeed: e.seed,
            deptId: r,
            offerSequence: t
          }),
          u = {
            offerId: f("offer", e.runId + ":" + r, t),
            deptId: r,
            generatedForIndex: 12 * e.gameYear + e.gameMonth,
            expiresAtMonthIndex: Number.MAX_SAFE_INTEGER,
            offerSequence: t,
            candidates: o
          };
        return e.offers.push(u), u;
      }
      e({
        findOffer: function findOffer(e, r) {
          return [].concat(e.offers).reverse().find(function (e) {
            return e.offerId === r;
          });
        },
        getOffer: function getOffer(e, r) {
          o(e, r);
          var n = [].concat(e.offers).reverse().find(function (e) {
            return e.deptId === r;
          });
          return n || u(e, r);
        },
        isOfferCurrent: function isOfferCurrent(e, r) {
          var n = e.offers.find(function (e) {
            return e.offerId === r;
          });
          if (!n) return !1;
          var t = [].concat(e.offers).reverse().find(function (e) {
            return e.deptId === n.deptId;
          });
          return (null == t ? void 0 : t.offerId) === r;
        },
        refreshOffer: function refreshOffer(e, r) {
          return o(e, r), u(e, r);
        }
      }), r._RF.push({}, "a6a6bSjWaNNO7Oybv0JXVXm", "OfferService", void 0), r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/offline.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./errors.ts", "./advanceMonth.ts"], function (e) {
  var a, l, n, s;
  return {
    setters: [function (e) {
      a = e["extends"];
    }, function (e) {
      l = e.cclegacy;
    }, function (e) {
      n = e.GameErrorCode;
    }, function (e) {
      s = e.advanceMonth;
    }],
    execute: function execute() {
      e({
        computeOfflineMonths: o,
        settleOffline: function settleOffline(e) {
          var l,
            r,
            i = e.state,
            f = e.cfg,
            c = e.nowMs,
            M = null != (l = null == (r = i.company) ? void 0 : r.cashYuan) ? l : 0;
          if ("RUNNING" !== i.phase || 0 === i.speed) return i.lastWallClockMs = Math.max(c, i.lastWallClockMs), a({}, t, {
            cashBefore: M,
            newRemainderMs: i.offlineRemainderMs
          });
          var m = c - i.lastWallClockMs;
          if (m <= 0) return i.lastWallClockMs = Math.max(c, i.lastWallClockMs), a({}, t, {
            cashBefore: M,
            clockRolledBack: !0
          });
          for (var d = o(f, m, i.offlineRemainderMs), h = d.months, u = d.newRemainderMs, R = d.eligibleMs, k = [], v = 0, g = !1, p = 0; p < h; p++) try {
            var C = s(i, f);
            v += 1, C.yearClosed && k.push(i.gameYear - 1);
          } catch (e) {
            if (e instanceof Error && (e.message === n.NOT_READY || "DISTRESS_FROZEN" === e.message)) {
              g = !0;
              break;
            }
            throw e;
          }
          if (g) {
            var x = f.time.offlineRealMsPerGameMonth,
              N = v * x,
              b = i.offlineRemainderMs + R;
            i.offlineRemainderMs = Math.max(0, b - N);
          } else i.offlineRemainderMs = u;
          return i.lastWallClockMs = Math.max(c, i.lastWallClockMs), {
            monthsSettled: v,
            yearsClosed: k,
            clockRolledBack: !1,
            interrupted: g,
            eligibleMs: R,
            newRemainderMs: i.offlineRemainderMs,
            cashBefore: M
          };
        }
      }), l._RF.push({}, "a1a95gP9rdFNKbvUNor2df7", "offline", void 0);
      var t = e("NO_OFFLINE", {
        monthsSettled: 0,
        yearsClosed: [],
        clockRolledBack: !1,
        interrupted: !1,
        eligibleMs: 0,
        newRemainderMs: 0
      });
      function o(e, a, l) {
        var n = e.time.offlineRealMsPerGameMonth,
          s = e.time.maxOfflineMonthsPerSession,
          t = e.time.maxEligibleOfflineMsPerSession,
          o = Math.max(0, Math.min(a, t)),
          r = o + Math.max(0, l),
          i = Math.floor(r / n),
          f = r - i * n;
        return i >= s && (i = s, f = 0), {
          months: i,
          newRemainderMs: f,
          eligibleMs: o
        };
      }
      l._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/peopleNames.ts", ["cc"], function (e) {
  var c;
  return {
    setters: [function (e) {
      c = e.cclegacy;
    }],
    execute: function execute() {
      c._RF.push({}, "0efc4SdDJ5HMpJgkVQk0sOI", "peopleNames", void 0);
      e("SURNAMES", ["李", "王", "张", "刘", "陈", "杨", "赵", "黄", "周", "吴", "徐", "孙", "胡", "朱", "高", "林", "何", "郭", "马", "罗", "梁", "宋", "郑", "谢", "韩", "唐", "冯", "于", "董", "萧"]), e("GIVEN_NAMES", ["伟", "芳", "娜", "敏", "静", "磊", "强", "洋", "艳", "军", "杰", "涛", "明", "超", "秀英", "霞", "平", "刚", "桂英", "文", "子涵", "欣怡", "梓轩", "思远", "浩然", "雨桐", "一诺", "若曦", "嘉怡", "宇航", "晨曦", "书瑶", "景行", "知微", "怀瑾", "望舒", "南星", "清远", "允之", "安和"]), e("CEO_RANDOM_NAMES", ["林启航", "陈稳", "赵亲和", "王远征", "李思源", "周明达", "孙一诺", "何静宜"]);
      c._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/PlatformFactory.ts", ["cc", "./TapPlatform.ts", "./CocosPlatform.ts"], function (t) {
  var r, o, c, e;
  return {
    setters: [function (t) {
      r = t.cclegacy;
    }, function (t) {
      o = t.resolveTapRuntime, c = t.TapPlatform;
    }, function (t) {
      e = t.CocosPlatform;
    }],
    execute: function execute() {
      t("createPlatform", function () {
        var t = o();
        if (t) return new c(t);
        return new e();
      }), r._RF.push({}, "42fd3JjpbBG+6spHTWkacSN", "PlatformFactory", void 0), r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/privacyConsent.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (t) {
  var e, n;
  return {
    setters: [function (t) {
      e = t.asyncToGenerator;
    }, function (t) {
      n = t.cclegacy;
    }],
    execute: function execute() {
      t({
        acceptPrivacy: function acceptPrivacy(t, e) {
          return o.apply(this, arguments);
        },
        hasAcceptedPrivacy: function hasAcceptedPrivacy(t, e) {
          return i.apply(this, arguments);
        }
      }), n._RF.push({}, "92ebcjl/mdDmY7ENgmwC0Ro", "privacyConsent", void 0);
      var c = t("PRIVACY_CONSENT_KEY", "ceo/privacy/consent"),
        r = t("PRIVACY_POLICY_VERSION", 1);
      function i() {
        return (i = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee62(t, e) {
          var n;
          return _regeneratorRuntime().wrap(function _callee62$(_context63) {
            while (1) switch (_context63.prev = _context63.next) {
              case 0:
                _context63.prev = 0;
                _context63.next = 3;
                return t.get(c);
              case 3:
                n = _context63.sent;
                return _context63.abrupt("return", !!n && !0 === n.accepted && n.policyVersion === r);
              case 7:
                _context63.prev = 7;
                _context63.t0 = _context63["catch"](0);
                return _context63.abrupt("return", !1);
              case 10:
              case "end":
                return _context63.stop();
            }
          }, _callee62, null, [[0, 7]]);
        }))).apply(this, arguments);
      }
      function o() {
        return (o = e( /*#__PURE__*/_regeneratorRuntime().mark(function _callee63(t, e) {
          var n;
          return _regeneratorRuntime().wrap(function _callee63$(_context64) {
            while (1) switch (_context64.prev = _context64.next) {
              case 0:
                void 0 === e && (e = Date.now);
                n = {
                  accepted: !0,
                  policyVersion: r,
                  acceptedAtMs: e()
                };
                _context64.next = 4;
                return t.set(c, n);
              case 4:
                return _context64.abrupt("return", n);
              case 5:
              case "end":
                return _context64.stop();
            }
          }, _callee63);
        }))).apply(this, arguments);
      }
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RandomStreams.ts", ["cc", "./rng.ts"], function (e) {
  var n, t, r;
  return {
    setters: [function (e) {
      n = e.cclegacy;
    }, function (e) {
      t = e.Rng, r = e.deriveSeed;
    }],
    execute: function execute() {
      e("streamsFor", function (e) {
        return new u(e);
      }), n._RF.push({}, "40d60GjZu1BpL50wMVk4C0h", "RandomStreams", void 0);
      var u = e("RandomStreams", function () {
        function e(e) {
          this.runSeed = e;
        }
        var n = e.prototype;
        return n.stream = function (e, n) {
          return new t(r(this.runSeed, e, n));
        }, n.marketForYear = function (e) {
          return this.stream("market", e);
        }, n.eventForYear = function (e) {
          return new t(r(this.runSeed, "event", e));
        }, n.companyNames = function (e) {
          return this.stream("companyName", e);
        }, e;
      }());
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RecruitmentService.ts", ["cc", "./CandidateGenerator.ts", "./errors.ts", "./MutationContext.ts", "./OfferService.ts", "./departments.ts", "./monthEntry.ts"], function (e) {
  var n, r, t, a, o, i, d, c, s, I, m;
  return {
    setters: [function (e) {
      n = e.cclegacy;
    }, function (e) {
      r = e.recruitmentFee;
    }, function (e) {
      t = e.GameErrorCode;
    }, function (e) {
      a = e.ensureRunId, o = e.hasCommand, i = e.recordCommand;
    }, function (e) {
      d = e.isOfferCurrent;
    }, function (e) {
      c = e.hrRecruitmentDiscountBps, s = e.activeStaffInDept;
    }, function (e) {
      I = e.monthIndexOf, m = e.addPendingEntry;
    }],
    execute: function execute() {
      function u(e, n) {
        return "emp_" + e.runId + "_" + n;
      }
      function f(e, n) {
        e.onboarding.completedSteps.includes(n) || e.onboarding.completedSteps.push(n);
      }
      e({
        hireEmployee: function hireEmployee(e, n, p, h) {
          if (a(e, h.expectedRunId), !e.company) throw new Error(t.NOT_READY);
          if (o(e, h.commandId)) {
            var E = e.employees.find(function (e) {
                return e.hireCommandId === h.commandId;
              }),
              l = e.pendingEntries.find(function (e) {
                return e.refId === h.commandId && "RECRUITMENT" === e.category;
              });
            if (E) return {
              employee: E,
              feePaidYuan: l ? Math.abs(l.amountYuan) : 0,
              cashAfterYuan: e.company.cashYuan,
              firstHire: 1 === e.onboarding.initialHiresCompleted
            };
          }
          var R = "HIRING_INITIAL" === e.phase;
          if (!R && "RUNNING" !== e.phase && "DISTRESS" !== e.phase) throw new Error(t.NOT_READY);
          if (R && e.onboarding.initialHiresCompleted >= 2) throw new Error(t.NOT_READY);
          if (!e.departments.find(function (e) {
            return e.deptId === p.departmentId;
          })) throw new Error(t.DEPT_NOT_FOUND);
          if (!d(e, p.offerId)) throw new Error(t.OFFER_EXPIRED);
          var N = e.offers.find(function (e) {
            return e.offerId === p.offerId;
          });
          if (!N || N.deptId !== p.departmentId) throw new Error(t.OFFER_EXPIRED);
          var T = N.candidates.find(function (e) {
            return e.candidateId === p.candidateId;
          });
          if (!T) throw new Error(t.OFFER_EXPIRED);
          if (e.employees.some(function (e) {
            return e.candidateId === T.candidateId;
          })) throw new Error(t.OFFER_EXPIRED);
          var y = I(e),
            w = c(n, s(e, "HR", y)),
            O = r(T.salaryMonthlyYuan, w);
          if (e.company.cashYuan < O) throw new Error(t.INSUFFICIENT_CASH);
          var _ = {
            employeeId: u(e, T.candidateId),
            name: T.name,
            avatarId: T.avatarId,
            departmentId: p.departmentId,
            skill: T.skill,
            potential: T.potential,
            teamwork: T.teamwork,
            personality: T.personality,
            salaryMonthlyYuan: T.salaryMonthlyYuan,
            hiredAtMonthIndex: y,
            effectiveFromMonthIndex: R ? 0 : y + 1,
            dismissedAtMonthIndex: null,
            status: "ACTIVE",
            hireCommandId: h.commandId,
            candidateId: T.candidateId
          };
          e.company.cashYuan -= O, m(e, "RECRUITMENT", -O, h.commandId), e.employees.push(_), i(e, h.commandId);
          var A = !1;
          R && (e.onboarding.initialHiresCompleted += 1, A = 1 === e.onboarding.initialHiresCompleted, e.onboarding.initialHiresCompleted >= 2 && (e.phase = "TUTORIAL_DASHBOARD", f(e, "TUT-03")));
          return {
            employee: _,
            feePaidYuan: O,
            cashAfterYuan: e.company.cashYuan,
            firstHire: A
          };
        },
        startOperating: function startOperating(e, n) {
          if (a(e, n.expectedRunId), "RUNNING" === e.phase) return;
          if ("TUTORIAL_DASHBOARD" !== e.phase && "HIRING_INITIAL" !== e.phase) throw new Error(t.NOT_READY);
          if (e.onboarding.initialHiresCompleted < 2) throw new Error(t.ONBOARDING_INCOMPLETE);
          if (o(e, n.commandId)) return;
          e.phase = "RUNNING", e.speed = 1, f(e, "TUT-04"), f(e, "TUT-05"), i(e, n.commandId);
        }
      }), n._RF.push({}, "6700c9IIuBAFonvoX/qjl7V", "RecruitmentService", void 0), n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/ResetService.ts", ["cc", "./errors.ts", "./gameStateFactory.ts", "./ids.ts"], function (e) {
  var n, r, o, t;
  return {
    setters: [function (e) {
      n = e.cclegacy;
    }, function (e) {
      r = e.GameErrorCode;
    }, function (e) {
      o = e.createFreshRunState;
    }, function (e) {
      t = e.uniqueToken;
    }],
    execute: function execute() {
      e({
        closeCompanyPreview: function closeCompanyPreview(e, n) {
          if (!e.company) throw new Error(r.NOT_READY);
          return {
            confirmationToken: t("close"),
            issuedAtMs: n,
            expiresAtMs: n + 6e4,
            oldRunId: e.runId,
            summary: {
              companyName: e.company.name,
              yearsOperated: e.annualReports.length,
              cashYuan: e.company.cashYuan,
              employeeCount: e.employees.filter(function (e) {
                return "DISMISSED" !== e.status;
              }).length
            }
          };
        },
        confirmCloseCompany: function confirmCloseCompany(e, n, t) {
          if (!e.company) throw new Error(r.NOT_READY);
          if (t > n.expiresAtMs) throw new Error(r.CONFIRMATION_EXPIRED);
          if (n.oldRunId !== e.runId) throw new Error(r.RUN_CHANGED);
          if (!n.confirmationToken) throw new Error(r.CONFIRMATION_EXPIRED);
          var a = e.runId,
            s = o(t);
          return s.lastWallClockMs = t, s.offlineRemainderMs = 0, {
            oldRunId: a,
            newState: s
          };
        }
      }), n._RF.push({}, "f187bY9MENM0ZBBN8bvafXf", "ResetService", void 0);
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/result.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (e) {
  var n, s;
  return {
    setters: [function (e) {
      n = e["extends"];
    }, function (e) {
      s = e.cclegacy;
    }],
    execute: function execute() {
      e({
        fail: function fail(e, s, o) {
          return void 0 === o ? {
            ok: !1,
            code: e,
            displayMessage: s
          } : {
            ok: !1,
            code: e,
            displayMessage: s,
            details: n({}, o)
          };
        },
        isSuccess: function isSuccess(e) {
          return e.ok;
        },
        ok: function ok(e, n, s) {
          return {
            ok: !0,
            runId: e,
            revision: n,
            payload: s
          };
        }
      }), s._RF.push({}, "fe683aiYxZIp6PQLnwZp/gV", "result", void 0), s._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RiskService.ts", ["cc", "./errors.ts", "./MutationContext.ts", "./monthEntry.ts"], function (n) {
  var e, a, t, r, u, o, i;
  return {
    setters: [function (n) {
      e = n.cclegacy;
    }, function (n) {
      a = n.GameErrorCode;
    }, function (n) {
      t = n.ensureRunId, r = n.hasCommand, u = n.recordCommand;
    }, function (n) {
      o = n.monthIndexOf, i = n.addPendingEntry;
    }],
    execute: function execute() {
      function s(n, e, a) {
        var t = o(e),
          r = e.employees.filter(function (n) {
            return "ACTIVE" === n.status && n.effectiveFromMonthIndex <= t;
          }).reduce(function (n, e) {
            return n + e.salaryMonthlyYuan;
          }, 0),
          u = n.industry[e.company.industry].fixedManagementAnnualYuan / 12;
        return Math.round((r + u) * a);
      }
      function c(n, e) {
        var a,
          t,
          r = null != (a = null == (t = n.company) ? void 0 : t.cashYuan) ? a : 0,
          u = s(e, n, e.risk.cashWarningRequiredMonths),
          o = s(e, n, 1),
          i = n.monthlyLedgersRolling.filter(function (e) {
            return e.runId === n.runId;
          }),
          c = i[i.length - 1],
          d = 0;
        c && (d = c.revenueYuan + c.directCostYuan + c.otherOperatingCostYuan + c.afterSalesCostYuan + c.fixedCostYuan + c.payrollYuan);
        var l = "NORMAL";
        return r + Math.max(0, d) < o ? l = "DISTRESS" : r < u && (l = "WARNING"), {
          level: l,
          cash: r,
          sixMonthNeed: u,
          nextMonthNeed: o,
          projectedNextInflow: d
        };
      }
      function d(n, e) {
        var a = c(n, e).level;
        return n.cashRisk = a, a;
      }
      n({
        assessRisk: c,
        committedCost: s,
        injectRescueCapital: function injectRescueCapital(n, e, o) {
          if (t(n, o.expectedRunId), !n.company) throw new Error(a.NOT_READY);
          if (r(n, o.commandId) && n.rescueCapitalUsed) return {
            granted: !1,
            amountYuan: 0,
            cashAfterYuan: n.company.cashYuan,
            paidInCapitalAfterYuan: n.company.paidInCapitalYuan
          };
          if (n.rescueCapitalUsed) throw new Error(a.ALREADY_USED);
          var s = e.risk.oneTimeRescueCapitalYuan;
          return n.company.cashYuan += s, n.company.paidInCapitalYuan += s, i(n, "CAPITAL_INJECTION", s, o.commandId), n.rescueCapitalUsed = !0, u(n, o.commandId), d(n, e), {
            granted: !0,
            amountYuan: s,
            cashAfterYuan: n.company.cashYuan,
            paidInCapitalAfterYuan: n.company.paidInCapitalYuan
          };
        },
        refreshRisk: d
      }), e._RF.push({}, "e43c7TKkzxHL6gdsW4se7dh", "RiskService", void 0), e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/rng.ts", ["cc"], function (t) {
  var n;
  return {
    setters: [function (t) {
      n = t.cclegacy;
    }],
    execute: function execute() {
      function r(t) {
        for (var n = 1779033703 ^ t.length, r = 0; r < t.length; r++) n = (n = Math.imul(n ^ t.charCodeAt(r), 3432918353)) << 13 | n >>> 19;
        return n = Math.imul(n ^ n >>> 16, 2246822507), n = Math.imul(n ^ n >>> 13, 3266489909), (n ^= n >>> 16) >>> 0;
      }
      function e() {
        for (var t = arguments.length, n = new Array(t), e = 0; e < t; e++) n[e] = arguments[e];
        return r(n.map(function (t) {
          return String(t);
        }).join("|"));
      }
      t({
        deriveSeed: e,
        hashString: r,
        randomSeed: function randomSeed() {
          var t = globalThis.crypto;
          if (t && "function" == typeof t.getRandomValues) {
            var n = new Uint32Array(1);
            t.getRandomValues(n);
            var r = n[0];
            if (void 0 !== r) return r >>> 0;
          }
          return (Date.now() ^ Math.floor(4294967295 * Math.random())) >>> 0;
        }
      }), n._RF.push({}, "33891uZ76FP8YiibXWIKEsH", "rng", void 0);
      t("Rng", function () {
        function t(t) {
          this.state = void 0, this.state = t >>> 0;
        }
        var n = t.prototype;
        return n.derive = function (n) {
          return new t(e(this.state >>> 0, n));
        }, n.nextUint32 = function () {
          this.state = this.state + 1831565813 >>> 0;
          var t = this.state;
          return t = Math.imul(t ^ t >>> 15, 1 | t), ((t ^= t + Math.imul(t ^ t >>> 7, 61 | t)) ^ t >>> 14) >>> 0;
        }, n.next = function () {
          return this.nextUint32() / 4294967296;
        }, n.nextInt = function (t, n) {
          if (n < t) throw new Error("nextInt range invalid: " + t + ".." + n);
          var r = n - t + 1;
          return t + Math.floor(this.next() * r);
        }, n.pick = function (t) {
          if (0 === t.length) throw new Error("pick from empty array");
          var n = t[this.nextInt(0, t.length - 1)];
          if (void 0 === n) throw new Error("pick returned undefined");
          return n;
        }, n.sample = function (t, n) {
          if (n > t.length) throw new Error("sample " + n + " from " + t.length + " items");
          for (var r = [].concat(t), e = [], i = 0; i < n; i++) {
            var o = this.nextInt(0, r.length - 1),
              a = r[o];
            if (void 0 === a) throw new Error("sample returned undefined");
            e.push(a), r.splice(o, 1);
          }
          return e;
        }, t;
      }());
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/runtimeConfig.ts", ["cc"], function (n) {
  var t;
  return {
    setters: [function (n) {
      t = n.cclegacy;
    }],
    execute: function execute() {
      n({
        getRuntimeConfig: function getRuntimeConfig() {
          var n;
          return null != (n = r) ? n : i;
        },
        setRuntimeConfig: function setRuntimeConfig(n) {
          return r = {
            authEndpoint: "string" == typeof (null == n ? void 0 : n.authEndpoint) ? n.authEndpoint : "",
            privacyPolicyUrl: "string" == typeof (null == n ? void 0 : n.privacyPolicyUrl) ? n.privacyPolicyUrl : ""
          };
        }
      }), t._RF.push({}, "27c3cPSse9LgpdqUbKMVl4f", "runtimeConfig", void 0);
      var i = {
          authEndpoint: "",
          privacyPolicyUrl: ""
        },
        r = null;
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/safeArea.ts", ["cc"], function (t) {
  var e;
  return {
    setters: [function (t) {
      e = t.cclegacy;
    }],
    execute: function execute() {
      t("computeSafeAreaTransform", function (t, e) {
        void 0 === e && (e = {
          width: a,
          height: i
        });
        var h = t.safeArea,
          f = t.width > 0 ? t.width : e.width,
          n = t.height > 0 ? t.height : e.height;
        if (!h) return r;
        var s = Math.max(0, Math.min(h.left, f)),
          o = Math.max(0, Math.min(f - h.right, f)),
          u = Math.max(0, Math.min(h.top, n)),
          c = Math.max(0, Math.min(n - h.bottom, n)),
          m = f - s - o,
          d = n - u - c;
        if (m <= 0 || d <= 0) return r;
        var p = Math.min(m / e.width, d / e.height);
        if (!Number.isFinite(p) || p <= 0) return r;
        var v = (c - u) / 2 / p,
          M = (o - s) / 2 / p;
        return s + o + u + c === 0 ? r : {
          scale: p,
          offsetX: M,
          offsetY: v,
          applied: !0
        };
      }), e._RF.push({}, "d0559LuyyZGzoqIsG2rXuoI", "safeArea", void 0);
      var a = t("SAFE_DESIGN_WIDTH", 375),
        i = t("SAFE_DESIGN_HEIGHT", 812),
        r = {
          scale: 1,
          offsetX: 0,
          offsetY: 0,
          applied: !1
        };
      e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SafeArea2.ts", ["cc", "./safeArea.ts"], function (e) {
  var r, t;
  return {
    setters: [function (e) {
      r = e.cclegacy;
    }, function (r) {
      t = r.computeSafeAreaTransform, e("computeSafeAreaTransform", r.computeSafeAreaTransform);
    }],
    execute: function execute() {
      e("resolveSafeAreaTransform", function (e) {
        try {
          return t(e.getWindowInfo());
        } catch (e) {
          return {
            scale: 1,
            offsetX: 0,
            offsetY: 0,
            applied: !1
          };
        }
      }), r._RF.push({}, "8e6255N24tBdrbpx2ymeMxs", "SafeArea", void 0), r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SaveCodec.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./crc32.ts", "./canonical.ts", "./SaveTypes.ts"], function (e) {
  var n, r, o, i, s, t;
  return {
    setters: [function (e) {
      n = e["extends"];
    }, function (e) {
      r = e.cclegacy;
    }, function (e) {
      o = e.crc32String;
    }, function (e) {
      i = e.canonicalStringify;
    }, function (e) {
      s = e.CURRENT_SCHEMA_VERSION, t = e.CURRENT_CONFIG_VERSION;
    }],
    execute: function execute() {
      e({
        computeChecksum: c,
        encodeEnvelope: function encodeEnvelope(e, r) {
          var o,
            i,
            u = {
              schemaVersion: s,
              gameVersion: null != (o = r.gameVersion) ? o : a,
              configVersion: null != (i = r.configVersion) ? i : t,
              revision: r.revision,
              runId: r.runId,
              resetGeneration: r.resetGeneration,
              payload: e
            };
          return n({}, u, {
            checksum: c(u)
          });
        },
        verifyEnvelope: function verifyEnvelope(e) {
          var n, r, o;
          if (null === e || "object" != _typeof(e)) return {
            ok: !1,
            reason: "not-an-object"
          };
          var i = e;
          if (i.schemaVersion !== s) return {
            ok: !1,
            reason: "unsupported-schema:" + String(i.schemaVersion)
          };
          if ("number" != typeof i.revision || "string" != typeof i.runId) return {
            ok: !1,
            reason: "missing-fields"
          };
          if ("string" != typeof i.checksum || void 0 === i.payload) return {
            ok: !1,
            reason: "missing-checksum-or-payload"
          };
          if (c({
            schemaVersion: i.schemaVersion,
            gameVersion: null != (n = i.gameVersion) ? n : a,
            configVersion: null != (r = i.configVersion) ? r : t,
            revision: i.revision,
            runId: i.runId,
            resetGeneration: null != (o = i.resetGeneration) ? o : 0,
            payload: i.payload
          }) !== i.checksum) return {
            ok: !1,
            reason: "checksum-mismatch"
          };
          return {
            ok: !0
          };
        }
      }), r._RF.push({}, "ffe28NB4xtGZZCyCpR20TwS", "SaveCodec", void 0);
      var a = e("GAME_VERSION", "0.1.0");
      function c(e) {
        var n = e.schemaVersion,
          r = e.gameVersion,
          s = e.configVersion,
          t = e.revision,
          a = e.runId,
          c = e.resetGeneration,
          u = e.payload;
        return o(i({
          schemaVersion: n,
          gameVersion: r,
          configVersion: s,
          revision: t,
          runId: a,
          resetGeneration: c,
          payload: u
        }));
      }
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SaveMigration.ts", ["cc"], function (e) {
  var r;
  return {
    setters: [function (e) {
      r = e.cclegacy;
    }],
    execute: function execute() {
      e({
        migrateEnvelope: function migrateEnvelope(e, r) {
          void 0 === r && (r = 1);
          var o = e;
          for (; o.schemaVersion < r;) {
            var i = n.get(o.schemaVersion);
            if (!i) throw new Error("no migrator from schemaVersion " + o.schemaVersion);
            o = i(o);
          }
          if (o.schemaVersion > r) throw new Error("save schema " + o.schemaVersion + " is newer than supported " + r);
          return o;
        },
        registerMigrator: function registerMigrator(e, r) {
          n.set(e, r);
        }
      }), r._RF.push({}, "e6ad1FCOTZKUYebGJ4bzJor", "SaveMigration", void 0);
      var n = new Map();
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SaveRepository.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./errors.ts", "./canonical.ts", "./SaveCodec.ts", "./SaveMigration.ts", "./stateIntegrity.ts", "./SaveTypes.ts"], function (e) {
  var t, r, n, o, i, a, s, u, l;
  return {
    setters: [function (e) {
      t = e.asyncToGenerator;
    }, function (e) {
      r = e.cclegacy;
    }, function (e) {
      n = e.GameErrorCode;
    }, function (e) {
      o = e.canonicalStringify;
    }, function (e) {
      i = e.encodeEnvelope, a = e.verifyEnvelope;
    }, function (e) {
      s = e.migrateEnvelope;
    }, function (e) {
      u = e.validateGameState;
    }, function (e) {
      l = e.SAVE_KEYS;
    }],
    execute: function execute() {
      r._RF.push({}, "88410Q6pDtFL6hj3LGuJjXI", "SaveRepository", void 0);
      e("SaveRepository", function () {
        function e(e, t) {
          void 0 === t && (t = 5e5), this.storage = void 0, this.targetMaxBytes = void 0, this.storage = e, this.targetMaxBytes = t;
        }
        var r = e.prototype;
        return r.commit = function () {
          var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee64(e, t) {
            var r, s, u, v, c, d, f, h, p;
            return _regeneratorRuntime().wrap(function _callee64$(_context65) {
              while (1) switch (_context65.prev = _context65.next) {
                case 0:
                  if (!(0 === e.runId.length)) {
                    _context65.next = 2;
                    break;
                  }
                  throw new Error("runId required");
                case 2:
                  _context65.next = 4;
                  return this.readTombstone();
                case 4:
                  r = _context65.sent;
                  if (!(r && r.oldRunId === e.runId)) {
                    _context65.next = 7;
                    break;
                  }
                  throw new Error(n.RUN_CHANGED);
                case 7:
                  _context65.next = 9;
                  return this.readPointer();
                case 9:
                  s = _context65.sent;
                  u = "a" === (null == s ? void 0 : s.slot) ? "b" : "a";
                  v = i(e, {
                    revision: t.revision,
                    runId: e.runId,
                    resetGeneration: t.resetGeneration
                  });
                  c = o(v).length;
                  if (!(c > this.targetMaxBytes)) {
                    _context65.next = 15;
                    break;
                  }
                  throw new Error(n.SAVE_FAILED + ":save-too-large:" + c);
                case 15:
                  d = "a" === u ? l.slotA : l.slotB;
                  _context65.next = 18;
                  return this.storage.set(d, v);
                case 18:
                  _context65.next = 20;
                  return this.storage.get(d);
                case 20:
                  f = _context65.sent;
                  if (f) {
                    _context65.next = 23;
                    break;
                  }
                  throw new Error(n.SAVE_FAILED + ":readback-null");
                case 23:
                  h = a(f);
                  if (h.ok) {
                    _context65.next = 26;
                    break;
                  }
                  throw new Error(n.SAVE_FAILED + ":" + h.reason);
                case 26:
                  p = {
                    slot: u,
                    revision: t.revision,
                    runId: e.runId,
                    resetGeneration: t.resetGeneration
                  };
                  _context65.next = 29;
                  return this.storage.set(l.active, p);
                case 29:
                  return _context65.abrupt("return", v);
                case 30:
                case "end":
                  return _context65.stop();
              }
            }, _callee64, this);
          }));
          return function (t, r) {
            return e.apply(this, arguments);
          };
        }(), r.load = function () {
          var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee65() {
            var e, t, r, o, i, a, s, u, v, c;
            return _regeneratorRuntime().wrap(function _callee65$(_context66) {
              while (1) switch (_context66.prev = _context66.next) {
                case 0:
                  _context66.next = 2;
                  return this.readTombstone();
                case 2:
                  t = _context66.sent;
                  _context66.next = 5;
                  return this.readPointer();
                case 5:
                  r = _context66.sent;
                  if (!r) {
                    _context66.next = 13;
                    break;
                  }
                  o = "a" === r.slot ? l.slotA : l.slotB;
                  _context66.next = 10;
                  return this.tryReadSlot(o);
                case 10:
                  i = _context66.sent;
                  if (!(i && i.runId === r.runId && (!t || t.oldRunId !== i.runId))) {
                    _context66.next = 13;
                    break;
                  }
                  return _context66.abrupt("return", this.finalize(i, !1));
                case 13:
                  a = [];
                  _context66.next = 16;
                  return this.tryReadSlot(l.slotA);
                case 16:
                  s = _context66.sent;
                  _context66.next = 19;
                  return this.tryReadSlot(l.slotB);
                case 19:
                  u = _context66.sent;
                  s && a.push({
                    slot: "a",
                    envelope: s
                  }), u && a.push({
                    slot: "b",
                    envelope: u
                  });
                  v = a.filter(function (e) {
                    return !(t && t.oldRunId === e.envelope.runId);
                  }).sort(function (e, t) {
                    return t.envelope.revision - e.envelope.revision;
                  })[0];
                  if (v) {
                    _context66.next = 28;
                    break;
                  }
                  if (!(t && (s || u))) {
                    _context66.next = 25;
                    break;
                  }
                  return _context66.abrupt("return", null);
                case 25:
                  if (!(r || s || u)) {
                    _context66.next = 27;
                    break;
                  }
                  throw new Error(n.SAVE_CORRUPT);
                case 27:
                  return _context66.abrupt("return", null);
                case 28:
                  c = {
                    slot: v.slot,
                    revision: v.envelope.revision,
                    runId: v.envelope.runId,
                    resetGeneration: null != (e = v.envelope.resetGeneration) ? e : 0
                  };
                  _context66.next = 31;
                  return this.storage.set(l.active, c);
                case 31:
                  return _context66.abrupt("return", this.finalize(v.envelope, !0, r ? "pointer-mismatch" : "pointer-missing"));
                case 32:
                case "end":
                  return _context66.stop();
              }
            }, _callee65, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), r.writeTombstone = function () {
          var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee66(e) {
            return _regeneratorRuntime().wrap(function _callee66$(_context67) {
              while (1) switch (_context67.prev = _context67.next) {
                case 0:
                  _context67.next = 2;
                  return this.storage.set(l.tombstone, e);
                case 2:
                case "end":
                  return _context67.stop();
              }
            }, _callee66, this);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), r.readTombstone = function () {
          var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee67() {
            return _regeneratorRuntime().wrap(function _callee67$(_context68) {
              while (1) switch (_context68.prev = _context68.next) {
                case 0:
                  return _context68.abrupt("return", this.storage.get(l.tombstone));
                case 1:
                case "end":
                  return _context68.stop();
              }
            }, _callee67, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), r.clearRunSlots = function () {
          var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee68(e) {
            var t, r, n, o;
            return _regeneratorRuntime().wrap(function _callee68$(_context69) {
              while (1) switch (_context69.prev = _context69.next) {
                case 0:
                  t = 0, r = [l.slotA, l.slotB];
                case 1:
                  if (!(t < r.length)) {
                    _context69.next = 13;
                    break;
                  }
                  n = r[t];
                  _context69.next = 5;
                  return this.tryReadSlot(n);
                case 5:
                  o = _context69.sent;
                  _context69.t0 = o && o.runId === e;
                  if (!_context69.t0) {
                    _context69.next = 10;
                    break;
                  }
                  _context69.next = 10;
                  return this.storage.remove(n);
                case 10:
                  t++;
                  _context69.next = 1;
                  break;
                case 13:
                case "end":
                  return _context69.stop();
              }
            }, _callee68, this);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), r.clearPointer = function () {
          var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee69() {
            return _regeneratorRuntime().wrap(function _callee69$(_context70) {
              while (1) switch (_context70.prev = _context70.next) {
                case 0:
                  _context70.next = 2;
                  return this.storage.remove(l.active);
                case 2:
                case "end":
                  return _context70.stop();
              }
            }, _callee69, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), r.readPointer = function () {
          var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee70() {
            return _regeneratorRuntime().wrap(function _callee70$(_context71) {
              while (1) switch (_context71.prev = _context71.next) {
                case 0:
                  return _context71.abrupt("return", this.storage.get(l.active));
                case 1:
                case "end":
                  return _context71.stop();
              }
            }, _callee70, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), r.tryReadSlot = function () {
          var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee71(e) {
            var t, r;
            return _regeneratorRuntime().wrap(function _callee71$(_context72) {
              while (1) switch (_context72.prev = _context72.next) {
                case 0:
                  _context72.prev = 0;
                  _context72.next = 3;
                  return this.storage.get(e);
                case 3:
                  t = _context72.sent;
                  if (t) {
                    _context72.next = 6;
                    break;
                  }
                  return _context72.abrupt("return", null);
                case 6:
                  if (a(t).ok) {
                    _context72.next = 8;
                    break;
                  }
                  return _context72.abrupt("return", null);
                case 8:
                  r = s(t, 1);
                  return _context72.abrupt("return", u(r.payload).ok ? t : null);
                case 12:
                  _context72.prev = 12;
                  _context72.t0 = _context72["catch"](0);
                  return _context72.abrupt("return", null);
                case 15:
                case "end":
                  return _context72.stop();
              }
            }, _callee71, this, [[0, 12]]);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), r.finalize = function (e, t, r) {
          var o,
            i = s(e, 1),
            a = u(i.payload);
          if (!a.ok) throw new Error(n.SAVE_CORRUPT + ":" + (null != (o = a.reason) ? o : "invalid-state"));
          return {
            envelope: i,
            state: i.payload,
            recovered: t,
            recoveryNote: r
          };
        }, e;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SaveTypes.ts", ["cc"], function (e) {
  var t;
  return {
    setters: [function (e) {
      t = e.cclegacy;
    }],
    execute: function execute() {
      t._RF.push({}, "99de662amBE75qqoywtRh/x", "SaveTypes", void 0);
      e("SAVE_KEYS", {
        slotA: "ceo/save/a",
        slotB: "ceo/save/b",
        active: "ceo/save/active",
        tombstone: "ceo/reset/tombstone"
      }), e("CURRENT_SCHEMA_VERSION", 1), e("CURRENT_CONFIG_VERSION", "economy-v1.0.0");
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/stateIntegrity.ts", ["cc"], function (e) {
  var r;
  return {
    setters: [function (e) {
      r = e.cclegacy;
    }],
    execute: function execute() {
      e("validateGameState", function (e) {
        var r = function r(e) {
          return {
            ok: !1,
            reason: e
          };
        };
        if (null === e || "object" != _typeof(e)) return r("not-an-object");
        var n = e;
        if ("string" != typeof n.runId || 0 === n.runId.length) return r("bad-run-id");
        if ("string" != typeof n.phase || !t.has(n.phase)) return r("bad-phase");
        if (!(Array.isArray(n.employees) && Array.isArray(n.departments) && Array.isArray(n.monthlyLedgersRolling) && Array.isArray(n.annualReports) && Array.isArray(n.pendingEntries) && Array.isArray(n.offers))) return r("non-array-collections");
        var a = "CREATING" !== n.phase;
        if (a) {
          if (!n.company || "number" != typeof n.company.cashYuan) return r("company-mismatch");
          if (!n.ceo || "number" != typeof n.ceo.businessSkill) return r("ceo-mismatch");
        }
        if (n.company) {
          var i = n.company.cashYuan;
          if ("number" != typeof i || !Number.isFinite(i)) return r("non-finite-cash");
          if (i < 0) return r("negative-cash");
          if (i > 1e11) return r("cash-overflow");
        }
        if ("number" != typeof n.gameYear || "number" != typeof n.gameMonth || n.gameYear < 1 || n.gameMonth < 1 || n.gameMonth > 12) return r("bad-time");
        if (a) {
          if (!n.departments.some(function (e) {
            return "BUSINESS" === e.type;
          })) return r("no-business-department");
        }
        for (var s = new Set(n.departments.map(function (e) {
            return e.deptId;
          })), o = new Set(), u = 0, p = n.employees; u < p.length; u++) {
          var y = p[u];
          if (o.has(y.employeeId)) return r("duplicate-employee-id");
          if (o.add(y.employeeId), ("ACTIVE" === y.status || "PENDING_DISMISSAL" === y.status) && !s.has(y.departmentId)) return r("active-employee-without-dept");
        }
        return {
          ok: !0
        };
      }), r._RF.push({}, "706915fLshHrZgcPH7UJEQu", "stateIntegrity", void 0);
      var t = new Set(["CREATING", "HIRING_INITIAL", "TUTORIAL_DASHBOARD", "RUNNING", "DISTRESS", "RESETTING"]);
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/statePrune.ts", ["cc"], function (e) {
  var t;
  return {
    setters: [function (e) {
      t = e.cclegacy;
    }],
    execute: function execute() {
      e({
        estimateStateBytes: function estimateStateBytes(e) {
          for (var t = JSON.stringify(e), n = 0, a = 0; a < t.length; a++) {
            var r = t.charCodeAt(a);
            n += r < 128 ? 1 : r < 2048 ? 2 : 3;
          }
          return n;
        },
        pruneStateHistory: function pruneStateHistory(e, t) {
          var n = t.save.rollingMonthlyLedgers;
          e.monthlyLedgersRolling.length > n && (e.monthlyLedgersRolling = e.monthlyLedgersRolling.slice(-n));
          var a = t.save.keepAnnualReports;
          e.annualReports.length > a && (e.annualReports = e.annualReports.slice(-a));
          var r = new Set(e.annualReports.map(function (e) {
            return e.year;
          }));
          r.add(e.gameYear);
          for (var s = 0, o = Object.keys(e.yearOpenCashYuan); s < o.length; s++) {
            var l = o[s],
              i = Number(l);
            r.has(i) || delete e.yearOpenCashYuan[i];
          }
          var u = t.save.keepRecentEventDetails;
          e.eventHistory.length > u && (e.eventHistory = e.eventHistory.slice(-u));
          e.automationLogs.length > 50 && (e.automationLogs = e.automationLogs.slice(-50));
          return e;
        }
      }), t._RF.push({}, "23cfaQD/R1GD4de3m/9swW0", "statePrune", void 0);
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/TapPlatform.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./errors.ts"], function (t) {
  var e, n, r, o;
  return {
    setters: [function (t) {
      e = t.createForOfIteratorHelperLoose;
    }, function (t) {
      n = t.cclegacy;
    }, function (t) {
      r = t.GameError, o = t.GameErrorCode;
    }],
    execute: function execute() {
      t("resolveTapRuntime", u), n._RF.push({}, "d9b02dpM6lLDIr0s+F2+76e", "TapPlatform", void 0);
      var i = ["getWindowInfo", "onShow", "offShow", "onHide", "offHide", "getStorage", "setStorage", "removeStorage", "login", "getNetworkType", "request"];
      function u(t) {
        if (void 0 === t && (t = globalThis), !t || "object" != _typeof(t)) return null;
        var n = t.tap;
        if (!n || "object" != _typeof(n)) return null;
        for (var r, o = e(i); !(r = o()).done;) {
          if ("function" != typeof n[r.value]) return null;
        }
        return n;
      }
      var a = t("TAP_STORAGE_MAX_KEY_BYTES", 1e6),
        s = function () {
          function t(t, e) {
            var n = this;
            this.settled = !1, this.timer = void 0, this.onTimeout = e, this.timer = setTimeout(function () {
              return n.fire(n.onTimeout);
            }, t);
          }
          return t.prototype.fire = function (t) {
            this.settled || (this.settled = !0, clearTimeout(this.timer), t());
          }, t;
        }();
      function c(t) {
        if (t && "object" == _typeof(t)) {
          var e = t.errMsg;
          if ("string" == typeof e && e.length > 0) return e;
        }
        return t instanceof Error ? t.message : String(t);
      }
      function f(t, e) {
        return new r(o.PLATFORM_UNAVAILABLE, {
          api: t,
          cause: c(e)
        });
      }
      function l(t, e, n) {
        return new r(o.SAVE_FAILED, {
          api: t,
          key: e,
          cause: c(n)
        });
      }
      t("TapPlatform", function () {
        function t(t, e) {
          var n, i, s;
          this.tap = void 0, this.maxKeyBytes = void 0, this.loginTimeoutMs = void 0, this.opTimeoutMs = void 0, this.loginCallbackTimeoutMs = void 0;
          var c = null != t ? t : u();
          if (!c) throw new r(o.PLATFORM_UNAVAILABLE, {
            api: "runtime",
            cause: "globalThis.tap missing or incomplete"
          });
          this.tap = c, this.maxKeyBytes = null != (n = null == e ? void 0 : e.maxKeyBytes) ? n : a, this.loginTimeoutMs = null == e ? void 0 : e.loginTimeoutMs, this.opTimeoutMs = null != (i = null == e ? void 0 : e.opTimeoutMs) ? i : 3e3, this.loginCallbackTimeoutMs = null != (s = null == e ? void 0 : e.loginCallbackTimeoutMs) ? s : 1e4;
        }
        var e = t.prototype;
        return e.getEnvironment = function () {
          return "TAPTAP";
        }, e.getWindowInfo = function () {
          var t;
          try {
            t = this.tap.getWindowInfo();
          } catch (t) {
            throw f("getWindowInfo", t);
          }
          return {
            width: t.windowWidth,
            height: t.windowHeight,
            pixelRatio: t.pixelRatio,
            safeArea: t.safeArea ? {
              top: t.safeArea.top,
              bottom: t.safeArea.bottom,
              left: t.safeArea.left,
              right: t.safeArea.right
            } : void 0
          };
        }, e.onShow = function (t) {
          var e = this;
          this.tap.onShow(t);
          var n = !0;
          return function () {
            n && (n = !1, e.tap.offShow(t));
          };
        }, e.onHide = function (t) {
          var e = this;
          this.tap.onHide(t);
          var n = !0;
          return function () {
            n && (n = !1, e.tap.offHide(t));
          };
        }, e.login = function () {
          var t = this;
          return new Promise(function (e, n) {
            var i = new s(t.loginCallbackTimeoutMs, function () {
                return n(new r(o.AUTH_REQUIRED, {
                  api: "login",
                  cause: "login callback timeout (runtime did not respond)"
                }));
              }),
              u = {
                success: function success(t) {
                  return i.fire(function () {
                    t && "string" == typeof t.code && t.code.length > 0 ? e({
                      code: t.code
                    }) : n(new r(o.AUTH_REQUIRED, {
                      api: "login",
                      cause: "login succeeded but returned empty code"
                    }));
                  });
                },
                fail: function fail(t) {
                  return i.fire(function () {
                    return n(new r(o.AUTH_REQUIRED, {
                      api: "login",
                      cause: c(t)
                    }));
                  });
                }
              };
            void 0 !== t.loginTimeoutMs && (u.timeout = t.loginTimeoutMs);
            try {
              t.tap.login(u);
            } catch (t) {
              i.fire(function () {
                return n(new r(o.AUTH_REQUIRED, {
                  api: "login",
                  cause: c(t)
                }));
              });
            }
          });
        }, e.getNetworkState = function () {
          var t = this;
          return new Promise(function (e) {
            var n = new s(t.opTimeoutMs, function () {
              return e("unknown");
            });
            try {
              t.tap.getNetworkType({
                success: function success(t) {
                  return n.fire(function () {
                    return e("string" != typeof (n = t ? t.networkType : void 0) ? "unknown" : "none" === n ? "offline" : "unknown" === n ? "unknown" : "online");
                    var n;
                  });
                },
                fail: function fail() {
                  return n.fire(function () {
                    return e("unknown");
                  });
                }
              });
            } catch (t) {
              n.fire(function () {
                return e("unknown");
              });
            }
          });
        }, e.get = function (t) {
          var e = this;
          return new Promise(function (n, r) {
            var o = new s(e.opTimeoutMs, function () {
              return n(null);
            });
            try {
              e.tap.getStorage({
                key: t,
                success: function success(t) {
                  return o.fire(function () {
                    var e = t ? t.data : void 0;
                    n(null == e || "" === e ? null : e);
                  });
                },
                fail: function fail(e) {
                  return o.fire(function () {
                    !function (t) {
                      var e,
                        n = null != (e = t.errMsg) ? e : "";
                      return n.includes("data not found") || n.includes("not exist") || n.includes("not found");
                    }(e) ? r(l("getStorage", t, e)) : n(null);
                  });
                }
              });
            } catch (e) {
              o.fire(function () {
                return r(l("getStorage", t, e));
              });
            }
          });
        }, e.set = function (t, e) {
          var n,
            i = this;
          try {
            var u = JSON.stringify(e);
            n = void 0 === u ? 0 : function (t) {
              for (var e = 0, n = 0; n < t.length; n++) {
                var r = t.charCodeAt(n);
                e += r < 128 ? 1 : r < 2048 ? 2 : 3;
              }
              return e;
            }(u);
          } catch (e) {
            return Promise.reject(new r(o.SAVE_FAILED, {
              api: "setStorage",
              key: t,
              cause: "serialize failed: " + c(e)
            }));
          }
          return n > this.maxKeyBytes ? Promise.reject(new r(o.SAVE_FAILED, {
            api: "setStorage",
            key: t,
            bytes: n,
            budgetBytes: this.maxKeyBytes,
            cause: "payload " + n + "B exceeds per-key budget " + this.maxKeyBytes + "B"
          })) : new Promise(function (n, u) {
            var a = new s(i.opTimeoutMs, function () {
              return u(new r(o.SAVE_FAILED, {
                api: "setStorage",
                key: t,
                cause: "setStorage callback timeout (runtime did not respond)"
              }));
            });
            try {
              i.tap.setStorage({
                key: t,
                data: e,
                success: function success() {
                  return a.fire(function () {
                    return n();
                  });
                },
                fail: function fail(e) {
                  return a.fire(function () {
                    return u(l("setStorage", t, e));
                  });
                }
              });
            } catch (e) {
              a.fire(function () {
                return u(l("setStorage", t, e));
              });
            }
          });
        }, e.remove = function (t) {
          var e = this;
          return new Promise(function (n, r) {
            var o = new s(e.opTimeoutMs, function () {
              return n();
            });
            try {
              e.tap.removeStorage({
                key: t,
                success: function success() {
                  return o.fire(function () {
                    return n();
                  });
                },
                fail: function fail(e) {
                  return o.fire(function () {
                    return r(l("removeStorage", t, e));
                  });
                }
              });
            } catch (e) {
              o.fire(function () {
                return r(l("removeStorage", t, e));
              });
            }
          });
        }, e.request = function (t) {
          var e,
            n = this,
            r = null != (e = t.timeoutMs) ? e : Math.max(this.opTimeoutMs, 5e3);
          return new Promise(function (e, o) {
            var i = new s(r, function () {
              return o(f("request", "timeout after " + r + "ms"));
            });
            try {
              var u;
              n.tap.request({
                url: t.url,
                method: null != (u = t.method) ? u : "GET",
                data: t.data,
                header: t.headers,
                timeout: r,
                success: function success(t) {
                  return i.fire(function () {
                    return e({
                      statusCode: t.statusCode,
                      data: t.data
                    });
                  });
                },
                fail: function fail(t) {
                  return i.fire(function () {
                    return o(f("request", t));
                  });
                }
              });
            } catch (t) {
              i.fire(function () {
                return o(f("request", t));
              });
            }
          });
        }, t;
      }());
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/theme.ts", ["cc"], function (e) {
  var r, n;
  return {
    setters: [function (e) {
      r = e.cclegacy, n = e.Color;
    }],
    execute: function execute() {
      r._RF.push({}, "5b7b6UnTyJDDrYSluLHrcQz", "theme", void 0);
      e("THEME", {
        primary: new n().fromHEX("#3668B2"),
        secondary: new n().fromHEX("#5D9F8C"),
        bg: new n().fromHEX("#F5F7FB"),
        card: new n().fromHEX("#FFFFFF"),
        text: new n().fromHEX("#273244"),
        textWeak: new n().fromHEX("#697386"),
        danger: new n().fromHEX("#C75353"),
        profit: new n().fromHEX("#2E9E6B"),
        divider: new n().fromHEX("#E3E8F0"),
        warning: new n().fromHEX("#D9922E"),
        disabled: new n().fromHEX("#B7BFCB")
      }), e("DESIGN_WIDTH", 375), e("DESIGN_HEIGHT", 812), e("MIN_TOUCH", 44);
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/TransferService.ts", ["cc", "./errors.ts", "./MutationContext.ts", "./monthEntry.ts"], function (r) {
  var e, n, t, o, d, f;
  return {
    setters: [function (r) {
      e = r.cclegacy;
    }, function (r) {
      n = r.GameErrorCode;
    }, function (r) {
      t = r.ensureRunId, o = r.hasCommand, d = r.recordCommand;
    }, function (r) {
      f = r.monthIndexOf;
    }],
    execute: function execute() {
      function a(r, e) {
        var t = r.employees.find(function (r) {
          return r.employeeId === e;
        });
        if (!t) throw new Error(n.EMPLOYEE_NOT_FOUND);
        if ("ACTIVE" !== t.status) throw new Error(n.EMPLOYEE_NOT_DISMISSIBLE);
        return t;
      }
      r({
        previewTransfer: function previewTransfer(r, e, t) {
          var o = a(r, e),
            d = r.departments.find(function (r) {
              return r.deptId === t;
            });
          if (!d || !d.enabled) throw new Error(n.DEPT_NOT_FOUND);
          if (o.departmentId === t) throw new Error(n.INVALID_TARGET);
          return {
            employeeId: e,
            name: o.name,
            fromDeptId: o.departmentId,
            toDeptId: t,
            effectiveFromMonthIndex: f(r) + 1
          };
        },
        transferEmployee: function transferEmployee(r, e, i, u) {
          if (t(r, u.expectedRunId), !r.company) throw new Error(n.NOT_READY);
          if ("RUNNING" !== r.phase && "DISTRESS" !== r.phase) throw new Error(n.NOT_READY);
          if (o(r, u.commandId)) return a(r, e);
          var c = a(r, e),
            m = r.departments.find(function (r) {
              return r.deptId === i;
            });
          if (!m || !m.enabled) throw new Error(n.DEPT_NOT_FOUND);
          if (c.departmentId === i) throw new Error(n.INVALID_TARGET);
          return c.pendingDepartmentId = i, c.transferFromMonthIndex = f(r) + 1, d(r, u.commandId), c;
        }
      }), e._RF.push({}, "1347454CHVGfJ81jqc6OraG", "TransferService", void 0), e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/types.ts", ["cc"], function (E) {
  var R;
  return {
    setters: [function (E) {
      R = E.cclegacy;
    }],
    execute: function execute() {
      R._RF.push({}, "531adMQjG5Fu6hjE2LEi5b6", "types", void 0);
      E("INDUSTRIES", ["TRADE", "SOFTWARE", "SERVICE"]), E("SUPPORT_DEPARTMENTS", ["HR", "PROCUREMENT", "MARKETING", "CUSTOMER_SERVICE", "FINANCE"]), E("CEO_TRAITS", ["BOLD", "STEADY", "PEOPLE"]);
      R._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/UiFactory.ts", ["cc", "./theme.ts"], function (t) {
  var n, e, o, i, r, l, a, d, c, u, p, h, C, g, s, m, v, f, T;
  return {
    setters: [function (t) {
      n = t.cclegacy, e = t.Node, o = t.UITransform, i = t.Size, r = t.Graphics, l = t.Label, a = t.HorizontalTextAlignment, d = t.VerticalTextAlignment, c = t.Overflow, u = t.BlockInputEvents, p = t.Color, h = t.Vec3, C = t.Button, g = t.Widget, s = t.Layout, m = t.ScrollView, v = t.Mask;
    }, function (t) {
      f = t.THEME, T = t.MIN_TOUCH;
    }],
    execute: function execute() {
      function w(t) {
        var n,
          l,
          a,
          d = new e(null != (n = t.name) ? n : "Rect");
        d.addComponent(o).setContentSize(new i(t.width, t.height)), t.parent && (d.parent = t.parent);
        var c = d.addComponent(r),
          u = null != (l = t.color) ? l : f.card;
        return c.fillColor = u, c.roundRect(-t.width / 2, -t.height / 2, t.width, t.height, null != (a = t.radius) ? a : 8), c.fill(), d;
      }
      function E(t) {
        var n,
          r,
          u,
          p,
          h,
          C,
          g,
          s,
          m,
          v = new e(null != (n = t.name) ? n : "Label");
        t.parent && (v.parent = t.parent), v.addComponent(o).setContentSize(new i(null != (r = t.width) ? r : 200, null != (u = null != (p = t.height) ? p : t.fontSize) ? u : 20));
        var T = v.addComponent(l);
        return T.string = t.text, T.fontSize = null != (h = t.fontSize) ? h : 14, T.lineHeight = null != (C = t.lineHeight) ? C : (null != (g = t.fontSize) ? g : 14) + 4, T.color = null != (s = t.color) ? s : f.text, T.isBold = null != (m = t.bold) && m, T.horizontalAlign = "left" === t.align ? a.LEFT : "right" === t.align ? a.RIGHT : a.CENTER, T.verticalAlign = d.CENTER, t.width ? T.overflow = t.text.includes("\n") ? c.RESIZE_HEIGHT : c.SHRINK : T.overflow = c.RESIZE_HEIGHT, v;
      }
      function S(t, n, e) {
        var o;
        void 0 === n && (n = 8), void 0 === e && (e = 12);
        var i = null != (o = t.getComponent(s)) ? o : t.addComponent(s);
        return i.type = s.Type.VERTICAL, i.spacingY = n, i.paddingTop = e, i.paddingBottom = e, i.paddingLeft = e, i.paddingRight = e, i.horizontalDirection = s.HorizontalDirection.LEFT_TO_RIGHT, i.verticalDirection = s.VerticalDirection.TOP_TO_BOTTOM, i;
      }
      t({
        addVerticalLayout: S,
        createButton: function createButton(t) {
          var n,
            e,
            o,
            i,
            r,
            l = null != (n = t.height) ? n : T,
            a = w({
              name: null != (e = t.name) ? e : "Button",
              width: t.width,
              height: l,
              color: t.disabled ? f.disabled : null != (o = t.color) ? o : f.primary,
              radius: 8,
              parent: t.parent
            });
          a.addComponent(u), E({
            text: t.text,
            fontSize: null != (i = t.fontSize) ? i : 15,
            color: null != (r = t.textColor) ? r : p.WHITE,
            width: t.width - 16,
            height: l,
            bold: !0,
            parent: a
          }).setPosition(h.ZERO);
          var d = a.addComponent(C);
          return d.transition = C.Transition.SCALE, d.zoomScale = .96, a.on(C.EventType.CLICK, function () {
            t.disabled || t.onClick();
          }), a;
        },
        createLabel: E,
        createRect: w,
        createScrollContainer: function createScrollContainer(t, n, r) {
          var l = new e("ScrollView");
          l.parent = t, l.addComponent(o).setContentSize(new i(n, r)), l.addComponent(u);
          var a = l.addComponent(m);
          a.horizontal = !1, a.vertical = !0;
          var d = new e("View");
          d.parent = l, d.addComponent(o).setContentSize(new i(n, r)), d.addComponent(v).type = v.Type.GRAPHICS_RECT;
          var c = new e("Content");
          return c.parent = d, c.addComponent(o).setContentSize(new i(n, 1)), S(c, 8, 8).constraint = s.Constraint.NONE, a.content = c.getComponent(o), {
            root: l,
            content: c
          };
        },
        moneyText: function moneyText(t) {
          var n = t < 0 ? "-" : "",
            e = Math.abs(t);
          return n + "¥" + e.toLocaleString("zh-CN");
        },
        stretchToParent: function stretchToParent(t, n, e, o, i) {
          var r;
          void 0 === n && (n = 0);
          void 0 === e && (e = 0);
          void 0 === o && (o = 0);
          void 0 === i && (i = 0);
          var l = null != (r = t.getComponent(g)) ? r : t.addComponent(g);
          return l.isAlignTop = !0, l.isAlignBottom = !0, l.isAlignLeft = !0, l.isAlignRight = !0, l.top = n, l.bottom = e, l.left = o, l.right = i, l.alignMode = g.AlignMode.ON_WINDOW_RESIZE, l;
        }
      }), n._RF.push({}, "bf462JYUM5IObmN513Pyr7t", "UiFactory", void 0), n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/validation.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./companyNames.ts", "./types.ts"], function (r) {
  var e, n, t, o, i, a, u;
  return {
    setters: [function (r) {
      e = r.createForOfIteratorHelperLoose;
    }, function (r) {
      n = r.cclegacy;
    }, function (r) {
      t = r.COMPANY_NAME_MIN, o = r.COMPANY_NAME_MAX, i = r.FORBIDDEN_NAME_WORDS;
    }, function (r) {
      a = r.INDUSTRIES, u = r.CEO_TRAITS;
    }],
    execute: function execute() {
      r({
        isValidCeoTrait: function isValidCeoTrait(r) {
          return u.includes(r);
        },
        isValidIndustry: function isValidIndustry(r) {
          return a.includes(r);
        },
        isValidSkill: function isValidSkill(r) {
          return Number.isSafeInteger(r) && r >= 0 && r <= 100;
        },
        normalizeName: s,
        validateCompanyName: function validateCompanyName(r) {
          var n = s(r);
          if (0 === n.length) return {
            ok: !1,
            reason: "EMPTY"
          };
          if (l(n)) return {
            ok: !1,
            reason: "CONTROL_CHAR"
          };
          if (c.test(n)) return {
            ok: !1,
            reason: "TAG"
          };
          var a = f(n);
          if (a < t) return {
            ok: !1,
            reason: "TOO_SHORT"
          };
          if (a > o) return {
            ok: !1,
            reason: "TOO_LONG"
          };
          for (var u, O = e(i); !(u = O()).done;) {
            var v = u.value;
            if (n.includes(v)) return {
              ok: !1,
              reason: "FORBIDDEN_WORD"
            };
          }
          return {
            ok: !0,
            name: n
          };
        },
        validatePersonName: function validatePersonName(r, n) {
          void 0 === n && (n = 12);
          var t = s(r);
          if (0 === t.length) return {
            ok: !1,
            reason: "EMPTY"
          };
          if (l(t)) return {
            ok: !1,
            reason: "CONTROL_CHAR"
          };
          if (c.test(t)) return {
            ok: !1,
            reason: "TAG"
          };
          var o = f(t);
          if (o < 1) return {
            ok: !1,
            reason: "TOO_SHORT"
          };
          if (o > n) return {
            ok: !1,
            reason: "TOO_LONG"
          };
          for (var a, u = e(i); !(a = u()).done;) {
            var O = a.value;
            if (t.includes(O)) return {
              ok: !1,
              reason: "FORBIDDEN_WORD"
            };
          }
          return {
            ok: !0,
            name: t
          };
        },
        visibleLength: f
      }), n._RF.push({}, "c7993r1KDRJNYweWQ7M/eds", "validation", void 0);
      function s(r) {
        return r.split("　").join(" ").trim();
      }
      function f(r) {
        return Array.from(r).length;
      }
      function l(r) {
        for (var n, t = e(r); !(n = t()).done;) {
          var o,
            i = null != (o = n.value.codePointAt(0)) ? o : 0;
          if (i <= 31 || 127 === i || i >= 128 && i <= 159) return !0;
        }
        return !1;
      }
      var c = /<\s*\/?[a-zA-Z][^>]*>/;
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/validators.ts", ["cc", "./validation.ts"], function (a) {
  var i;
  return {
    setters: [function (a) {
      i = a.cclegacy;
    }, function (i) {
      var e = {};
      e.isCeoTrait = i.isValidCeoTrait, e.isIndustry = i.isValidIndustry, e.isValidSkill = i.isValidSkill, e.normalizeName = i.normalizeName, e.validateCompanyName = i.validateCompanyName, e.validatePersonName = i.validatePersonName, e.visibleLength = i.visibleLength, a(e);
    }],
    execute: function execute() {
      i._RF.push({}, "69b31Lz65pIOqueTka5wrOd", "validators", void 0), i._RF.pop();
    }
  };
});
(function (r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main');
})(function (mid, cid) {
  System.register(mid, [cid], function (_export, _context) {
    return {
      setters: [function (_m) {
        var _exportObj = {};
        for (var _key in _m) {
          if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
        }
        _export(_exportObj);
      }],
      execute: function execute() {}
    };
  });
});