function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
System.register([], function (_export, _context) {
  return {
    execute: function execute() {
      System.register("chunks:///_virtual/rollupPluginModLoBabelHelpers.js", [], function (e) {
        return {
          execute: function execute() {
            function t(e, t, r, n, o, i, u) {
              try {
                var a = e[i](u),
                  c = a.value;
              } catch (e) {
                return void r(e);
              }
              a.done ? t(c) : Promise.resolve(c).then(n, o);
            }
            function r(e, t) {
              for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, y(n.key), n);
              }
            }
            function n() {
              return (n = e("extends", Object.assign ? Object.assign.bind() : function (e) {
                for (var t = 1; t < arguments.length; t++) {
                  var r = arguments[t];
                  for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                }
                return e;
              })).apply(this, arguments);
            }
            function o(t) {
              return (o = e("getPrototypeOf", Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (e) {
                return e.__proto__ || Object.getPrototypeOf(e);
              }))(t);
            }
            function i(t, r) {
              return (i = e("setPrototypeOf", Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (e, t) {
                return e.__proto__ = t, e;
              }))(t, r);
            }
            function u() {
              if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
              if (Reflect.construct.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})), !0;
              } catch (e) {
                return !1;
              }
            }
            function a(t, r, n) {
              return (a = u() ? e("construct", Reflect.construct.bind()) : e("construct", function (e, t, r) {
                var n = [null];
                n.push.apply(n, t);
                var o = new (Function.bind.apply(e, n))();
                return r && i(o, r.prototype), o;
              })).apply(null, arguments);
            }
            function c(e) {
              return -1 !== Function.toString.call(e).indexOf("[native code]");
            }
            function l(t) {
              var r = "function" == typeof Map ? new Map() : void 0;
              return (l = e("wrapNativeSuper", function (e) {
                if (null === e || !c(e)) return e;
                if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
                if (void 0 !== r) {
                  if (r.has(e)) return r.get(e);
                  r.set(e, t);
                }
                function t() {
                  return a(e, arguments, o(this).constructor);
                }
                return t.prototype = Object.create(e.prototype, {
                  constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                  }
                }), i(t, e);
              }))(t);
            }
            function f(e, t) {
              if (e) {
                if ("string" == typeof e) return p(e, t);
                var r = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? p(e, t) : void 0;
              }
            }
            function p(e, t) {
              (null == t || t > e.length) && (t = e.length);
              for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
              return n;
            }
            function s(e, t) {
              if ("object" != _typeof(e) || null === e) return e;
              var r = e[Symbol.toPrimitive];
              if (void 0 !== r) {
                var n = r.call(e, t || "default");
                if ("object" != _typeof(n)) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.");
              }
              return ("string" === t ? String : Number)(e);
            }
            function y(e) {
              var t = s(e, "string");
              return "symbol" == _typeof(t) ? t : String(t);
            }
            e({
              applyDecoratedDescriptor: function applyDecoratedDescriptor(e, t, r, n, o) {
                var i = {};
                Object.keys(n).forEach(function (e) {
                  i[e] = n[e];
                }), i.enumerable = !!i.enumerable, i.configurable = !!i.configurable, ("value" in i || i.initializer) && (i.writable = !0);
                i = r.slice().reverse().reduce(function (r, n) {
                  return n(e, t, r) || r;
                }, i), o && void 0 !== i.initializer && (i.value = i.initializer ? i.initializer.call(o) : void 0, i.initializer = void 0);
                void 0 === i.initializer && (Object.defineProperty(e, t, i), i = null);
                return i;
              },
              arrayLikeToArray: p,
              assertThisInitialized: function assertThisInitialized(e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
              },
              asyncToGenerator: function asyncToGenerator(e) {
                return function () {
                  var r = this,
                    n = arguments;
                  return new Promise(function (o, i) {
                    var u = e.apply(r, n);
                    function a(e) {
                      t(u, o, i, a, c, "next", e);
                    }
                    function c(e) {
                      t(u, o, i, a, c, "throw", e);
                    }
                    a(void 0);
                  });
                };
              },
              construct: a,
              createClass: function createClass(e, t, n) {
                t && r(e.prototype, t);
                n && r(e, n);
                return Object.defineProperty(e, "prototype", {
                  writable: !1
                }), e;
              },
              createForOfIteratorHelperLoose: function createForOfIteratorHelperLoose(e, t) {
                var r = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (r) return (r = r.call(e)).next.bind(r);
                if (Array.isArray(e) || (r = f(e)) || t && e && "number" == typeof e.length) {
                  r && (e = r);
                  var n = 0;
                  return function () {
                    return n >= e.length ? {
                      done: !0
                    } : {
                      done: !1,
                      value: e[n++]
                    };
                  };
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
              },
              "extends": n,
              getPrototypeOf: o,
              inheritsLoose: function inheritsLoose(e, t) {
                e.prototype = Object.create(t.prototype), e.prototype.constructor = e, i(e, t);
              },
              initializerDefineProperty: function initializerDefineProperty(e, t, r, n) {
                if (!r) return;
                Object.defineProperty(e, t, {
                  enumerable: r.enumerable,
                  configurable: r.configurable,
                  writable: r.writable,
                  value: r.initializer ? r.initializer.call(n) : void 0
                });
              },
              isNativeFunction: c,
              isNativeReflectConstruct: u,
              setPrototypeOf: i,
              toPrimitive: s,
              toPropertyKey: y,
              unsupportedIterableToArray: f,
              wrapNativeSuper: l
            });
          }
        };
      });
    }
  };
});