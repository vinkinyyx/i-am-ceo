"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _default = {
  "imports": {
    "cc": "./../cocos-js/cc.40b88.js"
  }
};
exports["default"] = _default;