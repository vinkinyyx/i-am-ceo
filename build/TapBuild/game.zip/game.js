/* Unity Converter Injection */
Error.stackTraceLimit = Infinity;

GameGlobal.oldFetch = GameGlobal.fetch;
if (!GameGlobal.oldFetch) {
    console.warn('[compat] fetch is not defined');
}
GameGlobal.fetch = undefined; // remove fetch to follow wx

function __initApp() {
  // init app
  globalThis.__wxRequire = require; // FIX: require cannot work in separate engine 
  require('./web-adapter.898ec.js');
  var firstScreen = require('./first-screen');

  // Polyfills bundle.
  require("src/polyfills.bundle.43263.js");

  // SystemJS support.
  require("src/system.bundle.f45da.js");

  // Adapt for IOS, swap if opposite
  var info = wx.getSystemInfoSync();
  if (typeof canvas !== 'undefined' && canvas) {
    var _w = canvas.width;
    var _h = canvas.height;
    if (info.screenWidth < info.screenHeight) {
      if (canvas.width > canvas.height) {
        _w = canvas.height;
        _h = canvas.width;
      }
    } else {
      if (canvas.width < canvas.height) {
        _w = canvas.height;
        _h = canvas.width;
      }
    }
    canvas.width = _w;
    canvas.height = _h;
  }
  // Adjust initial canvas size
  if (canvas && window.devicePixelRatio >= 2) {
    canvas.width *= info.devicePixelRatio;
    canvas.height *= info.devicePixelRatio;
  }
  var importMap = require("src/import-map.27724.js")["default"];
  System.warmup({
    importMap: importMap,
    importMapUrl: 'src/import-map.27724.js',
    defaultHandler: function defaultHandler(urlNoSchema) {
      require('.' + urlNoSchema);
    },
    handlers: {
      'plugin:': function plugin(urlNoSchema) {
        requirePlugin(urlNoSchema);
      },
      'project:': function project(urlNoSchema) {
        require(urlNoSchema);
      }
    }
  });
  firstScreen.start('default', 'default', 'false').then(function () {
    return System["import"]('./application.c311b.js');
  }).then(function (module) {
    return firstScreen.setProgress(0.2).then(function () {
      return Promise.resolve(module);
    });
  }).then(function (_ref) {
    var Application = _ref.Application;
    return new Application();
  }).then(function (application) {
    return firstScreen.setProgress(0.4).then(function () {
      return Promise.resolve(application);
    });
  }).then(function (application) {
    return onApplicationCreated(application);
  })["catch"](function (err) {
    console.error(err);
    try {
      firstScreen.end();
    } catch (e) {}
  });
  function onApplicationCreated(application) {
    return System["import"]('cc').then(function (module) {
      return firstScreen.setProgress(0.6).then(function () {
        return Promise.resolve(module);
      });
    }).then(function (cc) {
      require('./engine-adapter.e45dd.js');
      return application.init(cc);
    }).then(function () {
      return firstScreen.end().then(function () {
        return application.start();
      });
    });
  }
} // init app

// NOTE: on WeChat Android end, we can only get the correct screen size at the second tick of game.
var sysInfo = wx.getSystemInfoSync();
(function () {
  var platform = sysInfo && sysInfo.platform ? String(sysInfo.platform).toLowerCase() : '';
  var raf = null;
  try {
    raf = GameGlobal && GameGlobal.requestAnimationFrame;
  } catch (e) {}
  if (!raf && typeof requestAnimationFrame === 'function') raf = requestAnimationFrame;
  if (platform === 'android') {
    if (raf) raf(__initApp);else setTimeout(__initApp, 16);
  } else {
    __initApp();
  }
})();